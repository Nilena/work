import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcKeyValueListComponent } from './wbc-key-value-list/wbc-key-value-list.component';
import { WbcChipModule } from '../chip/chip.module'

@NgModule({
  declarations: [WbcKeyValueListComponent],
  imports: [CommonModule,
    WbcChipModule],
  exports: [WbcKeyValueListComponent],
})
export class KeyValueListModule { }
