import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcKeyValueListComponent } from './wbc-key-value-list.component';

describe('WbcKeyValueListComponent', () => {
  let component: WbcKeyValueListComponent;
  let fixture: ComponentFixture<WbcKeyValueListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcKeyValueListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcKeyValueListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
