import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { Subscription } from 'rxjs';
import { DateFormatModel, StatusConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';

@Component({
  selector: 'lib-wbc-grid-against-day',
  templateUrl: './wbc-grid-against-day.component.html',
  styleUrls: ['./wbc-grid-against-day.component.css']
})
export class WbcGridAgainstDayComponent implements OnInit {

  hours: any[];
  currentTime: string;
  eventDetailsSubscription: Subscription;
  @Input() dateConfig: DateFormatModel;
  @Input() statusConfig: StatusConfigModel;
  @Input() events = [];
  @Output() eventData = new EventEmitter<any>();
  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService) { }

  ngOnInit(): void { }

  ngOnChanges(changes: SimpleChanges) {
    this.hours = this.calendarService.getHourList(this.dateConfig);
    if (this.events.length) {
      let eventHr = this.events.map((value) => ({
        ...value,
        formattedHour: value.hour,
        hour: this.timeService.convertTo24HrFormat(value.hour, this.dateConfig),
      }));
      this.events = [...eventHr];
    }
    this.eventDetailsSubscription = this.calendarService.data$.subscribe((data) => {
      this.calendarService.displayedYear = data.year;
      this.calendarService.displayedMonth = data.month;
      this.calendarService.displayedDay = this.timeService.getDayName(data.year, data.month, data.date, this.dateConfig.day);
      this.calendarService.displayedDate = data.date;
    });
  }

  /**
   * @description function to check matching hour from event hour
   * @param hour number
   * @returns filtered object matching from event hour
   */
  getEventsForHour(hour: number): any[] {
    return this.events.filter((event) => {
      const eventHour = event.hour;
      const eventDay = event.day;
      const eventMonth = event.month;
      const eventYear = event.year;
      return (eventHour === hour) && (eventDay == this.calendarService.displayedDate) && (eventMonth == this.calendarService.displayedMonth) && (eventYear == this.calendarService.displayedYear);
    });
  }

  /**
  * @description function to get current
  * @param hour number
  * @returns boolean if it same as currenttime
  */
  getCurrentTime(hour: string): boolean {
    return this.timeService.isCurrentTime(hour, this.dateConfig.formattedHr);
  }

  /**
   * @description function to emit selected event data
   * @param hour number
   * @param event data
   */
  getData(event, hour) {
    let data = {
      date: this.calendarService.displayedDate,
      month: this.calendarService.displayedMonth,
      year: this.calendarService.displayedYear,
      event: event,
      hour: hour
    }
    this.eventData.emit(data);
  }

  /**
 * @description to determine the event color
 * @param status is condition of the event
 * @returns color based on status attribute from event array
 */
  getBackgroundColor(status: string, optional?: boolean, customColor?: string): string {
    if (optional)
      return customColor || this.statusConfig.custom;
    else
      return this.statusConfig[status] || this.statusConfig.default;
  }
  /**
   * @description to destroy event subcription
   */
  ngOnDestroy() {
    this.eventDetailsSubscription.unsubscribe();
  }
}
