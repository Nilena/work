import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { WbcDayViewBottomSheetComponent } from '../wbc-day-view-bottom-sheet/wbc-day-view-bottom-sheet.component';
import { ViewportService } from '../../../services/viewport.service';
import { Subscription } from 'rxjs';
import { DateFormatModel, StatusConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { CdkDragDrop } from '@angular/cdk/drag-drop';

@Component({
  selector: 'lib-wbc-grid-against-week',
  templateUrl: './wbc-grid-against-week.component.html',
  styleUrls: ['./wbc-grid-against-week.component.css']
})
export class WbcGridAgainstWeekComponent implements OnInit {

  @Input() events;
  hours: any[];
  week: any[];
  currentDate: string | Date;
  private eventDetailsSubscription: Subscription;
  @Input() dateConfig: DateFormatModel;
  @Input() statusConfig: StatusConfigModel;
  @Output() eventData = new EventEmitter<{ date: string, month: string, year: string, event: any }>();

  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService,
    private bottomSheet: MatBottomSheet,
    private viewPortService: ViewportService) { }

  ngOnInit(): void { }

  ngOnChanges(changes: SimpleChanges) {
    this.hours = this.calendarService.getHourList(this.dateConfig);
    if (this.events.length) {
      let eventHr = this.events.map((value) => ({
        ...value,
        formattedHour: value.hour,
        hour: this.timeService.convertTo24HrFormat(value.hour, this.dateConfig),
      }));
      this.events = [...eventHr];
    }
    this.eventDetailsSubscription = this.calendarService.data$.subscribe((data) => {
      this.getWeekDetails(data);

    });
  }
  drop(event: CdkDragDrop<string[]>, ) {
    // if (event.previousContainer.data != event.container.data) {
    //   const data = {
    //     month: this.calendarService.displayedMonth,
    //     year: this.calendarService.displayedYear,
    //     from:event.previousContainer.data,
    //     to:event.container.data,
    //     event:this.events.find(ev => ev.eventId === event.item.data.item.eventId &&ev.day===event.previousContainer.data),
    //     drop: 1 //Edit Date
    //   }
    //   this.events = this.events.map(ev => {
    //     if (ev.eventId === event.item.data.item.eventId &&ev.day===event.previousContainer.data) {
    //       return { ...ev, day: event.container.data };
    //     }
    //     return ev;
    //   });
      // this.dragUpdateData(data)
      // this.getNoOfWeeks();
    // }
  }
  /**
  * @description to emit data on event selection
  * @param data 
  */
  dragUpdateData(data) {
    this.eventData.emit(data);
  }
  /**
   * @description function to get current
   * @param hour number
   * @returns boolean if it same as currenttime
   */
  getCurrentTime(hour: string): boolean {
    return this.timeService.isCurrentTime(hour, this.dateConfig.formattedHr);
  }

  /**
  * @description populate week of a month based on display date
  * @param data 
  * @returns array contains weeks 
  */

  getWeekDetails(data): void {
    this.currentDate = this.timeService.getFormatedDate(data.year, data.month, data.date, this.dateConfig.formattedDate);
    const weekDates = this.timeService.getWeekRange(this.currentDate, this.dateConfig);
    this.week = this.populateEventsForWeek(weekDates, this.events);
    this.calendarService.displayedYear = data.year;
    this.calendarService.displayedMonth = data.month;
    this.calendarService.displayedDay = this.timeService.getDayName(data.year, data.month, data.date, this.dateConfig.day);
    this.calendarService.displayedDate = data.date;
  }

  /**
   * @description map event to week based on day of the week
   * @param weekDates 
   * @param events 
   * @returns array contains weeks 
   */

  populateEventsForWeek(weekDates: any[], events: any[]): any[] {
    if (this.events.length)
      return weekDates.map(dayInfo => ({
        ...dayInfo,
        events: events.filter(event => event.day === dayInfo.date)
      }));
    else
      return weekDates
  }
  /**
   * @description filter event object based each day and hour from a week
   * @param hour 
   * @param date 
   * @returns object from the event 
   */

  getEventsofDay(hour: string, dayDetail): any[] {
    return this.events.filter((event) => {
      const eventHour = event.hour;
      const eventDay = event.day;
      const eventMonth = event.month;
      const eventYear = event.year;
      return (eventHour === hour) && (eventDay == dayDetail.date) && (eventMonth == dayDetail.month) && (eventYear == dayDetail.year);
    });
  }
  /**
   * @description to emit selected event
   * @param event details of the event to emit
   * @param hour time of current event to emit
   */

  getData(event, hour) {
    let data = {
      date: this.calendarService.displayedDate,
      month: this.calendarService.displayedMonth,
      year: this.calendarService.displayedYear,
      event: event,
      hour: hour
    }
    this.eventData.emit(data);
  }
  /**
   * @description to determine the event color
   * @param status is condition of the event
   * @returns color based on status attribute from event array
   */
  getBackgroundColor(status: string, optional?: boolean, customColor?: string): string {
    if (optional)
      return customColor || this.statusConfig.custom;
    else
      return this.statusConfig[status] || this.statusConfig.default;
  }
  /**
   * @description function for open bottomsheet in mobile view only
   */
  openBottomSheet(event, hour): void {
    const data = {
      dayName: this.timeService.getDayName(event.year, event.month, event.date, this.dateConfig.day),
      dayNumber: event.date,
      events: event.events,
      status: this.statusConfig
    }

    const bottomSheetConfig = {
      autoFocus: true,
      hasBackdrop: true,
    };
    const bottomsheet = this.bottomSheet.open(WbcDayViewBottomSheetComponent, {
      data: data,
      ...bottomSheetConfig
    });
    bottomsheet.afterDismissed().subscribe((result) => {
      if (result)
        this.getData(result, hour);
    });
  }

  /**
  * @description function for close bottomsheet if it is open
  */

  closeBottomSheet(): void {
    this.bottomSheet.dismiss();
  }
  /**
   * @description function to check mobile view or not
   */
  checkScreenWidth(day, event, hour): void {
    if (!this.viewPortService.isMobileView)
      this.getData(event, hour)
    else
      this.openBottomSheet(day, hour);
  }

  /**
   * @description to destroy event subcription
   */
  ngOnDestroy() {
    this.eventDetailsSubscription.unsubscribe();
  }
}
