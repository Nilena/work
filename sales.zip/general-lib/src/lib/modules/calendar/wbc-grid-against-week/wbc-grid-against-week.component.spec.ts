import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WbcGridAgainstWeekComponent } from './wbc-grid-against-week.component';
import { CalendarService } from '../../../services/calendar.service';
import { of } from 'rxjs';
import { TimeOperationService } from '../../../services/time-operation.service';
import { MatBottomSheet, MatBottomSheetModule, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { ViewportService } from '../../../services/viewport.service';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';

describe('WbcGridAgainstWeekComponent', () => {
  let component: WbcGridAgainstWeekComponent;
  let fixture: ComponentFixture<WbcGridAgainstWeekComponent>;
  let calendarServiceMock: jasmine.SpyObj<CalendarService>;
  let timeServiceMock: jasmine.SpyObj<TimeOperationService>;
  let matBottomSheet: MatBottomSheet;

  const viewportServiceMock = {
    isMobileView: true
  };
  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };

  const mockstatusConfig = {
    approved: 'green',
    rejected: 'red',
    pending: 'blue',
    default: 'transparent'
  }
  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'dddd',
      date: 'DD',
      month: 'MM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      shortDay: 'ddd',
      monthName: 'MMMM',
      hour: 'HH',
      formattedHr: 'hh:mm A'
    },
    StatusConfig: mockstatusConfig
  };
  beforeEach(() => {
    timeServiceMock = jasmine.createSpyObj('timeServiceMock', ['getDayName', 'getHourList', 'getFormatedDate', 'convertTo24HrFormat', 'getWeekRange', 'isCurrentTime']);
    calendarServiceMock = jasmine.createSpyObj('CalendarService', ['getHourList', 'updateEmittedData', 'data$']);
    TestBed.configureTestingModule({
      declarations: [WbcGridAgainstWeekComponent],
      providers: [
        { provide: CalendarService, useValue: calendarServiceMock },
        { provide: TimeOperationService, useValue: timeServiceMock },
        { provide: MatBottomSheet, useValue: { open: () => { }, dismiss: () => { } } },
        { provide: ViewportService, useValue: viewportServiceMock }
      ],
      imports: [MatBottomSheetModule],
    }).compileComponents();
    fixture = TestBed.createComponent(WbcGridAgainstWeekComponent);
    component = fixture.componentInstance;
    matBottomSheet = TestBed.inject(MatBottomSheet);
    component.dateConfig = MockCalenderConfig.dateFormat;
    component.statusConfig = MockCalenderConfig.StatusConfig;
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });


  it('should return true if the given hour is the current time', () => {
    component.dateConfig = MockCalenderConfig.dateFormat;
    timeServiceMock.isCurrentTime.and.returnValue(true);
    const result = component.getCurrentTime('12:30 PM');
    expect(result).toBe(true);
    expect(timeServiceMock.isCurrentTime).toHaveBeenCalledWith('12:30 PM', 'hh:mm A');
  });
  it('should close bottom sheet when closeBottomSheet is called', () => {
    const dismissBottomSheetSpy = spyOn(matBottomSheet, 'dismiss')
    component.closeBottomSheet();
    expect(dismissBottomSheetSpy).toHaveBeenCalled();
  });


  it('should return false if the given hour is not the current time', () => {
    component.dateConfig = MockCalenderConfig.dateFormat;
    timeServiceMock.isCurrentTime.and.returnValue(false);
    const result = component.getCurrentTime('12:30 PM');
    expect(result).toBe(false);
    expect(timeServiceMock.isCurrentTime).toHaveBeenCalledWith('12:30 PM', 'hh:mm A');
  });

  it('should filter events for a specific day and hour', () => {

    const mockEvents = [
      { day: 15, month: '01', year: 2024, eventName: 'Event 1', hour: '10:00 AM', status: 'approved' },
      { day: 15, month: '01', year: 2024, eventName: 'Event 2', hour: '10:15 AM', status: 'pending' },
      { day: 15, month: '01', year: 2024, eventName: 'Event 3', hour: '10:30 AM', status: 'rejected' },
      { day: 16, month: '01', year: 2024, eventName: 'Event 4', hour: '10:00 AM', status: 'approved' },
    ];
    component.events = mockEvents;
    const filteredEvents = component.getEventsofDay('10:15 AM', { date: '15', month: '01', year: '2024' });
    expect(filteredEvents).toEqual([
      { day: 15, month: '01', year: 2024, eventName: 'Event 2', hour: '10:15 AM', status: 'pending' },
    ]);
  });
  it('should emit eventData when getData is called', () => {
    spyOn(component.eventData, 'emit').and.callThrough();
    const mockEvent = { day: '15', month: '01', year: '2024', eventName: 'Webcardio Client meet', hour: '10:00 AM', status: 'rejected' };
    const mockHour = '10';
    calendarServiceMock.displayedDate = '15';
    calendarServiceMock.displayedMonth = '01';
    calendarServiceMock.displayedYear = '2024'
    const expectedEmittedData = {
      date: calendarServiceMock.displayedDate,
      month: calendarServiceMock.displayedMonth,
      year: calendarServiceMock.displayedYear,
      event: mockEvent,
      hour: mockHour,
    };
    component.getData(mockEvent, mockHour);
    expect(component.eventData.emit).toHaveBeenCalledWith(expectedEmittedData);
  });


  it('should populate events for the week', () => {
    const mockWeekDates = [
      { date: 14, day: 'Mon' },
      { date: 15, day: 'Tue' },
    ];

    const mockEvents = [
      { day: 14, month: '01', year: 2024, eventName: 'Event 1', hour: '10:00 AM', status: 'approved' },
      { day: 15, month: '01', year: 2024, eventName: 'Event 2', hour: '10:15 AM', status: 'pending' },
      { day: 16, month: '01', year: 2024, eventName: 'Event 3', hour: '10:30 AM', status: 'rejected' },
    ];
    component.events = mockEvents;
    const result = component.populateEventsForWeek(mockWeekDates, mockEvents);
    expect(result.length).toEqual(2);
    expect(result[0].date).toEqual(14);
    expect(result[0].day).toEqual('Mon');
    expect(result[0].events.length).toEqual(1);
    expect(result[0].events[0]).toEqual(mockEvents[0]);
  });


  it('should return "red" for status "rejected"', () => {
    const status = 'rejected';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('red');
  });

  it('should return "default" for status "addvisit"', () => {
    const status = '';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual(component.statusConfig.default);
  });

  it('should return "red" for status "rejected"', () => {
    const status = 'custom';
    const result = component.getBackgroundColor(status, true);
    expect(result).toEqual(component.statusConfig.custom);
  });

  it('should return "blue" for status "pending"', () => {
    const status = 'pending';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('blue');
  });

  it('should return "transparent" for unknown status', () => {
    const status = 'default';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('transparent');
  });

  it('should return "transparent" for unknown status', () => {
    const status = 'approved';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('green');
  });
  it('should set week details and update calendarService properties', () => {
    const mockData = { year: '2024', month: '01', date: '15' };
    const mockFormattedDate = '2024-01-15';
    const mockWeekDates = [
      { date: '14', day: 'Mon' },
      { date: '15', day: 'Tue' },
    ];
    timeServiceMock.getFormatedDate.and.returnValue(mockFormattedDate);
    timeServiceMock.getWeekRange.and.returnValue(mockWeekDates);
    timeServiceMock.getDayName.and.returnValue('Tue');
    spyOn(component, 'populateEventsForWeek').and.returnValue([])
    component.getWeekDetails(mockData);
    expect(component.currentDate).toEqual(mockFormattedDate);
    expect(component.week).toEqual(component.populateEventsForWeek(mockWeekDates, component.events));

    expect(calendarServiceMock.displayedYear).toEqual(mockData.year);
    expect(calendarServiceMock.displayedMonth).toEqual(mockData.month);
    expect(calendarServiceMock.displayedDay).toEqual('Tue');
    expect(calendarServiceMock.displayedDate).toEqual(mockData.date);
  });
  it('should open bottom sheet when checkScreenWidth is called in mobile view', () => {
    viewportServiceMock.isMobileView = true;
    const mockEvent = {
      dayNumber: '15',
      dayName: 'Tuesday'
    }
    const mockData = {
      dayName: 'Monday',
      dayNumber: '15',
      events: ['Event1', 'Event2']
    };
    const openBottomSheetSpy = spyOn(matBottomSheet, 'open').and.returnValue({
      afterDismissed: () => of(mockData),
    } as MatBottomSheetRef<any>);
    component.checkScreenWidth(mockEvent, mockEvent, 10);
    expect(openBottomSheetSpy).toHaveBeenCalled();
  });

  it('should open bottom sheet with the correct data and config when openBottomSheet is called', () => {
    const mockEvent = {
      dayNumber: '15',
      dayName: 'Tuesday'
    }
    component.events = ['Event 1', 'Event 2'];
    const mockData = {
      dayName: 'Monday',
      dayNumber: '15',
      events: ['Event1', 'Event2']
    };
    const openBottomSheetSpy = spyOn(matBottomSheet, 'open').and.returnValue({
      afterDismissed: () => of(mockData),
    } as MatBottomSheetRef<any>);
    component.openBottomSheet(mockEvent, '10');
    expect(openBottomSheetSpy).toHaveBeenCalled();
  });

  it('should call getData if not in mobile view', () => {
    viewportServiceMock.isMobileView = false;
    const eventMock = {
      dayNumber: '15',
      dayName: 'Tuesday'
    }
    const hourMock = 10;
    const getDataSpy = spyOn(component, 'getData');
    const bottomSheetSpy = spyOn(component, 'openBottomSheet');

    component.checkScreenWidth(eventMock, hourMock, hourMock);
    expect(getDataSpy).toHaveBeenCalledWith(eventMock, hourMock);
    expect(bottomSheetSpy).not.toHaveBeenCalled();
  });
  it('should set hours and update events on ngOnChanges', () => {
    const MockEvents = [
      { hour: '12:00 PM', day: '01', month: '01', year: '2022', status: 'approved' },
      { hour: '03:30 PM', day: '02', month: '01', year: '2022', status: 'rejected' },
    ]; const dateConfig = MockCalenderConfig.dateFormat;
    const testData = { year: '2022', month: '01', date: '01', view: 'week' };
    const weekDates = [{ date: '15', month: '01' }];
    component.dateConfig = dateConfig;
    component.events = MockEvents;
    calendarServiceMock.getHourList.and.returnValue(['12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM']);
    timeServiceMock.convertTo24HrFormat.and.callFake((hour, dateConfig) => hour);
    timeServiceMock.getWeekRange.and.returnValue(weekDates);
    calendarServiceMock.data$ = of(testData);
    component.ngOnChanges({ dateConfig: { currentValue: dateConfig, previousValue: undefined, firstChange: true, isFirstChange: () => true } });
    expect(component.hours).toEqual(['12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM']);
    expect(component.events).toEqual([
      { formattedHour: '12:00 PM', hour: '12:00 PM', day: '01', month: '01', year: '2022', status: 'approved' },
      { formattedHour: '03:30 PM', hour: '03:30 PM', day: '02', month: '01', year: '2022', status: 'rejected' },
    ]);
    spyOn(component, 'getWeekDetails').and.returnValue();
  });


});
