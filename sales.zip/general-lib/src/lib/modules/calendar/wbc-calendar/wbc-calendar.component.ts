import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { MatSidenav } from '@angular/material/sidenav';
import { CalenderConfig } from '../wbc-calendar-config';
import { TimeOperationService } from '../../../services/time-operation.service';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { ViewportService } from '../../../services/viewport.service';

@Component({
  selector: 'lib-wbc-calendar',
  templateUrl: './wbc-calendar.component.html',
  styleUrls: ['./wbc-calendar.component.css']
})
export class WbcCalendarComponent implements OnInit {
  activeViewBy: string;
  openMenu: boolean = false;
  toggleEvent: boolean = false;
  @Input() data = [];
  @Input() date
  @Input() config?;
  @Input() reportees = [];
  @Output() eventData = new EventEmitter<{ date: string, month: string, year: string, event?: any, hour?: string, action?: number }>();
  @ViewChild('sidenav') sidenav: MatSidenav;

  calendarConfig: WbcCalenderConfigModel = CalenderConfig;
  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService,
    public viewportService: ViewportService) { }

  ngOnChanges(changes: SimpleChanges) {
    if ('config' in changes) {
      this.calendarConfig = this.config;
      this.calendarService.displayedView = this.calendarConfig.headerConfig.view.default;
      this.activeViewBy = this.calendarConfig.headerConfig.view.default;
    }
    let currentMoment = this.calendarService.currentMoment;
    if ('date' in changes) {
      const data = {
        month: this.date.month,
        year: this.date.year,
        date: currentMoment.date().toString().padStart(2, '0'),
        view: this.calendarService.displayedView
      };
      this.calendarService.updateData(data);
  }
  }

  ngOnInit(): void {
    this.calendarService.displayedView = this.calendarConfig.headerConfig.view.default;
    this.activeViewBy = this.calendarConfig.headerConfig.view.default;
    if (!this.viewportService.isMobileView)
      this.openMenu = true;
    else
      this.openMenu = false;
  }

  /**
   * @description change month and date based on direction 
   * @param event {action,view} action -1 for backward and 1 for forward
   */
  changeMonth(event) {
    const date = this.calendarService.displayedDate;
    const year = this.calendarService.displayedYear;
    const monthName = this.timeService.getMonthName(this.calendarService.displayedMonth, this.calendarConfig.dateFormat.monthName);
    this.calendarService.displayedView = event.view;
    let data: { date: string, month: string, year: string, view: string, action?: number };
    let currentMoment = this.calendarService.currentMoment;
    currentMoment = currentMoment.year(parseInt(year)).month(monthName).date(parseInt(date));

    switch (event.action) {
      case -1:
        switch (event.view) {
          case 'day':
            currentMoment.subtract(1, 'day');
            break;
          case 'month':
            currentMoment.subtract(1, 'months');
            break;
          case 'week':
            currentMoment.subtract(1, 'week').startOf('isoWeek');
            break;
        }
        break;

      case 1:
        switch (event.view) {
          case 'day':
            currentMoment.add(1, 'day');
            break;
          case 'month':
            currentMoment.add(1, 'months');
            break;
          case 'week':
            currentMoment.add(1, 'week').startOf('isoWeek');
            break;
        }
        break;
    }

    data = {
      month: (currentMoment.month() + 1).toString().padStart(2, '0'),
      year: currentMoment.year().toString(),
      date: currentMoment.date().toString().padStart(2, '0'),
      view: event.view,
      action: event.action
    };
    this.getEventDetails(data);
    this.calendarService.updateData(data);
  }

  /**
   * @description change month and date based on direction 
   * @param event {action,view} action -1 for backward and 1 for forward
   */

  changeView(event: string) {
    this.calendarService.displayedView = event;
    this.activeViewBy = event;
    let data = {
      date: this.calendarService.displayedDate,
      month: this.calendarService.displayedMonth,
      year: this.calendarService.displayedYear,
      view: this.calendarService.displayedView,
    }
    this.getEventDetails(data);
  }

  /**
   * @description to open ans close side nav
   */
  toggleSidenav(event) {
    this.toggleEvent = event;
    this.sidenav.toggle();
  }

  /**
    * @description to emit selected event
    */
  getEventDetails(event) {
    this.eventData.emit(event);
  }

}
