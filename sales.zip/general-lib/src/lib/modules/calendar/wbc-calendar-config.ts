import { WbcCalenderConfigModel } from "./wbc-calendar-config-model/wbc-calendar-config-model";

export const ViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
];

export const ViewConfig = {
    default: 'month',
    options: ViewOptions,
    display: true,

}
export const statusConfig = {
    approved: 'green',
    rejected: 'red',
    pending: 'blue',
    done: 'black',
    default: 'black',
    inProgress: 'black',
    deleted: 'rgb(236, 18, 189)',
    custom: 'lightseagreen'

}
export const CalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
        view: ViewConfig,
        displayView: true,
        displaySkipOptions: true,
        display: true,
        title: 'Calender',
        menu: true
    },
    sideNavConfig: {
        display: true,
        displayCalender: true,
        selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
        day: 'dddd',
        shortDay: 'ddd',
        date: 'DD',
        month: 'MM',
        monthName: 'MMMM',
        year: 'YYYY',
        formattedDate: 'YYYY-MM-DD',
        hour: 'HH',
        formattedHr: 'hh:mm A',
    },
    StatusConfig: statusConfig
}

