import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WbcWebGridAgainstMonthComponent } from './wbc-web-grid-against-month.component';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { of } from 'rxjs';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { SimpleChanges } from '@angular/core';

describe('WbcWebGridAgainstMonthComponent', () => {
  let component: WbcWebGridAgainstMonthComponent;
  let fixture: ComponentFixture<WbcWebGridAgainstMonthComponent>;
  let calendarServiceSpy: jasmine.SpyObj<CalendarService>;
  let timeServiceSpy: jasmine.SpyObj<TimeOperationService>;
  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };

  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'dddd',
      shortDay: 'ddd',
      date: 'DD',
      month: 'MM',
      monthName: 'MMMM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      hour: 'HH',
      formattedHr: 'hh:mm A',
    }
  };
  const MockEvents = [
    { day: '01', year: '2024', month: '01', event: 'Event 1' },
    { day: '02', year: '2024', month: '01', event: 'Event 2' },
  ];

  beforeEach(() => {
    calendarServiceSpy = jasmine.createSpyObj('CalendarService', ['updateEmittedData']);
    timeServiceSpy = jasmine.createSpyObj('TimeOperationService', ['getDaysInAMonth', 'getDayName', 'getFormatedDate']);

    TestBed.configureTestingModule({
      declarations: [WbcWebGridAgainstMonthComponent],
      providers: [
        { provide: CalendarService, useValue: calendarServiceSpy },
        { provide: TimeOperationService, useValue: timeServiceSpy },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(WbcWebGridAgainstMonthComponent);
    component = fixture.componentInstance;
    component.dateConfig = MockCalenderConfig.dateFormat;
    component.events = MockEvents;
    calendarServiceSpy.data$ = of({ year: '2024', month: '01', date: '15', view: 'month' });
    calendarServiceSpy.displayedYear = '2024';
    calendarServiceSpy.displayedMonth = '01';
    calendarServiceSpy.displayedDate = '15';

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should getNoOfWeeks and update days array', () => {
    const daysInMonth = 31;
    timeServiceSpy.getDaysInAMonth.and.returnValue(daysInMonth);
    spyOn(component, 'generateDaysArray').and.callThrough();
    component.getNoOfWeeks();
    expect(component.generateDaysArray).toHaveBeenCalledWith(daysInMonth);
    expect(component.dayList.length).toBe(daysInMonth);
  });

  it('should generate array of days with correct properties and events', () => {
    const daysInMonth = 31;
    component.events = MockEvents;

    component.dateConfig.formattedDate = MockCalenderConfig.dateFormat.formattedDate;
    const result = component.generateDaysArray(daysInMonth);
    expect(result.length).toBe(daysInMonth);
    for (let i = 0; i < result.length; i++) {
      const days = result[i];
      expect(days.day).toBe((i + 1).toString().padStart(2, '0'));
    }
  });

  it('should emit eventData when getData is called', () => {
    spyOn(component.eventData, 'emit').and.callThrough();
    const testData: { date: string, month: string, year: string, number: number; events: any } = {
      number: 15,
      date: '15',
      month: '01',
      year: '2024',
      events: [{
        day: '15',
        month: '01',
        year: '2024', eventName: 'Webcardio Morning meet', status: 'approved'
      }],
    };
    component.getData(testData);
    expect(component.eventData.emit).toHaveBeenCalledWith(testData);
  });

  // it('should subscribe to CalendarService.data$ when "events" changes', () => {
  //   const MockEvents = [
  //     { hour: '12:00 PM', day: '01', month: '01', year: '2022', status: 'approved' },
  //     { hour: '03:30 PM', day: '02', month: '01', year: '2022', status: 'rejected' },
  //   ]; const dateConfig = MockCalenderConfig.dateFormat;
  //   const testData = { year: '2022', month: '01', date: '01', view: 'week' };
  //   const weekDates = [{ date: '15', month: '01' }];
  //   component.dateConfig = dateConfig;
  //   component.events = MockEvents;
  //    const changes: SimpleChanges = {
  //     events: {
  //       currentValue: [{}, {}, {}], 
  //       previousValue: undefined,
  //       firstChange: true,
  //       isFirstChange: () => true
  //     }
  //   };
  //   component.ngOnChanges(changes);
  //   calendarServiceSpy.data$ = of(testData);

  //   expect(component.year).toBeDefined();
  //   expect(component.month).toBeDefined();
  //   expect(component.date).toBeDefined();
  //   expect(calendarServiceSpy.displayedYear).toBe(component.year);
  //   expect(calendarServiceSpy.displayedMonth).toBe(component.month);
  //   expect(calendarServiceSpy.displayedDay).toBeDefined(); 
  //   expect(calendarServiceSpy.displayedDate).toBe(component.date);
  //   expect(component.getNoOfWeeks).toHaveBeenCalled();
  // });

 
});
