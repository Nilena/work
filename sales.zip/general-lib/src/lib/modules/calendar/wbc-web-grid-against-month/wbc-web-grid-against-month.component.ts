import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges} from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { Subscription } from 'rxjs';
import { DateFormatModel, StatusConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { CdkDragDrop } from '@angular/cdk/drag-drop';
@Component({
  selector: 'lib-wbc-web-grid-against-month',
  templateUrl: './wbc-web-grid-against-month.component.html',
  styleUrls: ['./wbc-web-grid-against-month.component.css']
})
export class WbcWebGridAgainstMonthComponent implements OnInit {
  year: string;
  month: string;
  date: string;
  dayList: any[];
  private eventDetailsSubscription: Subscription;
  weeks: { number: number; events: string[] }[][] = [];
  @Input() events;
  @Input() dateConfig: DateFormatModel;
  @Input() statusConfig: StatusConfigModel;
  @Output() eventData = new EventEmitter<any>();

  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService) { }

  ngOnInit(): void {}
  ngOnChanges(changes: SimpleChanges) {
    if ('events' in changes) {
      this.eventDetailsSubscription = this.calendarService.data$.subscribe((data) => {
        this.year = data.year;
        this.month = data.month;
        this.date = data.date;
        this.calendarService.displayedYear = this.year;
        this.calendarService.displayedMonth = this.month;
        this.calendarService.displayedDay = this.timeService.getDayName(data.year, data.month, data.date, this.dateConfig.day);
        this.calendarService.displayedDate = this.date;
        this.getNoOfWeeks();
      });
    }
  }

  drop(event: CdkDragDrop<string[]>, ) {
      const data = {
        month:this.month,
        year:this.year,
        from:event.previousContainer.data,
        to:event.container.data,
        event:this.events.find(ev => ev.eventId === event.item.data.item.eventId&&ev.day===event.previousContainer.data),
        drop: 1 //Edit Date
      }
      this.getData(data)
  }

  /**
   * @description to populate days in a month
   */
  getNoOfWeeks() {
    const daysInaMonth = this.timeService.getDaysInAMonth(this.year, this.month);
    this.dayList = this.generateDaysArray(daysInaMonth);
  }

  /**
  * @description to generate array of days
  */
  generateDaysArray(daysInMonth): any {
    const daysArray: any[] = [];
    for (let i = 1; i <= daysInMonth; i++) {
      const eventsForDay: any[] = this.events.filter(event => (
        event.day === i.toString().padStart(2, '0') &&
        event.year === this.calendarService.displayedYear &&
        event.month === this.calendarService.displayedMonth
      ));
      daysArray.push({
        number: i,
        day: i.toString().padStart(2, '0'),
        month: this.calendarService.displayedMonth,
        year: this.calendarService.displayedYear,
        date: this.timeService.getFormatedDate(this.calendarService.displayedYear, this.calendarService.displayedMonth, i.toString().padStart(2, '0'), this.dateConfig.formattedDate),
        dayName: this.timeService.getDayName(this.calendarService.displayedYear, this.calendarService.displayedMonth, i.toString().padStart(2, '0'), this.dateConfig.day),
        events: eventsForDay,
      });
    }
    return daysArray;
  }

  /**
   * @description to emit data on event selection
   * @param data 
   */
  getData(data) {
    this.eventData.emit(data);
  }
  /**
    * @description to destroy subscription
    */
  ngOnDestroy() {
    this.eventDetailsSubscription.unsubscribe();
  }
}
