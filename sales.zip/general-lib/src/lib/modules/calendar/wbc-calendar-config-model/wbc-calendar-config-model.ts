export interface WbcCalenderConfigModel {
    headerConfig?: HeaderConfigModel,
    dateFormat?: DateFormatModel,
    sideNavConfig?: SideNavConfigModel,
    StatusConfig?: StatusConfigModel
}

export interface HeaderConfigModel {
    view: ViewOptionsModel,
    displayView: boolean
    displaySkipOptions: boolean,
    display: boolean,
    title: string,
    menu: boolean
}
export interface ViewOptionsModel {
    default: string,
    options: { id: string, value: string, viewValue: string, hide: boolean }[]
    display: boolean
}
export interface DateFormatModel {
    day: string,
    shortDay: string
    date: string,
    month: string,
    monthName: string
    year: string,
    formattedDate: string,
    hour: string,
    formattedHr: string
}
export interface SideNavConfigModel {
    display: boolean,
    displayCalender: boolean,
    selectionDropdown: { display: boolean, multi: boolean }
}

export interface StatusConfigModel {
    approved: string;
    rejected: string;
    pending: string;
    done?: string,
    default: string,
    inProgress?: string,
    deleted?: string,
    custom?: string
}