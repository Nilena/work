import { Component, EventEmitter, Inject, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { CalendarService } from '../../../services/calendar.service';

@Component({
  selector: 'lib-wbc-day-view-bottom-sheet',
  templateUrl: './wbc-day-view-bottom-sheet.component.html',
  styleUrls: ['./wbc-day-view-bottom-sheet.component.css']
})
export class WbcDayViewBottomSheetComponent implements OnInit {
  constructor(@Inject(MAT_BOTTOM_SHEET_DATA) public data: any,
    private bottomSheetRef: MatBottomSheetRef<WbcDayViewBottomSheetComponent>,
    private calendarService: CalendarService) { }


  ngOnInit(): void {
  }

  /**
   * @param event
   *  @description emit data to based selected event
   */
  getData(event) {
    this.bottomSheetRef.dismiss(event);
  }

  /**
   * @param color
   *  @description update color based on status 
   */
  getBackgroundColor(color: string, optional?: boolean, customColor?: string): string {
    if (optional)
      return customColor  || this.data.status.default;
    else
      return this.data.status[color];
  }
}

