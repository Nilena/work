import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheetModule, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { CalendarService } from '../../../services/calendar.service';
import { WbcDayViewBottomSheetComponent } from './wbc-day-view-bottom-sheet.component';

describe('WbcDayViewBottomSheetComponent', () => {
  let component: WbcDayViewBottomSheetComponent;
  let fixture: ComponentFixture<WbcDayViewBottomSheetComponent>;
  let calendarService: CalendarService;
  const mockMatBottomSheetRef = jasmine.createSpyObj(['dismiss']);

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WbcDayViewBottomSheetComponent],
      imports: [MatBottomSheetModule],
      providers: [
        { provide: MAT_BOTTOM_SHEET_DATA, useValue: {} },
        { provide: MatBottomSheetRef, useValue: mockMatBottomSheetRef }, // Provide the mock
        CalendarService
      ],
    });

    fixture = TestBed.createComponent(WbcDayViewBottomSheetComponent);
    calendarService = TestBed.inject(CalendarService);

    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit data when getData is called', () => {
    const mockEvent = { day: '15', month: '01', year: '2024', eventName: 'Webcardio Client meet', hour: '10:00 AM', status: 'rejected' };
    component.getData(mockEvent);
    expect(mockMatBottomSheetRef.dismiss).toHaveBeenCalledWith(mockEvent);
  });

  it('should return the correct background color based on status', () => {
    const mockData = {
      status: {
        approved: 'green',
        pending: 'yellow',
        rejected: 'red'
      }
    };
    component.data = mockData;
    const resultGreen = component.getBackgroundColor('approved');
    const resultYellow = component.getBackgroundColor('pending');
    const resultRed = component.getBackgroundColor('rejected');
    expect(resultGreen).toBe('green');
    expect(resultYellow).toBe('yellow');
    expect(resultRed).toBe('red');
  });
  
  it('should return "custom" for status "approved" if addvisit is true', () => {
    const mockData = {
      status: {
        approved: 'green',
        pending: 'yellow',
        rejected: 'red',
        custom: 'lightreen'
      }
    };
    component.data = mockData;
    const status = 'approved';
    const result = component.getBackgroundColor('approved', true,mockData.status.custom);
    expect(result).toBe(mockData.status.custom);
  });

  afterEach(() => {
    fixture.destroy();
  });
});
