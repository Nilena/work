import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component, EventEmitter, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { MatBottomSheet, MatBottomSheetConfig, MatBottomSheetModule, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { WbcCalendarGridboxComponent } from './wbc-calendar-gridbox.component';
import { CalendarService } from '../../../services/calendar.service';
import { ViewportService } from '../../../services/viewport.service';
import { WbcDayViewBottomSheetComponent } from '../wbc-day-view-bottom-sheet/wbc-day-view-bottom-sheet.component';
import { of } from 'rxjs';


describe('WbcCalendarGridboxComponent', () => {
  let component: WbcCalendarGridboxComponent;
  let fixture: ComponentFixture<WbcCalendarGridboxComponent>;
  let calendarServiceSpy: jasmine.SpyObj<CalendarService>;
  let matBottomSheet: MatBottomSheet;
  let matBottomSheetRef: MatBottomSheetRef<WbcDayViewBottomSheetComponent>;

  const viewportServiceMock = {
    isMobileView: true
  };
  const mockstatusConfig = {
    approved: 'green',
    rejected: 'red',
    pending: 'blue',
    default: 'transparent'
  }
  beforeEach(() => {
    calendarServiceSpy = jasmine.createSpyObj('CalendarService', ['getDisplayedDate', 'getMonthNumber', 'getDisplayedMonth', 'getDisplayedYear', 'updateEmittedData']);

    TestBed.configureTestingModule({
      declarations: [WbcCalendarGridboxComponent],
      providers: [
        { provide: CalendarService, useValue: calendarServiceSpy },
        { provide: MatBottomSheet, useValue: { open: () => { }, dismiss: () => { }, afterDismissed: () => { } } },
        { provide: ViewportService, useValue: viewportServiceMock }
      ],
      imports: [MatBottomSheetModule],
    }).compileComponents();

    fixture = TestBed.createComponent(WbcCalendarGridboxComponent);
    matBottomSheet = TestBed.inject(MatBottomSheet);
    component = fixture.componentInstance;
    calendarServiceSpy.displayedMonth = '01';
    calendarServiceSpy.displayedYear = '2022';
    component.statusConfig = mockstatusConfig;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component properties', () => {
    component.dayNumber = '01';
    component.dayName = 'Monday';
    component.data = {};
    component.events = ['Event 1', 'Event 2'];
    calendarServiceSpy.displayedDate = '01';
    calendarServiceSpy.displayedMonth = '01';
    calendarServiceSpy.displayedYear = '2022';
    component.ngOnInit();
    expect(component.currentDate).toBe(false);
    expect(component.slicedContents).toEqual(['Event 1', 'Event 2']);
    expect(component.remainingContents).toBe(0);
  });

  it('should initialize component properties', () => {
    
    component.dayNumber = '01';
    component.dayName = 'Saturday';
    component.data = {};
    component.events = ['Event 1', 'Event 2'];
    calendarServiceSpy.currentDate = '01';
    calendarServiceSpy.currentMonth = '01';
    calendarServiceSpy.currentYear = '2022';
    calendarServiceSpy.displayedMonth = '01';
    calendarServiceSpy.displayedDate = '01';

    calendarServiceSpy.displayedYear = '2022';
    component.ngOnInit();

    expect(component.currentDate).toBe(true);
    expect(component.slicedContents).toEqual(['Event 1', 'Event 2']);
    expect(component.remainingContents).toBe(0);
  });

  it('should set slicedContents and remainingContents when events array is provided with more than 3 items', () => {
    component.events = ['Event 1', 'Event 2', 'Event 3', 'Event 4'];
    component.ngOnInit();
    expect(component.slicedContents).toEqual(component.events.slice(0, 2));
    expect(component.remainingContents).toEqual(component.events.length - 2);
  });

  it('should set slicedContents and remainingContents as empty when events array is not provided', () => {
    component.events = [];
    component.ngOnInit();
    expect(component.slicedContents).toEqual([]);
    expect(component.remainingContents).toEqual(0);
  });


  it('should emit eventData when getData is called', () => {
    const eventDataSpy = jasmine.createSpyObj('EventEmitter', ['emit']);
    component.eventData = eventDataSpy;

    const MockEvent = { day: '01' }
    component.getData(MockEvent);

    const expectedData = {
      date: '01',
      month: '01',
      year: '2022',
      event: MockEvent

    };
    expect(eventDataSpy.emit).toHaveBeenCalledWith({ date: '01', month: '01', year: '2022', event: MockEvent });
  });


  it('should close bottom sheet when closeBottomSheet is called', () => {
    const dismissBottomSheetSpy = spyOn(matBottomSheet, 'dismiss')
    component.closeBottomSheet();
    expect(dismissBottomSheetSpy).toHaveBeenCalled();
  });


  it('should open popuop when checkScreenWidth is called in web view', () => {
    viewportServiceMock.isMobileView = false;
    const openBottomSheetSpy = spyOn(matBottomSheet, 'open');
    component.checkScreenWidth();
    expect(openBottomSheetSpy).not.toHaveBeenCalled();
    expect(component.openPopup).toBe(true);
  });


  it('should open bottom sheet when checkScreenWidth is called in mobile view', () => {
    viewportServiceMock.isMobileView = true;
    const mockData = {
      dayName: 'Monday',
      dayNumber: '15',
      events: ['Event1', 'Event2']
    };
    const openBottomSheetSpy = spyOn(matBottomSheet, 'open').and.returnValue({
      afterDismissed: () => of(mockData),
    } as MatBottomSheetRef<any>);
    component.checkScreenWidth();
    expect(component.openPopup).toBe(false);
    expect(openBottomSheetSpy).toHaveBeenCalled();
  });

  it('should open bottom sheet with the correct data and config when openBottomSheet is called', () => {
    component.dayName = 'Monday';
    component.dayNumber = '01';
    component.events = ['Event 1', 'Event 2'];
    const mockData = {
      dayName: 'Monday',
      dayNumber: '15',
      events: ['Event1', 'Event2']
    };
    const openBottomSheetSpy = spyOn(matBottomSheet, 'open').and.returnValue({
      afterDismissed: () => of(mockData),
    } as MatBottomSheetRef<any>);
    component.openBottomSheet();
    expect(openBottomSheetSpy).toHaveBeenCalled();
  });

  it('should return the correct background color for each status', () => {
    expect(component.getBackgroundColor('approved')).toBe('green');
    expect(component.getBackgroundColor('rejected')).toBe('red');
    expect(component.getBackgroundColor('pending')).toBe('blue');
    expect(component.getBackgroundColor('unknown')).toBe('transparent');
  });

  it('should return "default" for status "addvisit"', () => {
    const status = '';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual(component.statusConfig.default);
  });

  it('should return "red" for status "rejected"', () => {
    const status = 'custom';
    const result = component.getBackgroundColor(status, true);
    expect(result).toEqual(component.statusConfig.custom);
  });
});
