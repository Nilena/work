import { Component, EventEmitter, HostListener, Input, OnInit, Output, SimpleChanges, TemplateRef, ViewChild } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { WbcDayViewBottomSheetComponent } from '../wbc-day-view-bottom-sheet/wbc-day-view-bottom-sheet.component';
import { ViewportService } from '../../../services/viewport.service';
import { LIB_CONSTANT } from '../../../general-lib-constants.enum';
import { StatusConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';

@Component({
  selector: 'lib-wbc-calendar-gridbox',
  templateUrl: './wbc-calendar-gridbox.component.html',
  styleUrls: ['./wbc-calendar-gridbox.component.css']
})
export class WbcCalendarGridboxComponent implements OnInit {
  @Input() dayNumber: string;
  @Input() dayName: string;
  @Input() data: {};
  @Input() events: string[];
  @Input() statusConfig: StatusConfigModel;
  @Output() eventData = new EventEmitter<{ date: string, month: string, year: string, event: any }>();
  openPopup: boolean = false;
  slicedContents: any[] = [];
  remainingContents = 0;
  currentDate: boolean = false;
  isMobileView: boolean;
  openDayView: boolean = false;
  constants;
  constructor(private calendarService: CalendarService,
    private bottomSheet: MatBottomSheet,
    private viewPortService: ViewportService) {
    this.constants = LIB_CONSTANT;
  };

  ngOnInit(): void {
  }
  ngOnChanges(changes: SimpleChanges) {
    if ('events' in changes) {
      if (this.events) {
        if (this.events?.length > 3) {
          this.slicedContents = this.events.slice(0, 2);
          this.remainingContents = this.events?.length - 2;
        } else {
          this.slicedContents = this.events ? this.events : [];
          this.remainingContents = 0;
        }
      }
      if (this.dayNumber === this.calendarService.displayedDate && (this.calendarService.currentMonth === this.calendarService.displayedMonth)
        && (this.calendarService.currentYear === this.calendarService.displayedYear)) {
        this.currentDate = true;
      } else {
        this.currentDate = false;
      }
    }
  }
  /**
  * @description function for close bottomsheet if it is open
  */

  closeBottomSheet(): void {
    this.bottomSheet.dismiss();
  }
  /**
   * @description function for emit data based on selected event
   * @param event 
   */

  getData(res) {
    let data = { date: res.day, month: this.calendarService.displayedMonth, year: this.calendarService.displayedYear, event: res };
    this.eventData.emit(data);
  }

  /**
   * @description function for open bottomsheet in mobile view only
   */
  openBottomSheet(): void {
    const data = {
      dayName: this.dayName,
      dayNumber: this.dayNumber,
      events: this.events,
      status: this.statusConfig
    }

    const bottomSheetConfig = {
      autoFocus: true,
      hasBackdrop: true,
    };
    const bottomsheet = this.bottomSheet.open(WbcDayViewBottomSheetComponent, {
      data: data,
      ...bottomSheetConfig
    });
    bottomsheet.afterDismissed().subscribe((result) => {
      if (result)
        this.getData(result);
    });
  }

  /**
   * @description function to check mobile view or not
   */
  checkScreenWidth(): void {
    if (this.viewPortService.isMobileView) {
      this.openBottomSheet();
      this.openPopup = false;
    }
    else
      this.openPopup = true;
  }

  /**
  * @description to determine the event color
  * @param status is condition of the event
  * @returns color based on status attribute from event array
  */
 getBackgroundColor(status: string, optional?: boolean, customColor?: string): string {
   if (optional)
     return customColor || this.statusConfig.custom;
   else
     return this.statusConfig[status] || this.statusConfig.default;
 }}
