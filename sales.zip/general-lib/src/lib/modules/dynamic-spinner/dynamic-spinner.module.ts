import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcDynamicSpinnerComponent } from './wbc-dynamic-spinner/wbc-dynamic-spinner.component';



@NgModule({
    declarations: [WbcDynamicSpinnerComponent],
    imports: [
        CommonModule,
    ],
    exports: [
        WbcDynamicSpinnerComponent
    ]
})
export class DynamicSpinnerModule { }
