import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcSuccessIconComponent } from './wbc-success-icon/wbc-success-icon.component';
import { WbcCloseIconComponent } from './wbc-close-icon/wbc-close-icon.component';
import { WbcWarningIconComponent } from './wbc-warning-icon/wbc-warning-icon.component';
import { WbcErrorIconComponent } from './wbc-error-icon/wbc-error-icon.component';
import { WbcInfoIconComponent } from './wbc-info-icon/wbc-info-icon.component';



@NgModule({
  declarations: [WbcSuccessIconComponent, WbcCloseIconComponent, WbcWarningIconComponent, WbcErrorIconComponent, WbcInfoIconComponent],
  imports: [
    CommonModule
  ],
  exports: [WbcSuccessIconComponent, WbcCloseIconComponent, WbcWarningIconComponent, WbcErrorIconComponent, WbcInfoIconComponent]
})
export class IconsModule { }
