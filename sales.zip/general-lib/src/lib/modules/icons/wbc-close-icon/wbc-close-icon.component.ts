import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-close-icon',
  templateUrl: './wbc-close-icon.component.html',
  styleUrls: ['./wbc-close-icon.component.css']
})
export class WbcCloseIconComponent implements OnInit {

  constructor() { }

  @Input() size;

  ngOnInit(): void {
  }

}
