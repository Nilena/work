import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-error-icon',
  templateUrl: './wbc-error-icon.component.html',
  styleUrls: ['./wbc-error-icon.component.css']
})
export class WbcErrorIconComponent implements OnInit {

  constructor() { }

  @Input() size

  ngOnInit(): void {
  }

}
