import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcErrorIconComponent } from './wbc-error-icon.component';

describe('WbcErrorIconComponent', () => {
  let component: WbcErrorIconComponent;
  let fixture: ComponentFixture<WbcErrorIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcErrorIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcErrorIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
