import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-info-icon',
  templateUrl: './wbc-info-icon.component.html',
  styleUrls: ['./wbc-info-icon.component.css']
})
export class WbcInfoIconComponent implements OnInit {

  constructor() { }

  @Input() size;

  ngOnInit(): void {
  }

}
