import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-warning-icon',
  templateUrl: './wbc-warning-icon.component.html',
  styleUrls: ['./wbc-warning-icon.component.css']
})
export class WbcWarningIconComponent implements OnInit {

  constructor() { }

  @Input() size;

  ngOnInit(): void {
  }

}
