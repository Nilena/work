import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcWarningIconComponent } from './wbc-warning-icon.component';

describe('WbcWarningIconComponent', () => {
  let component: WbcWarningIconComponent;
  let fixture: ComponentFixture<WbcWarningIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcWarningIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcWarningIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
