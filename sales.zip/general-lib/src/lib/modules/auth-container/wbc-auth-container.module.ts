import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcAuthContainerComponent } from './wbc-auth-container.component';
import { MatCardModule } from '@angular/material/card';

@NgModule({
  declarations: [
    WbcAuthContainerComponent
  ],
  imports: [
    CommonModule,
    MatCardModule
  ],
  exports:[
    WbcAuthContainerComponent
  ]
})
export class WbcAuthContainerModule { }
