import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcHeaderComponent } from './wbc-header/wbc-header.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from '@angular/material/icon';




@NgModule({
  declarations: [WbcHeaderComponent],
  imports: [
    CommonModule,
    MatTooltipModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    
    
  ],
  exports:[WbcHeaderComponent]
})
export class HeaderModule { }
