import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcHeaderComponent } from './wbc-header.component';

describe('WbcHeaderComponent', () => {
  let component: WbcHeaderComponent;
  let fixture: ComponentFixture<WbcHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
