import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcMultiSelectDropdownComponent } from './wbc-multi-select-dropdown/wbc-multi-select-dropdown.component';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [WbcMultiSelectDropdownComponent],
  imports: [
    CommonModule,
    MatInputModule,
    ReactiveFormsModule,
    MatIconModule,
    MatSelectModule,
    NgxMatSelectSearchModule,
    FormsModule,
    MatCheckboxModule
  ],
  exports: [WbcMultiSelectDropdownComponent]
})
export class MultiSelectDropdownModule {}
