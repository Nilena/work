import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcMultiSelectDropdownComponent } from './wbc-multi-select-dropdown.component';

describe('WbcMultiSelectDropdownComponent', () => {
  let component: WbcMultiSelectDropdownComponent;
  let fixture: ComponentFixture<WbcMultiSelectDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcMultiSelectDropdownComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcMultiSelectDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
