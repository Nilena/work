export interface BreadCrumb {
    items: BreadCrumbItem[],
    customClass?: string
}

export interface BreadCrumbItem {
    title: string,
    route?: string,
}