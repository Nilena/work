import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcBreadCrumbComponent } from './wbc-bread-crumb/wbc-bread-crumb.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    WbcBreadCrumbComponent
  ],
  imports: [
    CommonModule,
    MatIconModule
  ],
  exports: [WbcBreadCrumbComponent]
})
export class WbcBreadCrumbModule { }
