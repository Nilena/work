import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-filter-with-popover',
  templateUrl: './wbc-filter-with-popover.component.html',
  styleUrls: ['./wbc-filter-with-popover.component.css']
})
export class WbcFilterWithPopoverComponent implements OnInit {

  @Input() activeOption: string;
  @Input() isFilterActive:boolean;
  @Input() activeIcon:string;
  @Input() inActiveIcon:string;
  @Input() radioBtnCustomClass:string='';

  @Input() options: any = [];
  @Output() applyFilterEvent = new EventEmitter();
  constructor() {}

  ngOnInit(): void {}

  applyFilter() {
    this.applyFilterEvent.emit(this.activeOption);
  }

}
