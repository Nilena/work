import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcFilterWithPopoverComponent } from './wbc-filter-with-popover/wbc-filter-with-popover.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    WbcFilterWithPopoverComponent
  ],
  imports: [
    CommonModule,
    MatMenuModule,
    MatRadioModule,
    FormsModule
  ],
  exports:[
    WbcFilterWithPopoverComponent
  ]
})
export class FilterModule { }
