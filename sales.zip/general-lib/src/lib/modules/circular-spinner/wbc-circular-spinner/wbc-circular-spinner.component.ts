import { Component, OnInit, OnDestroy,ChangeDetectorRef } from '@angular/core';
import {SubscriptionLike as ISubscription} from "rxjs";
import { map } from 'rxjs/operators';
import {WbcSpinnerService} from '../../../services/wbc-spinner.service';


@Component({
  selector: 'lib-wbc-circular-spinner',
  templateUrl: './wbc-circular-spinner.component.html',
  styleUrls: ['./wbc-circular-spinner.component.css']
})
export class WbcCircularSpinnerComponent implements OnInit,OnDestroy {
  subscription:ISubscription
  state:boolean;
  constructor(private spinnerService : WbcSpinnerService,private cdr:ChangeDetectorRef) { }
/**
 * Ng Init event
 */
  ngOnInit() {
    this.subscription = this.spinnerService.spinnerState.pipe(map((state: boolean) => { 
      this.state=state;
      this.cdr.detectChanges();
    })).subscribe()
}
/**
 * NG destroy event
 */
ngOnDestroy(){
  this.subscription.unsubscribe();
}
}