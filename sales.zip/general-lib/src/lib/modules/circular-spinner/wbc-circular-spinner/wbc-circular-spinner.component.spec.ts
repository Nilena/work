import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcCircularSpinnerComponent } from './wbc-circular-spinner.component';

describe('WbcCircularSpinnerComponent', () => {
  let component: WbcCircularSpinnerComponent;
  let fixture: ComponentFixture<WbcCircularSpinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcCircularSpinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcCircularSpinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
