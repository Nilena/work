import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcSnackbarComponent } from './wbc-snackbar.component';

describe('WbcSnackbarComponent', () => {
  let component: WbcSnackbarComponent;
  let fixture: ComponentFixture<WbcSnackbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcSnackbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcSnackbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
