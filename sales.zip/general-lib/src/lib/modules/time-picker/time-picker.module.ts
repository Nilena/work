import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcTimePickerComponent } from './wbc-time-picker/wbc-time-picker.component';
import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';



@NgModule({
  declarations: [WbcTimePickerComponent],
  imports: [
    CommonModule,
    NgxMaterialTimepickerModule
  ],
  exports:[WbcTimePickerComponent]
})
export class TimePickerModule { }
