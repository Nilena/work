import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcActionDialogComponent } from './wbc-action-dialog/wbc-action-dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  declarations: [WbcActionDialogComponent],
  imports: [CommonModule, MatButtonModule, FlexLayoutModule],
  exports: [WbcActionDialogComponent]
})
export class ActionDialogModule {}
