import { Component, Input, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-action-dialog',
  templateUrl: './wbc-action-dialog.component.html',
  styleUrls: ['./wbc-action-dialog.component.css']
})
export class WbcActionDialogComponent implements OnInit {
  @Input() className: string;
  @Input() message: string = 'Dialog Message';
  @Input() rightActionLabel: string = 'RightAction';
  @Input() leftActionLabel: string = 'LeftAction';

  @Output() rightAction = new EventEmitter<any>();
  @Output() leftAction = new EventEmitter<any>();

  constructor() {}

  ngOnInit(): void {}

  rightActionFunc() {
    this.rightAction.emit(true);
  }

  leftActionFunc() {
    this.leftAction.emit(true);
  }
}
