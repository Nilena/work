import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcActionDialogComponent } from './wbc-action-dialog.component';

describe('WbcActionDialogComponent', () => {
  let component: WbcActionDialogComponent;
  let fixture: ComponentFixture<WbcActionDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcActionDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcActionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
