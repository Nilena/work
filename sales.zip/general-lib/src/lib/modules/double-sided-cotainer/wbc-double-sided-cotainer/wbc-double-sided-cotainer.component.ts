import { Component, ElementRef, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { IWbcLeftContent, Ribbon } from '../wbc-double-sided-cotainer.model';
import { IWbcIcon } from '../wbc-double-sided-cotainer.model';
import { FabButton } from '../../fab-button/wbc-fab-button-model';

@Component({
  selector: 'lib-wbc-double-sided-cotainer',
  templateUrl: './wbc-double-sided-cotainer.component.html',
  styleUrls: ['./wbc-double-sided-cotainer.component.css'],
})
export class WbcDoubleSidedCotainerComponent implements OnInit {
  @Input() leftColor!: string;
  @Input() rightColor!: string;
  @Input() leftContent!: IWbcLeftContent[];
  @Input() rightContent!: IWbcLeftContent[];
  @Input() rightTitle!: string;
  @Input() rightIcons!: IWbcIcon[];
  @Input() id!: string;
  @Input() isRightClickable!: boolean;
  @Input() customIconClass!: string;
  @Input() ribbonContent!: Ribbon;
  @Input() footerActionsConfig!: FabButton[]

  @Output() iconClick = new EventEmitter<IWbcIcon>();
  @Output() fabClick = new EventEmitter<{id: string, action: string}>()
  @Output() clickEvent = new EventEmitter();
  selected: boolean = false;

  constructor(
    private matIconRegistry: MatIconRegistry,
    private domSanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    if (this.rightIcons)
      for (let item of this.rightIcons) {
        this.matIconRegistry.addSvgIcon(
          item.name as string,
          this.domSanitizer.bypassSecurityTrustResourceUrl(item.iconPath)
        );
      }
  }

  handleClick(item: IWbcIcon) {
    this.iconClick.emit(item);
  }

  selectedItem() {
    if (this.isRightClickable) {
      this.selected = !this.selected;
      this.clickEvent.emit({ id: this.id, status: this.selected });
    }
  }

  selectedBtn(item: FabButton){
    event?.stopPropagation()
    this.fabClick.emit({id: this.id, action: item.action})
  }

}
