import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcDatePickerComponent } from './wbc-date-picker.component';

describe('WbcDatePickerComponent', () => {
  let component: WbcDatePickerComponent;
  let fixture: ComponentFixture<WbcDatePickerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcDatePickerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcDatePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set selected date on ngOnInit', () => {
    const date = new Date('2023-09-30');
    component.date = date;
    fixture.detectChanges();

    expect(component.selected).toEqual(date);
  });

  it('should emit selectedDate on button click', () => {
    const date = new Date('2023-09-30');
    spyOn(component.selectedDate, 'emit');
    component.date = date;
    fixture.detectChanges();
    let event = {value: date}
    component.onDateSelected(event);

    expect(component.selectedDate.emit).toHaveBeenCalledWith(date);
  });
});
