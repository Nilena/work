import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges
} from '@angular/core';

@Component({
  selector: 'lib-wbc-date-picker',
  templateUrl: './wbc-date-picker.component.html',
  styleUrls: ['./wbc-date-picker.component.css']
})
export class WbcDatePickerComponent implements OnInit {
  @Input() date;
  @Output() selectedDate = new EventEmitter<Date>();
  selected: Date | null;
  constructor() {}

  ngOnInit(): void {}
  ngOnChanges(changes: SimpleChanges) {
    this.selected = this.date;
  }

  /**
   * @param {any} event  The event to process
   */
  onDateSelected(event: any): void {
    this.selectedDate.emit(event);
  }
}
