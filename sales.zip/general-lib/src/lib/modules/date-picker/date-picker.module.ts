import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcDatePickerComponent } from './wbc-date-picker/wbc-date-picker.component';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCardModule} from '@angular/material/card';
import { ReactiveFormsModule } from '@angular/forms'; 

@NgModule({
  declarations: [
    WbcDatePickerComponent
  ],
  imports: [
    CommonModule,
    MatDatepickerModule,
    MatCardModule,
    ReactiveFormsModule
  ],
  exports:[
    WbcDatePickerComponent
  ]
})
export class DatePickerModule { }
