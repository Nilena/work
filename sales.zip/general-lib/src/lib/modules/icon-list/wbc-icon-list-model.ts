export interface IWbcIcon {
    iconPath: string;
    name: string;
    value?: number;
  }