import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcIconListComponent } from './wbc-icon-list/wbc-icon-list.component';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [WbcIconListComponent],
  imports: [CommonModule, MatIconModule],
  exports: [WbcIconListComponent],
})
export class IconListModule {}
