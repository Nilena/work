import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Chip, ChipList, } from '../../chip/wbc-chip-models';

@Component({
  selector: 'lib-wbc-chip-list',
  templateUrl: './wbc-chip-list.component.html',
  styleUrls: ['./wbc-chip-list.component.css']
})
export class WbcChipListComponent {

  @Input() list!: ChipList;
  @Output() clickEvent = new EventEmitter();
  @Output() removeChipEvent = new EventEmitter();

  constructor() { }

  selectedChip(chip: Chip) {
    this.clickEvent.emit(chip);
  }

  removeChip(index: number) {
    this.removeChipEvent.emit(this.list.chipItems[index]);
    this.list.chipItems.splice(index, 1);
  }

}
