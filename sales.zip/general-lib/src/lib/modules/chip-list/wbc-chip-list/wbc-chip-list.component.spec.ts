import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WbcChipListComponent } from './wbc-chip-list.component';
import { Chip, ChipList } from '../../chip/wbc-chip-models';

describe('WbcChipListComponent', () => {
  let component: WbcChipListComponent;
  let fixture: ComponentFixture<WbcChipListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcChipListComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcChipListComponent);
    component = fixture.componentInstance;
    component.list = {
      chipItems: [{ value: 'WC1100-SP3' }, { value: 'WC1100-SP5' }],
      removableIcon: { icon: 'close', iconClass: 'custom-close-list' }
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit click event with chip object when chip is clicked', () => {
    const chip: Chip = { value: 'WC1100-SP3' }
    const emitSpy = spyOn(component.clickEvent, 'emit');
    component.selectedChip(chip);
    expect(emitSpy).toHaveBeenCalledWith(chip);
  });

  it('should remove chip at given index', () => {
    component.list = {
      chipItems: [{ value: 'WBC_123', customClass: 'chip-s' }, { value: 'WBC_1233', customClass: 'chip-s' }, { value: 'WBC_12', customClass: 'chip-s' }],
      removableIcon: { icon: 'close', iconClass: 'icon-custom' }
    }
    component.removeChip(1);
    expect(component.list.chipItems.length).toBe(2);
    const emitSpy = spyOn(component.removeChipEvent, 'emit');
    expect(emitSpy).toHaveBeenCalledWith(component.list)
    expect(component.list.chipItems).toEqual([{ value: 'WBC_1233', customClass: 'chip-s' }]);
  });
});