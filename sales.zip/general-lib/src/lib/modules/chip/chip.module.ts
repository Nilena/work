import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcChipComponent } from './wbc-chip/wbc-chip.component';
import { WbcChipTagComponent } from './wbc-chip-tag/wbc-chip-tag.component';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { WbcFabButtonModule } from '../fab-button/fab-button.module';



@NgModule({
  declarations: [
    WbcChipComponent,
    WbcChipTagComponent
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    MatIconModule,
    WbcFabButtonModule
  ],
  exports: [WbcChipComponent]
})
export class WbcChipModule { }
