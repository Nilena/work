import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcChipComponent } from './wbc-chip.component';
import { MatChipsModule } from '@angular/material/chips';

describe('WbcChipComponent', () => {
  let component: WbcChipComponent;
  let fixture: ComponentFixture<WbcChipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcChipComponent],
      imports: [MatChipsModule]
    })
      .compileComponents();

    fixture = TestBed.createComponent(WbcChipComponent);
    component = fixture.componentInstance;

    component.tag = {
      value: 'Test Chip',
      tag: true
    };
    component.tag = {
      value: 'Tag Chip'
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit click event when chip is clicked', () => {
    const emitSpy = spyOn(component.clickEvent, 'emit');
    const chipElement: HTMLElement = fixture.nativeElement.querySelector('.chip');
    chipElement.click();
    expect(emitSpy).toHaveBeenCalledWith(component.tag);
  });

  it('should emit remove chip event when remove button is clicked', () => {
    const emitSpy = spyOn(component.removeChipEvent, 'emit');
    const removeButton: HTMLElement = fixture.nativeElement.querySelector('.close-btn');
    removeButton.click();
    expect(emitSpy).toHaveBeenCalledWith(component.tag);
  });
});
