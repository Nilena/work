import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WbcChipTagComponent } from './wbc-chip-tag.component';
import { Chip } from '../wbc-chip-models';

describe('WbcChipTagComponent', () => {
  let component: WbcChipTagComponent;
  let fixture: ComponentFixture<WbcChipTagComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcChipTagComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcChipTagComponent);
    component = fixture.componentInstance;

    component.data = {
      value: 'Tag Chip'
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit click event when chip is clicked', () => {
    const chip: Chip = { value: 'Test Chip' };
    const emitSpy = spyOn(component.clickEvent, 'emit');
    component.clickedChip(chip);
    expect(emitSpy).toHaveBeenCalledWith(chip);
  });
});