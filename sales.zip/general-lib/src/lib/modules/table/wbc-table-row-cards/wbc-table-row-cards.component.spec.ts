import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcTableRowCardsComponent } from './wbc-table-row-cards.component';

describe('WbcTableRowCardsComponent', () => {
  let component: WbcTableRowCardsComponent;
  let fixture: ComponentFixture<WbcTableRowCardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcTableRowCardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcTableRowCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
