import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcTableComponent } from './wbc-table.component';

describe('WbcTableComponent', () => {
  let component: WbcTableComponent;
  let fixture: ComponentFixture<WbcTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
