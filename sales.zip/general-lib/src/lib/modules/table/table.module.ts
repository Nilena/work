import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcTableComponent } from './wbc-table/wbc-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { UserMessageModule } from '../user-message/user-message.module';
import { PipeModule } from '../../pipe/pipe.module';
import { RouterModule } from '@angular/router';
import { WbcTableRowCardsComponent } from './wbc-table-row-cards/wbc-table-row-cards.component';
import { ButtonModule } from '../button/button.module';

@NgModule({
  declarations: [WbcTableComponent, WbcTableRowCardsComponent],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatCheckboxModule,
    UserMessageModule,
    PipeModule,
    MatSortModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule,
    RouterModule,
    ButtonModule
  ],
  exports: [WbcTableComponent, WbcTableRowCardsComponent]
})
export class TableModule {}
