import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcMultipleAddressFormComponent } from './wbc-multiple-address-form.component';

describe('WbcMultipleAddressFormComponent', () => {
  let component: WbcMultipleAddressFormComponent;
  let fixture: ComponentFixture<WbcMultipleAddressFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcMultipleAddressFormComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcMultipleAddressFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit click event with save object when save btn is clicked', () => {
    const event = {
      addressLane1: 'address1', state: 'kerala', addressLane2: null,
      country: 'india', district: 'ernakulam', pin: 682021, isGstRegistered: false,
      gstin: false, isPrimaryAddr: true, isShippingAddr: true, isInvoiceAddr: true,
      addressId: null
    }
    const emitSpy = spyOn(component.savedSingleAddressClick, 'emit');
    component.savedAddressList(event);
    expect(emitSpy).toHaveBeenCalledWith(event);
  });

  it('should emit footer event with footer btn object when button is clicked', () => {
    const event = { id: 'delete', action: 'delete' }
    const emitSpy = spyOn(component.footerActionFabBtnClick, 'emit');
    component.onAddressBtnAction(event);
    expect(emitSpy).toHaveBeenCalledWith(event);
  });
});
