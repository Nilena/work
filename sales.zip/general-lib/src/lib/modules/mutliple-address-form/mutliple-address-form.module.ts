import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcMultipleAddressFormComponent } from './wbc-multiple-address-form/wbc-multiple-address-form.component';
import { MatButtonModule } from '@angular/material/button';
import { WbcOverlappingCardModule } from '../overlapping-card/overlapping-card.module';
import { DoubleSidedCotainerModule } from '../double-sided-cotainer/double-sided-cotainer.module';
import { SingleAddressFormModule } from '../single-address-form/single-address-form.module';



@NgModule({
  declarations: [
    WbcMultipleAddressFormComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    WbcOverlappingCardModule,
    DoubleSidedCotainerModule,
    SingleAddressFormModule
  ],
  exports: [WbcMultipleAddressFormComponent]
})
export class MutlipleAddressFormModule { }
