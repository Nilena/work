export interface ApiConfig {
    apiBaseUrl: string,
    routePath: string,
    operations: string
}
