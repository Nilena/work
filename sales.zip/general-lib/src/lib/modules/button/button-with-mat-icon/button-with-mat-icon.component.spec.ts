import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonWithMatIconComponent } from './button-with-mat-icon.component';

describe('ButtonWithMatIconComponent', () => {
  let component: ButtonWithMatIconComponent;
  let fixture: ComponentFixture<ButtonWithMatIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ButtonWithMatIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonWithMatIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call onClick method when the button is clicked', () => {
    spyOn(component, 'onClick');
    const button = fixture.nativeElement.querySelector('.btn');
    button.click();
    expect(component.onClick).toHaveBeenCalled();
  });

  it('should disable the button when disabled property is true', () => {
    component.disabled = true;
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector('.btn');
    expect(button.disabled).toBeTruthy();
  });

  it('should not disable the button when disabled property is false', () => {
    component.disabled = false;
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector('.btn');
    expect(button.disabled).toBeFalsy();
  });

  it('should show the provided button label', () => {
    component.btnLabel = 'Submit';
    fixture.detectChanges();
    const button = fixture.nativeElement.querySelector('.btn');
    expect(button.textContent).toContain('Submit');
  });

  it('should show the provided button icon', () => {
    component.btnIcon = 'add';
    fixture.detectChanges();
    const icon = fixture.nativeElement.querySelector('mat-icon');
    expect(icon.textContent).toContain('add');
  });
});
