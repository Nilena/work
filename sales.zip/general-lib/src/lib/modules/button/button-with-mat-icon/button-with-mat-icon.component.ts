import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-button-with-mat-icon',
  templateUrl: './button-with-mat-icon.component.html',
  styleUrls: ['./button-with-mat-icon.component.css']
})
export class ButtonWithMatIconComponent implements OnInit {
  @Output() clickEvent: EventEmitter<any> = new EventEmitter();
  @Input() btnLabel!: string;
  @Input() btnType: string = 'button';
  @Input() disabled: Boolean = false;
  @Input() btnIcon?: string
  @Input() btnColor: string = 'primary';
  @Input() isLoading: boolean = false;
  @Input() customClass: string = '';
  constructor() {}

  ngOnInit(): void {}

  onClick() {
    this.clickEvent.emit();
  }
}
