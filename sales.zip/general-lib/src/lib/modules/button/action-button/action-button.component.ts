import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-action-button',
  templateUrl: './action-button.component.html',
  styleUrls: ['./action-button.component.css']
})
export class ActionButtonComponent implements OnInit {
  @Output() clickEvent: EventEmitter<any> = new EventEmitter();
  @Input() type: string;
  @Input() buttonType: string = "button";
  @Input() disabled: Boolean = false;
  @Input() btnType: string = "button";
  @Input() isFullWidth:boolean=false;
  @Input() isLoading:boolean=false;

  className:string;
  constructor() {
  }

  ngOnInit(): void {
    this.className=`${this.type}_action_btn`
  }
  onClick() {
    this.clickEvent.emit();
  }
}
