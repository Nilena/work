import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcResetPasswordWithCodeComponent } from './wbc-reset-password-with-code.component';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('WbcResetPasswordWithCodeComponent', () => {
  let component: WbcResetPasswordWithCodeComponent;
  let fixture: ComponentFixture<WbcResetPasswordWithCodeComponent>;
  let formBuilder: FormBuilder;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcResetPasswordWithCodeComponent ],
      imports: [
        ReactiveFormsModule,
        FormsModule,
      ],
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcResetPasswordWithCodeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize reset password form',() => {
    spyOn(component, 'initiResetPasswordForm')
    component.ngOnInit()
    expect(component.initiResetPasswordForm).toHaveBeenCalled()
  })

  it('should set submitted to true', () => {
    component.onResetPasswordSubmit();
    fixture.detectChanges();
    expect(component.submitted).toBeTruthy();
  });

  it('should reset password on submit',() => {
    spyOn(component.updatePassword, 'emit');
    component.ResetPasswordForm.setValue({code: 'cceqcqc3x', password: 'asdfghjkhfdssx', confirmPassword: 'asdfghjkhfdssx'})
    component.onResetPasswordSubmit()
    expect(component.updatePassword.emit).toHaveBeenCalled()
  })

  it('should initialize ResetPasswordForm with the correct controls and validators',() => {
    spyOn(formBuilder, 'group').and.callThrough();
    component.initiResetPasswordForm();
    expect(component.ResetPasswordForm instanceof FormGroup).toBe(true);
  })
});
