import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'lib-wbc-reset-password-with-code',
  templateUrl: './wbc-reset-password-with-code.component.html',
  styleUrls: ['./wbc-reset-password-with-code.component.css'],
})
export class WbcResetPasswordWithCodeComponent implements OnInit {
  constants: any;
  submitted: boolean = false;
  public ResetPasswordForm!: FormGroup;
  isLoading: boolean = false;
  @Input() forgotImage!: string;
  @Input() authTitle!: string;
  @Input() resetNewPwLabel!: string;
  @Input() resetConfirmPwLabel!: string;
  @Input() codeLabel!: string;
  @Input() codeErrorText!: string;
  @Input() btnLabel!: string;
  @Input() passwordnoSpaceValidator!: () => void;
  @Input() passwordMatchValidator!: (formGroup: FormGroup) => void;
  @Input() codeSentMessage!: string;
  @Output() updatePassword = new EventEmitter();

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initiResetPasswordForm();
  }

  initiResetPasswordForm() {
    this.ResetPasswordForm = this.formBuilder.group(
      {
        code: ['', [Validators.required]],
        password: [
          '',
          [
            Validators.required,
            Validators.minLength(8),
            this.passwordnoSpaceValidator(),
          ],
        ],
        confirmPassword: [
          '',
          [
            Validators.required,
            Validators.minLength(8),
            this.passwordnoSpaceValidator(),
          ],
        ],
      },
      { validator: this.passwordMatchValidator }
    );
  }

  onResetPasswordSubmit() {
    this.submitted = true;
    console.log(this.ResetPasswordForm.value);

    if (this.ResetPasswordForm.valid) {
      this.updatePassword.emit(this.ResetPasswordForm.value);
    }
  }
}
