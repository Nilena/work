import { Component, OnInit, Input ,Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'lib-wbc-dialog-header',
  templateUrl: './wbc-dialog-header.component.html',
  styleUrls: ['./wbc-dialog-header.component.css']
})
export class WbcDialogHeaderComponent implements OnInit {

  constructor() { }
  @Input() title;
  @Input() leftIcon;
  @Input() rightIcon='close';
  @Output() rightAction = new EventEmitter<string>();
  @Output() leftAction = new EventEmitter<string>();

  @Input() className:string;


  ngOnInit() {
  }

  rightActionFunc() {
    this.rightAction.next('');
  }
  leftActionFunc() {
    this.leftAction.next('');
  }

}
