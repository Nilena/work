import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges
} from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'lib-wbc-autocomplete',
  templateUrl: './wbc-autocomplete.component.html',
  styleUrls: ['./wbc-autocomplete.component.css']
})
export class WbcAutocompleteComponent implements OnInit {
  @Input() options: string[];
  @Input() label;
  @Input() placeHolder;
  @Input() initOptionIdx = 0;
  @Output() selectionEvent = new EventEmitter<any>();

  filteredOptions: Observable<string[]>;
  selectionControl = new FormControl();
  _emitSub: Subscription;
  currentOptionIdx = 0;

  constructor() {}

  ngOnInit(): void {
    this.selectionControl.setValue(this.options[this.initOptionIdx]);
    this.currentOptionIdx = this.initOptionIdx;
    this.filteredOptions = this.selectionControl.valueChanges.pipe(
      map((value) => this.filter(value))
    );
    this._emitSub = this.selectionControl.valueChanges.subscribe((value) => {
      this.selectionEvent.emit(value);
      this.currentOptionIdx = this.options.findIndex(
        (option) => option === value
      );
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if ('options' in changes) {
      if (this.currentOptionIdx >= 0) {
        this.selectionControl.setValue(this.options[this.currentOptionIdx], {
          emitEvent: false
        });
      }
    }
  }

  clearSelection(e) {
    e.preventDefault();
    this.selectionControl.setValue('');
  }

  filter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.options.filter((option) =>
      option.toLowerCase().startsWith(filterValue)
    );
  }

  ngOnDestroy() {
    this._emitSub && this._emitSub.unsubscribe();
  }
}
