import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcLoginComponent } from './wbc-login/wbc-login.component';
import { MatButtonModule } from "@angular/material/button";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { MatCardModule } from "@angular/material/card";
import { MatInputModule } from "@angular/material/input";
import { MatIconModule } from "@angular/material/icon";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatTooltipModule } from "@angular/material/tooltip";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { CognitoLoginComponent } from './cognito-login/cognito-login.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ButtonModule } from '../button/button.module';

@NgModule({
  declarations: [WbcLoginComponent, CognitoLoginComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatInputModule,
    MatIconModule,
    MatToolbarModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatCheckboxModule,
    ButtonModule
  ],
  exports:[
    WbcLoginComponent,
    CognitoLoginComponent
  ]
})
export class LoginModule { }
