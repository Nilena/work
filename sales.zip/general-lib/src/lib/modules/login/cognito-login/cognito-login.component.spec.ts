import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CognitoLoginComponent } from './cognito-login.component';

describe('CognitoLoginComponent', () => {
  let component: CognitoLoginComponent;
  let fixture: ComponentFixture<CognitoLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CognitoLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CognitoLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle password',() => {
    component.hidePassword = true;
    component.tgglePassword(new Event('click')); 
    expect(component.hidePassword).toBe(false);
  })

  it('should emit the submitLogin event',() => {
    spyOn(component.submitLogin, 'emit');
    component.submitted = true
    component.loginForm.setValue({ email:'ajay@gmail.com', password: 'AJAY12345@' });
    // fixture.detectChanges();
    component.formSubmit()
    expect(component.submitLogin.emit).toHaveBeenCalled()
  })
});
