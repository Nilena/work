import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'lib-cognito-login',
  templateUrl: './cognito-login.component.html',
  styleUrls: ['./cognito-login.component.css']
})
export class CognitoLoginComponent implements OnInit {

  public loginForm!: FormGroup;
  public submitted = false;

  /** Todo
   *Minimum Length Need to be updated depending on the project requirement.
   */
  passwordMinimumLength: number = 8;

  @Input() forgotPath!: string;
  error!: string | null;
  @Output() submitLogin = new EventEmitter<any>();
  @Input() loginImage!: string;
  @Input() loginTitle!: string;
  @Input() loginEmailLabel!: string;
  @Input() loginEmailPlaceholder!: string;
  @Input() loginEmailrequiredText!: string;
  @Input() loginEmailPatternErrText!: string;
  @Input() loginPwLabel!: string;
  @Input() loginPwPlaceholder!: string;
  @Input() loginPwrequiredText!: string;
  @Input() loginForgotLink!: string;
  @Input() loginEmailPattern!: string;
  @Input() icon!: string
  @Input() mobLogoIcon!: string
  hidePassword: boolean = true;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.initLoginForm();
  }

  /** Login form validator init. */
  initLoginForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(this.loginEmailPattern)]],
      password: ['', [Validators.required]],
    });
  }

  /**toggle password  */
  tgglePassword(event: Event) {
    event.preventDefault();
    this.hidePassword = !this.hidePassword;
  }
  formSubmit() {
    console.log('Submit');
    this.submitted = true;
    if (this.submitted && this.loginForm.valid) {
      this.submitLogin.emit(this.loginForm.value);
    }
  }

}
