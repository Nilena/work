import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcFabButtonComponent } from './wbc-fab-button.component';

describe('WbcFabButtonComponent', () => {
  let component: WbcFabButtonComponent;
  let fixture: ComponentFixture<WbcFabButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcFabButtonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcFabButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
