export interface FabButton {
    icon: string,
    toolTipText?: string,
    customClass?: string,
    IsSvgIcon?: boolean
    action: string,
}