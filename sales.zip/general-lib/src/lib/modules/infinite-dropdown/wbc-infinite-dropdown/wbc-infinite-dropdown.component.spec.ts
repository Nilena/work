import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcInfiniteDropdownComponent } from './wbc-infinite-dropdown.component';

describe('WbcInfiniteDropdownComponent', () => {
  let component: WbcInfiniteDropdownComponent;
  let fixture: ComponentFixture<WbcInfiniteDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcInfiniteDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcInfiniteDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
