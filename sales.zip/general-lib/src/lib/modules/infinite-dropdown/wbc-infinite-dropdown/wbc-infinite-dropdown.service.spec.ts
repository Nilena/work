import { TestBed } from '@angular/core/testing';

import { WbcInfiniteDropdownService } from './wbc-infinite-dropdown.service';

describe('WbcInfiniteDropdownService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcInfiniteDropdownService = TestBed.get(WbcInfiniteDropdownService);
    expect(service).toBeTruthy();
  });
});
