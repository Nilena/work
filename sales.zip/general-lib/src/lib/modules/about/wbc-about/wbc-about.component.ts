import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'lib-wbc-about',
  templateUrl: './wbc-about.component.html',
  styleUrls: ['./wbc-about.component.css']
})
export class WbcAboutComponent implements OnInit {
  gudid: string;
  releaseId: string;
  releaseDate: string;
  title: string;
  subtitle_product: string;
  subtitile_model: string;
  subtitile_version: string;
  subtitile_release_date: string;
  subtitile_device_id: string;
  subtitile_device_class: string;
  subtitile_manufacured: string;
  subtitile_contacts: string;
  aboutConfig: any;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}

  ngOnInit() {
    this.gudid = this.data.gudid;
    this.releaseId = this.data.releaseId;
    this.releaseDate = this.data.releaseDate;
    this.aboutConfig = this.data.aboutConfig;
    this.title=this.data.title;
    this.subtitle_product=this.data.subtitle_product;
    this.subtitile_model=this.data.subtitile_model;
    this.subtitile_version=this.data.subtitile_version;
    this.subtitile_release_date=this.data.subtitile_release_date;
    this.subtitile_device_id=this.data.subtitile_device_id;
    this.subtitile_device_class=this.data.subtitile_device_class;
    this.subtitile_manufacured=this.data.subtitile_manufacured;
    this.subtitile_contacts=this.data.subtitile_contacts;
  }
}
