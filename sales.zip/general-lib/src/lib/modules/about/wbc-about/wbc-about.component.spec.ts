import { ComponentFixture, TestBed } from '@angular/core/testing';
import { WbcAboutComponent } from './wbc-about.component';
describe('WbcAboutComponent', () => {
  let component: WbcAboutComponent;
  let fixture: ComponentFixture<WbcAboutComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcAboutComponent ]
    })
    .compileComponents();
  });
  beforeEach(() => {
    fixture = TestBed.createComponent(WbcAboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});