import { Component, OnInit, ViewChild, Output, Input, EventEmitter, SimpleChanges } from '@angular/core';
import { MatMenu } from '@angular/material/menu';

@Component({
  selector: 'lib-wbc-menu-popup',
  templateUrl: './wbc-menu-popup.component.html',
  styleUrls: ['./wbc-menu-popup.component.css']
})
export class WbcMenuPopupComponent implements OnInit {
  @ViewChild(MatMenu, {static: true}) menu: MatMenu;
  //@ViewChild('MatMenu', {static: true}) public MatMenu: any;
  @Output() itemClicked = new EventEmitter<{ title: string }>();
  @Input() menuList : any = [];
  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges(changes : SimpleChanges){
    this.menuList = changes?.menuList?.currentValue;
  }
  onItemClick(val : string) {
    this.itemClicked.emit({ title: val });
  }

}
