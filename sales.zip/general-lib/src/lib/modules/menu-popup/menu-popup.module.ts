import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcMenuPopupComponent } from './wbc-menu-popup/wbc-menu-popup.component';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [
    WbcMenuPopupComponent
  ],
  imports: [
    CommonModule,
    MatMenuModule,
    MatIconModule
  ],
  exports:[WbcMenuPopupComponent]
})
export class MenuPopupModule { }