import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcForgotPasswordEmailComponent } from './wbc-forgot-password-email.component';

describe('WbcForgotPasswordEmailComponent', () => {
  let component: WbcForgotPasswordEmailComponent;
  let fixture: ComponentFixture<WbcForgotPasswordEmailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcForgotPasswordEmailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcForgotPasswordEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set submitted to true', () => {
    component.onEmailSubmit();
    expect(component.submitted).toBeTruthy();
  });

  it('should emit an email sent event',() => {
    spyOn(component.emailSentEvent, 'emit');
    component.ForgotPasswordEmailForm.setValue({ email:'ajay@gmail.com' });
    component.onEmailSubmit();
    expect(component.emailSentEvent.emit).toHaveBeenCalled()
  })
});
