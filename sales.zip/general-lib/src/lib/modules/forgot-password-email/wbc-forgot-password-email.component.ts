import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'lib-wbc-forgot-password-email',
  templateUrl: './wbc-forgot-password-email.component.html',
  styleUrls: ['./wbc-forgot-password-email.component.css'],
})
export class WbcForgotPasswordEmailComponent implements OnInit {
  public submitted = false;
  public ForgotPasswordEmailForm!: FormGroup;
  isLoading: boolean = false;
  @Input() authTitle!: string;
  @Input() forgotImage!: string;
  @Input() authTitleDesc!: string;
  @Input() forgotEmailLabel!: string;
  @Input() forgotEmailPlaceholder!: string;
  @Input() forgotEmailrequiredText!: string;
  @Input() forgotEmailPatternErrText!: string;
  @Input() forgotEmailPattern!: string;
  @Input() btnLabel!: string;

  @Output() emailSentEvent = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder // private toasterService:ToastrService,
  ) {}

  ngOnInit(): void {
    this.initiForgotPasswordForm();
  }

  initiForgotPasswordForm() {
    this.ForgotPasswordEmailForm = this.formBuilder.group({
      email: [
        '',
        [Validators.required, Validators.pattern(this.forgotEmailPattern)],
      ],
    });
  }

  onEmailSubmit() {
    this.submitted = true;
    console.log(this.ForgotPasswordEmailForm.value);
    if (this.ForgotPasswordEmailForm.valid) {
      this.emailSentEvent.emit(this.ForgotPasswordEmailForm.value);
    }
  }
}
