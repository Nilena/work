import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcEventTimelineComponent } from './wbc-event-timeline/wbc-event-timeline.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    WbcEventTimelineComponent
  ],
  imports: [
    CommonModule,
    MatIconModule
  ],
  exports:[
    WbcEventTimelineComponent 
  ]
})
export class TimelineModule { }
