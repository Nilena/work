import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcEventTimelineComponent } from './wbc-event-timeline.component';

describe('WbcEventTimelineComponent', () => {
  let component: WbcEventTimelineComponent;
  let fixture: ComponentFixture<WbcEventTimelineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcEventTimelineComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcEventTimelineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
