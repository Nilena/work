import { Component, OnInit, Input ,EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'lib-wbc-search-field',
  templateUrl: './wbc-search-field.component.html',
  styleUrls: ['./wbc-search-field.component.css']
})
export class WbcSearchFieldComponent implements OnInit {

  constructor() { }
  @Input() searchLabel :string;
  @Output() filterChange = new EventEmitter<string>();
  @Input() searchValue;

  ngOnInit() {
  }
  applyFilter(){
    this.filterChange.emit(this.searchValue);
  }

}
