import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcSearchFieldComponent } from './wbc-search-field/wbc-search-field.component';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [WbcSearchFieldComponent],
  imports: [
    CommonModule,
    MatInputModule,
    MatIconModule,
    FormsModule
  ],
  exports:[WbcSearchFieldComponent]
})
export class SearchFieldModule { }
