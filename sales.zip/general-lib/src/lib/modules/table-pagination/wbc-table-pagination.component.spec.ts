import {
  SimpleChanges,
} from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatTableModule } from '@angular/material/table';
import { TableColumnDirective } from './table-column.directive';

import { WbcTablePaginationComponent } from './wbc-table-pagination.component';

interface IUser{
  name:string;
  age:number
}

describe('WbcTableComponent', () => {
  let component: WbcTablePaginationComponent<IUser>;
  let fixture: ComponentFixture<WbcTablePaginationComponent<IUser>>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MatTableModule],
      declarations: [WbcTablePaginationComponent],
    }).compileComponents();

    fixture = TestBed.createComponent<WbcTablePaginationComponent<IUser>>(WbcTablePaginationComponent);

    component.columnConfig = [
      { field: 'name', header: 'Name', isTemplate: false },
      { field: 'age', header: 'Age', isTemplate: false },
    ];
    component.tableData = [
      { name: 'User one', age: 30 },
      { name: 'User two', age: 25 },
    ];

    component.paginator = {
      length: 10,
    } as any;
    component.totalLength = 10;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set default values', () => {
    expect(component.pageIndex).toBe(1);
    expect(component.pageSize).toBe(10);
  });

  it('should set columnConfig and tableData', () => {
    component.columnConfig = [
      { field: 'name', header: 'Name', isTemplate: false },
      { field: 'age', header: 'Age', isTemplate: false },
    ];
    component.tableData = [
      { name: 'user one', age: 30 },
      { name: 'user two', age: 25 },
    ];
    component.ngOnInit();
    expect(component.displayedColumns).toEqual(['name', 'age']);
    expect(component.dataSource.data).toEqual(component.tableData);
  });

  it('should handle ngOnChanges correctly', () => {
    const changes: SimpleChanges = {
      tableData: {
        currentValue: [{}, {}, {}],
        previousValue: [{}, {}],
        firstChange: false,
        isFirstChange: () => false,
      },
      hasNextPage: {
        currentValue: true,
        previousValue: true,
        firstChange: false,
        isFirstChange: () => false,
      },
    };

    component.ngOnChanges(changes);

    fixture.detectChanges();
    expect(component.dataSource.data).toEqual(component.tableData);
  });

  describe('htmlTemplate', () => {
    it('should render the table title correctly', () => {
      component.title = 'Test Title';
      fixture.detectChanges();
      const titleElement = fixture.nativeElement.querySelector('.table-title');
      expect(titleElement.textContent).toContain('Test Title');
    });

    it('should project table filter content correctly', () => {
      // Provide the table filter content
      const tableFilterContent = '<div tableFilter>Filter Content</div>';

      // Set the content via innerHTML
      fixture.nativeElement.querySelector('.table-title-header').innerHTML =
        tableFilterContent;

      // Trigger change detection
      fixture.detectChanges();

      // Verify that the content is projected correctly
      const projectedContent =
        fixture.nativeElement.querySelector('[tableFilter]');
      expect(projectedContent).toBeTruthy();
      expect(projectedContent.textContent).toContain('Filter Content');
    });

    it('should render header cells correctly', () => {
      const headerCells = fixture.nativeElement.querySelectorAll('th');
      expect(headerCells.length).toBe(2); // Assuming there are 2 columns in columnConfig
      expect(headerCells[0].textContent).toContain('Name');
      expect(headerCells[1].textContent).toContain('Age');
    });

    it('should render data cells correctly', () => {
      const dataCells = fixture.nativeElement.querySelectorAll('td');
      expect(dataCells.length).toBe(4); // 2 rows x 2 columns
      expect(dataCells[0].textContent).toContain('User one');
      expect(dataCells[1].textContent).toContain('30');
    });
  });

  describe('setPageSize', () => {
    it('should handle setPageSize', () => {
      spyOn(component.pageChangeEvent, 'emit');
      component.hasNextPage = true;
      component.dataSource.data = [{}, {}, {}, {}];
      component.setPageSize({
        pageIndex: 1,
        previousPageIndex: 0,
        pageSize: 4,
        length: 10,
      });
      expect(component.pageChangeEvent.emit).toHaveBeenCalledWith({
        pageSize: 4,
        pageIndex: 2,
      });
    });
    it('should not emit pageChangeEvent when pageIndex is not greater than previousPageIndex', () => {
      const event = {
        pageIndex: 1,
        previousPageIndex: 2,
        pageSize: 10,
        length: 10,
      };
      const emitSpy = spyOn(component.pageChangeEvent, 'emit');
      component.setPageSize(event);

      expect(emitSpy).not.toHaveBeenCalled();
    });

    it('should not emit pageChangeEvent when hasNextPage is false', () => {
      component.hasNextPage = false;
      const event = {
        pageIndex: 2,
        previousPageIndex: 1,
        pageSize: 10,
        length: 30,
      };
      const emitSpy = spyOn(component.pageChangeEvent, 'emit');

      component.setPageSize(event);

      expect(emitSpy).not.toHaveBeenCalled();
    });

    it('should not emit pageChangeEvent when pageIndex * pageSize is less than data length', () => {
      const event = {
        pageIndex: 1,
        previousPageIndex: 0,
        pageSize: 1,
        length: 30,
      };
      const emitSpy = spyOn(component.pageChangeEvent, 'emit');

      component.setPageSize(event);

      expect(emitSpy).not.toHaveBeenCalled();
    });

    it('should update paginator length and totalLength when pageIndex * pageSize equals data length (exact match)', () => {
      const event = {
        pageIndex: 1,
        previousPageIndex: 0,
        pageSize: 1,
        length: 10,
      };
      component.paginator = {
        length: 10,
      } as any;
      component.hasNextPage = true;

      fixture.detectChanges();

      component.setPageSize(event);

      expect(component.paginator.length).toBe(12); //dataSoure?.data?.length + 10
      expect(component.totalLength).toBe(12); //dataSoure?.data?.length + 10
    });
  });

  describe('ngOnChange', () => {
    it('should update paginator length and totalLength when tableData changes when hasNextNextPage is false', async () => {
      const changes: SimpleChanges = {
        tableData: {
          currentValue: [{}, {}, {}],
          previousValue: [{}, {}],
          firstChange: false,
          isFirstChange: () => false,
        },
        hasNextPage: {
          currentValue: true,
          previousValue: true,
          firstChange: false,
          isFirstChange: () => false,
        },
      };
      component.paginator = {
        length: 10,
      } as any;

      await component.ngOnChanges(changes);

      expect(component.paginator.length).toBe(3); // Replace with your expected value
      expect(component.totalLength).toBe(3); // Replace with your expected value
    });

    it('should update paginator length and totalLength when tableData changes when hasNextPage is true', async () => {
      const changes: SimpleChanges = {
        tableData: {
          currentValue: [{}, {}, {}],
          previousValue: [{}, {}],
          firstChange: false,
          isFirstChange: () => false,
        },
        hasNextPage: {
          currentValue: true,
          previousValue: true,
          firstChange: false,
          isFirstChange: () => false,
        },
      };
      component.paginator = {
        length: 10,
        pageIndex: 1,
        pageSize: 1,
      } as any;
      component.hasNextPage = true;

      await component.ngOnChanges(changes);

      expect(component.paginator.length).toBe(3); // Replace with your expected value
      expect(component.totalLength).toBe(3); // Replace with your expected value
    });
  });

  it('should populate columnTemplateMap on ngAfterContentInit', () => {
    const column1 = new TableColumnDirective({} as any);
    column1.columnName = 'column1';

    const column2 = new TableColumnDirective({} as any);
    column2.columnName = 'column2';

    const column3 = new TableColumnDirective({} as any);
    column3.columnName = 'column3';

    component.columnList.reset([column1, column2, column3]);

    spyOn(component.columnTemplateMap, 'set');

    fixture.detectChanges();

    component.ngAfterContentInit();

    expect(component.columnList.length).toBe(3);
    expect(component.columnList.toArray()).toEqual([column1, column2, column3]);

    expect(component.columnList.first.columnName).toBe('column1');
    expect(component.columnList.last.columnName).toBe('column3');
  });
});
