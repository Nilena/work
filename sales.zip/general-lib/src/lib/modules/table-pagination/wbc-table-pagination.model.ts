export interface IcolumnConfig {
  field: string;
  header: string;
  isTemplate: boolean;
  headerTemplate?: boolean;
}
