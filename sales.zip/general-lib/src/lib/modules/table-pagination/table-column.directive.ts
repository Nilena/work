import { Directive, Input, TemplateRef } from '@angular/core';

@Directive({
  selector: '[libTableColumn]',
})

/**
* 
* @description
* How to Use
*
* 1. Import `TableColumnDirective` to your module.
*
* 2. Create an element in your template with the directive `[libTableColumn]`.
*
* 3. Bind the `columnName` input with the desired name for your column.
*
* 4. Nest your dynamic content inside this element. This is where the magic happens!
*
* <strong>Example</strong>
*
* ```typescript
* import { TableColumnDirective } from '../../';
*
* @Component({
*   template: `
*     <ng-container *ngFor="let item of items">
*       <ng-template libTableColumn tableColumn="item">
*         <!-- Your dynamic content goes here -->
*       </ng-template>
*     </ng-container>
*   `
* })
* export class MyTableComponent {
*   items = [
*     { name: 'Column A' },
*     { name: 'Column B' },
*     { name: 'Column C' }
*   ];
* }
* ```
*
*/
export class TableColumnDirective {
  constructor(public readonly template: TemplateRef<any>) {}

  @Input('tableColumn') columnName!: string;
}
