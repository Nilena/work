import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcTablePaginationComponent } from './wbc-table-pagination.component';
import {MatTableModule} from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatButtonModule} from '@angular/material/button';
import { TableColumnDirective } from './table-column.directive';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSortModule } from '@angular/material/sort';
import { MatTooltipModule } from '@angular/material/tooltip';
@NgModule({
  declarations: [
    WbcTablePaginationComponent,
    TableColumnDirective
  ],
  imports: [
    CommonModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatCheckboxModule,
    MatSortModule,
    MatTooltipModule
  ],
  exports:[
    WbcTablePaginationComponent,
    TableColumnDirective
  ],

})
export class WbcTablePaginationModule { }
