import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcActionCardComponent } from './wbc-action-card.component';

describe('WbcReporteeCardComponent', () => {
  let component: WbcActionCardComponent;
  let fixture: ComponentFixture<WbcActionCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcActionCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcActionCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
