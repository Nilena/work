import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcOverlappingCardComponent } from './wbc-overlapping-card.component';

describe('WbcOverlappingCardComponent', () => {
  let component: WbcOverlappingCardComponent;
  let fixture: ComponentFixture<WbcOverlappingCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcOverlappingCardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcOverlappingCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
