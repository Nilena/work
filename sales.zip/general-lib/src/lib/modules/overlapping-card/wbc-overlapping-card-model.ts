import { TemplateRef } from "@angular/core";
import { FabButton } from "../fab-button/wbc-fab-button-model";

export interface OverlappingCard {
    title?: string,
    footerActions?: FabButton[],
    customClass?: string,
}
