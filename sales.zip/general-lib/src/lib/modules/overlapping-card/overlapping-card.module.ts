import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcOverlappingCardComponent } from './wbc-overlapping-card/wbc-overlapping-card.component';
import { WbcFabButtonModule } from '../fab-button/fab-button.module';



@NgModule({
  declarations: [
    WbcOverlappingCardComponent
  ],
  imports: [
    CommonModule,
    WbcFabButtonModule
  ],
  exports: [WbcOverlappingCardComponent]
})
export class WbcOverlappingCardModule { }
