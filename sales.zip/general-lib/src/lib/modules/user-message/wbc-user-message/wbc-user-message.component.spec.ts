import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcUserMessageComponent } from './wbc-user-message.component';

describe('WbcUserMessageComponent', () => {
  let component: WbcUserMessageComponent;
  let fixture: ComponentFixture<WbcUserMessageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcUserMessageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcUserMessageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
