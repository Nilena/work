import { Component, Input, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { LIB_CONSTANT } from '../../general-lib-constants.enum';
import { WbcSnackbarService } from '../../services/wbc-snackbar.service';

@Component({
  selector: 'lib-copy-to-clipboard',
  templateUrl: './copy-to-clipboard.component.html',
  styleUrls: ['./copy-to-clipboard.component.css']
})
export class CopyToClipboardComponent implements OnInit {
  @Input() text: string;
  constructor(
    private sanitizer: DomSanitizer,
    private iconRegistry: MatIconRegistry,
    private snackBarService: WbcSnackbarService
  ) {
    this.iconRegistry.addSvgIcon(
      'copy-to-clipboard',
      this.sanitizer.bypassSecurityTrustResourceUrl(
        'assets/icons/copy_icon.svg'
      )
    );
  }

  ngOnInit(): void {}

  /**
   * Copies the content of the 'text' property to the clipboard.
   *
   * @param event - The event that triggered the copy operation.
   * @throws If the 'document.execCommand' is not supported or the copy operation fails.
   */
  copyTextToClipboard(event) {
    event.stopPropagation();
    event.preventDefault();
    if (this.text === '') {
      this.snackBarService.openSnackbar(
        LIB_CONSTANT.NOTHING_TO_COPY,
        'warning'
      );
    } else {
      var textarea = document.createElement('textarea');
      textarea.value = this.text;
      document.body.appendChild(textarea);
      textarea.select();

      try {
        document.execCommand('copy');
        document.body.removeChild(textarea);
        this.snackBarService.openSnackbar(
          LIB_CONSTANT.COPY_TO_CLIPBOARD_SUCCESS,
          'success'
        );
      } catch (error) {
        document.body.removeChild(textarea);

        this.snackBarService.openSnackbar(
          LIB_CONSTANT.COPY_TO_CLIPBOARD_ERROR,
          'error'
        );
      }
    }
  }
}
