/**
 * Component representing a bidirectional skip control.
 */
import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-bidirectional-skip',
  templateUrl: './wbc-bidirectional-skip.component.html',
  styleUrls: ['./wbc-bidirectional-skip.component.css']
})
export class WbcBidirectionalSkipComponent implements OnInit {
  /**
   * Event emitter for handling skip actions.
   * Emits a number indicating the skip direction (+1 for next, -1 for previous).
   */
  @Output() handleSkip = new EventEmitter<number>();

  constructor() {}

  ngOnInit(): void {}

  /**
   * Emits a skip action indicating a forward movement.
   */
  emitNext() {
    this.handleSkip.emit(+1);
  }

  /**
   * Emits a skip action indicating a backward movement.
   */
  emitPrev() {
    this.handleSkip.emit(-1);
  }
}
