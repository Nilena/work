import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { WbcBidirectionalSkipComponent } from './wbc-bidirectional-skip.component';

describe('WbcBidirectionalSkipComponent', () => {
  let component: WbcBidirectionalSkipComponent;
  let fixture: ComponentFixture<WbcBidirectionalSkipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcBidirectionalSkipComponent ],
      imports: [MatButtonModule, MatIconModule]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcBidirectionalSkipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit prev event on clicking left icon', () => {
    spyOn(component.handleSkip, 'emit');
    const prevButton = fixture.nativeElement.querySelector('.skip_btn:first-child');
    prevButton.click();
    expect(component.handleSkip.emit).toHaveBeenCalledWith(-1);
  });

  it('should emit next event on clicking right icon', () => {
    spyOn(component.handleSkip, 'emit');
    const nextButton = fixture.nativeElement.querySelector('.skip_btn:last-child');
    nextButton.click();
    expect(component.handleSkip.emit).toHaveBeenCalledWith(1);
  });
});
