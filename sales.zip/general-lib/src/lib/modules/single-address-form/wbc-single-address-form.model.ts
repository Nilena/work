import { IWbcIcon } from "../double-sided-cotainer/wbc-double-sided-cotainer.model";

export interface IAddressText {
    title: string;
    subTitle: string;
}

export interface IWbcAddressDetail {
    id: string;
    addressFields: string;
    address: IAddressText[];
    ribbonValue: string;
}

export interface IWbcCount {
    count: number;
    tooltip: string;
}

export interface IWbcAddressCardDetails {
    title: string;
    footerActions: {
        icon: string,
        toolTipText: string,
        customClass: string,
        IsSvgIcon: boolean,
        action: string,
    }[]
}
export interface IWbcAddressCardDetails {
    title: string;
    footerActions: {
        icon: string;
        toolTipText: string;
        customClass: string;
        IsSvgIcon: boolean;
        action: string;
    }[];
}

export interface IWbcFooter {
    icon: IWbcIcon;
    title: string;
    chipText: string;
}
