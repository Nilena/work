import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';

import { of as observableOf } from 'rxjs';

import { catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WbcImgHandlerService {
  constructor(private sanitizer: DomSanitizer, private http: HttpClient) {}

  /**
   * Function to convert url to blob
   * @param {string} url url to be converted to blob
   * @returns {Blob | string} converted blob or string
   */
  convertUrlToBlob(url: string) {
    return this.http.get(url, { responseType: 'blob' }).pipe(
      map((x: any) => {
        return x;
      }),
      catchError((err) =>
        observableOf(err).pipe(
          map((err) => {
            return '';
          })
        )
      )
    );
  }

  /**
   * Function to read local file
   * @param {Blob} file file to read data from
   * @returns local url of file
   */
  async readBlobFile(file: Blob): Promise<string> {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        resolve(reader.result as string);
      };
      reader.onerror = () => {
        reject(reader.error);
      };
      reader.readAsDataURL(file);
    });
  }

  /**
   * Function to convert blob to localUrl
   * @param {Blob} blob blob to convert to local url
   * @returns localImageUrl to be accessed from component
   */
  async convertBlobToLocalUrl(blob: Blob, local_file_access: Boolean) {
    let localImgUrl;
    //condition to check for server/local file access
    if (local_file_access) {
      localImgUrl = await this.readBlobFile(blob);
    } else {
      const localUrl = await this.readBlobFile(blob);
      localImgUrl = await this.sanitizer.bypassSecurityTrustUrl(localUrl);
    }
    return localImgUrl;
  }
}
