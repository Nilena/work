import { Injectable } from '@angular/core';
import { WbcLocalStorageService } from './wbc-local-storage.service';
//import cryptoBrowserify from 'crypto-browserify';
import CryptoJS from 'crypto-js'
@Injectable({
  providedIn: 'root'
})
export class WbcPkceService {

  constructor(private storageService : WbcLocalStorageService) { }



  getCodeVerifier(verifierKey:string) {
    let verfier = this.storageService.retrieveItem(verifierKey);
    if (verfier) {
      //this.storageService.removeItem(verifierKey);
    } else {
   //   verfier = this.base64URLEncode(cryptoBrowserify.randomBytes(32));
      verfier = this.strRandom(128);
      this.storageService.storeItem(verifierKey, verfier);
    }
    return verfier;
  }



 base64URLEncode(str){
    return str.toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=/g, '');
 }
  
  
 sha256(buffer) {
  //return cryptoBrowserify.createHash('sha256').update(buffer).digest();
 }
  
  
  getCodeChallenge(verifier) {
    let codeChallenge = CryptoJS.SHA256(verifier).toString(CryptoJS.enc.Base64);
    return  codeChallenge
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
  }


  strRandom(length: number) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}
}
