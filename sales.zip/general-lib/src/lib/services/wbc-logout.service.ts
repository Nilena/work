import { Injectable } from '@angular/core';
import { WbcAjaxService } from './wbc-ajax.service';
import { catchError, map } from 'rxjs/operators';
import { of as observableOf, Observable, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
import { WbcAuthService } from './wbc-auth.service';
import { WbcOauthService } from './wbc-oauth.service';

@Injectable({
  providedIn: 'root'
})
export class WbcLogoutService {

  constructor(
    private ajaxService: WbcAjaxService, 
    private authService: WbcAuthService,
    private oauthService: WbcOauthService ) { }


  logout(spinner, appData: { token: string, apiBaseUrl: string }, appConfig) {
    return this.ajaxService.postRequest({}, "logout", appData, spinner).pipe(
      map(res => {
        let response: any = res;
        if (response.result == "success") {
          this.oauthService.userLogout(appConfig);

          return { success: true, offline: false }
        }
        else {
          return { success: false, offline: false }

        }
      }
      ), catchError(err => observableOf(err).pipe(map(err => {

        if (!navigator.onLine && err.statusText == "Unknown Error") {
          return { success: false, offline: true }
        }
        else {
          return { success: false, offline: false }

        }
      }))))
  }
}
