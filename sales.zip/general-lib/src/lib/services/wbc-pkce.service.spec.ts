import { TestBed } from '@angular/core/testing';

import { WbcPkceService } from './wbc-pkce.service';

describe('WbcPkceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcPkceService = TestBed.get(WbcPkceService);
    expect(service).toBeTruthy();
  });
});
