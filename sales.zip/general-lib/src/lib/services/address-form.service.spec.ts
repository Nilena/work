import { TestBed } from '@angular/core/testing';
import { AddressFormService } from './address-form.service';
import { WbcAjaxService } from './wbc-ajax.service';
import { of } from 'rxjs';
import { LIB_CONSTANT } from '../general-lib-constants.enum';

describe('AddressFormService', () => {
  let service: AddressFormService;
  let ajaxServiceSpy: jasmine.SpyObj<WbcAjaxService>;
  beforeEach(() => {
    const spy = jasmine.createSpyObj('WbcAjaxService', ['getWithRoutePath']);
    TestBed.configureTestingModule({
      providers: [
        AddressFormService,
        { provide: WbcAjaxService, useValue: spy }
      ]
    });
    service = TestBed.inject(AddressFormService);
    ajaxServiceSpy = TestBed.inject(WbcAjaxService) as jasmine.SpyObj<WbcAjaxService>;

    // Mock the return value of getWithRoutePath
    ajaxServiceSpy.getWithRoutePath.and.returnValue(of({}));
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });


  it('should return success message and data for successful geoLocations call', () => {
    const apiConfig = {
      operations: '/api/locations',
      routePath: '/sfa',
      apiBaseUrl: 'https://example.com'
    };
    const mockResponse = { someData: 'value' };
    ajaxServiceSpy.getWithRoutePath.and.returnValue(of(mockResponse));
    service.geoLocations(apiConfig, 'country').subscribe((res) => {
      expect(res.message).toBe('success');
      expect(res.data).toEqual(mockResponse);
    });
  });


  it('should return success message and data for successful geoLocationUnderFieldstaff call', () => {
    const apiConfig = {
      operations: '/api/locations',
      routePath: '/sfa',
      apiBaseUrl: 'https://example.com'
    };
    const mockResponse = { someData: 'value' };
    ajaxServiceSpy.getWithRoutePath.and.returnValue(of(mockResponse));
    service.geoLocationUnderFieldstaff(apiConfig).subscribe((res) => {
      expect(res.message).toBe('success');
      expect(res.data).toEqual(mockResponse);
    });
  });


  it('should call ajaxService with correct path for geoLocations', () => {
    // Arrange
    const apiConfig = {
      operations: '/api/locations',
      routePath: '/sfa',
      apiBaseUrl: 'https://webcardio.com'
    };
    const path = 'country';
    const expectedUrl = `${apiConfig.operations}?country=India`;

    spyOn(service, 'getPathName').and.returnValue(expectedUrl);
    service.geoLocations(apiConfig, path, 'India').subscribe();

    expect(ajaxServiceSpy.getWithRoutePath).toHaveBeenCalledWith(
      expectedUrl,
      { token: null, apiBaseUrl: apiConfig.apiBaseUrl },
      apiConfig.routePath,
      jasmine.any(Object)
    );
  });

  it('should call ajaxService with correct path for geoLocationUnderFieldstaff', () => {
    const apiConfig = {
      operations: '/api/locations',
      routePath: '/sfa',
      apiBaseUrl: 'https://webcardio.com'
    };
    const expectedUrl = apiConfig.operations;

    service.geoLocationUnderFieldstaff(apiConfig).subscribe();
    expect(ajaxServiceSpy.getWithRoutePath).toHaveBeenCalledWith(
      expectedUrl,
      { token: null, apiBaseUrl: apiConfig.apiBaseUrl },
      apiConfig.routePath,
      jasmine.any(Object)
    );
  });
  it('should return correct URL path for different cases', () => {
    const apiConfig = {
      operations: '/api/locations',
      routePath: '/sfa',
      apiBaseUrl: 'https://webcardio.com'
    };

    const countryPath = service.getPathName(apiConfig, 'country');
    expect(countryPath).toBe(apiConfig.operations);

    const statePathWithCountry = service.getPathName(apiConfig, 'state', 'India');
    expect(statePathWithCountry).toBe(`${apiConfig.operations}?country=India`);

    const statePathWithoutCountry = service.getPathName(apiConfig, 'state');
    expect(statePathWithoutCountry).toBeUndefined();

    const distPathWithCountryAndState = service.getPathName(apiConfig, 'dist', 'India', 'Kerala');
    expect(distPathWithCountryAndState).toBe(`${apiConfig.operations}?country=India&state=Kerala`);

    const distPathWithCountryOnly = service.getPathName(apiConfig, 'dist', 'India');
    expect(distPathWithCountryOnly).toBeUndefined();

    const distPathWithoutCountryAndState = service.getPathName(apiConfig, 'dist');
    expect(distPathWithoutCountryAndState).toBeUndefined();
  });
});