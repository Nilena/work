import { of as observableOf, Observable, BehaviorSubject } from 'rxjs';

import { catchError, map } from 'rxjs/operators';
import { Injectable, ElementRef } from '@angular/core';

import { WbcSpinnerService } from './wbc-spinner.service';
import { WbcAjaxService } from './wbc-ajax.service';

import { WbcUserSessionService } from './wbc-user-session.service';
import { WbcRedirectionService } from './wbc-redirection.service';
import { MatDialog } from '@angular/material/dialog';
import { WbcActionDialogComponent } from '../modules/action-dialog/wbc-action-dialog/wbc-action-dialog.component';

import { LIB_CONSTANT } from '../general-lib-constants.enum';
import { WbcLocalStorageService } from './wbc-local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class WbcAuthService {
  /**
   * logged in bahaviour subject
   */
  private loggedIn = new BehaviorSubject<boolean>(false);
  /**
   * Constructor WBCAuthService
   * @param ajaxService ajaxService injected to utilize the http
   */
  constructor(
    private ajaxService: WbcAjaxService,
    private spinnerService: WbcSpinnerService,
    private userSessionService: WbcUserSessionService,
    private redirectionService: WbcRedirectionService,
    private localStorageService: WbcLocalStorageService,
    private dialog: MatDialog
  ) {}
  /**
   * Responsible for autheticating the user
   * @param email Username of the user for the authetication
   * @param password Password of the user for authetication
   * @example Simply call this method with username and password
   * authenticate('username','password')
   * @returns "Login Failed" message incase of failed attempt.
   *  Navigate to Landing page if the attempt is successful.
   */
  authenticate(
    email: string,
    password: string,
    element: ElementRef,
    appData: { token: string; apiBaseUrl },
    appKey: string,
    userTypes: Array<number>
  ) {
    return this.ajaxService
      .postRequest({ email: email, password: password }, 'login', appData, {
        spinner: true,
        elementToReplace: element
      })
      .pipe(
        map((res) => {
          let response: any = res;
          console.log('the response', response);
          if (
            response.result == 'success' &&
            userTypes.indexOf(response.user_type) != -1
          ) {
            this.userSessionService.setUsersessionDetails(appKey, response);
            this.setLoggedIn(true);
            this.spinnerService.hideSpinnerReplaceElement(element);
            return { success: true, offline: false };
          } else {
            this.spinnerService.hideSpinnerReplaceElement(element);
            return { success: false, offline: false };
          }
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              console.log('the err', err);
              this.spinnerService.hideSpinnerReplaceElement(element);
              if (navigator && !navigator.onLine) {
                return { success: false, offline: true };
              } else {
                return { success: false, offline: false };
              }
            })
          )
        )
      );
  }

  /**
   * Responsible to check whether there is an active user session or not.
   * @returns observable wrapping a boolean true when there is a session
   */
  isLoggedIn(appKey: string, userTypes: Array<number>): Observable<boolean> {
    if (this.userSessionService.isValidSession(appKey, userTypes)) {
      console.log('has session');
      this.loggedIn.next(true);
      return this.loggedIn.asObservable();
    } else {
      this.setLoggedIn(false);
      return this.loggedIn.asObservable();
    }
  }

  /**
   * Responsible for setting session when user logged In.
   */
  setLoggedIn(type) {
    this.loggedIn.next(type);
  }

  removeUserSession(appKey: string) {
    this.userSessionService.clearUserSession(appKey);
    this.setLoggedIn(false);
  }

  passwordExpiryWarning = (appConfig) => {
    let TOKEN = appConfig.env;
    let CREDENTIALS = this.localStorageService.retrieveObject(TOKEN);

    let setTime = +CREDENTIALS.password_set_time;
    let expiryDays = +CREDENTIALS.password_expiry_days;
    let expiryTime = setTime + expiryDays * 84600000;

    if (
      Date.parse(new Date(expiryTime).toLocaleString()) <
      Date.parse(new Date().toLocaleString())
    ) {
      this.resetPassword(appConfig);
    } else if (CREDENTIALS.show_password_alert == true) {
      let dialogRef = this.dialog.open(WbcActionDialogComponent, {
        height: '200px',
        width: '600px'
      });
      let instance = dialogRef.componentInstance;
      let expiryDateString = new Date(expiryTime).toLocaleString();
      instance.message = `${LIB_CONSTANT.PASSWORD_EXPIRES_ON} ${expiryDateString}`;

      instance.leftActionLabel = LIB_CONSTANT.CLOSE;
      let closeSub = instance.leftAction.subscribe(() => {
        dialogRef.close();
      });

      instance.rightActionLabel = LIB_CONSTANT.RESET;
      let resetSub = instance.rightAction.subscribe(() => {
        this.resetPassword(appConfig);
        dialogRef.close();
      });

      dialogRef.afterClosed().subscribe(() => {
        closeSub && closeSub.unsubscribe();
        resetSub && resetSub.unsubscribe();
      });

      CREDENTIALS.show_password_alert = false;
      this.localStorageService.storeObject(TOKEN, CREDENTIALS);
    }
  };

  resetPassword(appConfig) {
    let TOKEN = appConfig.env;
    let CREDENTIALS = this.localStorageService.retrieveObject(TOKEN);
    this.redirectionService.redirectToResetPassword(
      appConfig,
      CREDENTIALS.client_id
    );
  }
}
