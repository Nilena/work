import { TestBed } from '@angular/core/testing';

import { WbcRedirectionService } from './wbc-redirection.service';

describe('WbcRedirectionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcRedirectionService = TestBed.get(WbcRedirectionService);
    expect(service).toBeTruthy();
  });
});
