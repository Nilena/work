import { TestBed } from '@angular/core/testing';

import { WbcOauthService } from './wbc-oauth.service';

describe('WbcOauthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcOauthService = TestBed.get(WbcOauthService);
    expect(service).toBeTruthy();
  });
});
