import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WbcHTMLCSSTemplateService {

  constructor(@Inject(DOCUMENT) private document: Document,
  ) { }


  /**
   * 
   * @param componentSelector 
   * @returns css of that component
   */
  getTemplateCss(componentSelector: string) {
    const styles = this.document.head.querySelectorAll('style')
    let styleText = ''
    for (let i = 0; i < styles.length; i++) {
      const styleElement = styles[i] as HTMLStyleElement;
      if (styleElement.innerText.includes(componentSelector)) {
        styleText = styleElement.innerText
      }
    }
    return styleText
  }
  /**
     * @param content 
     * @param title 
     * @param css 
     * @returns css of that component
     */

  async getTemplateHtmlWithCss(content: string, title: string, css: string) {
    const frame1 = document.createElement('iframe');
    frame1.name = 'frame1';
    frame1.style.position = 'absolute';
    frame1.style.top = '-999em';
    frame1.style.left = '-999em';
    document.body.appendChild(frame1);
    const frameDoc = frame1.contentWindow;
    frameDoc?.document.open();
    frameDoc?.document.write(`
        <html>
            <head>
                <title>
                    ${title}
                </title>
                <style>
                    ${css}
                </style>`);
    frameDoc?.document.write('</head><body>');
    frameDoc?.document.write(content);
    frameDoc?.document.write('</body></html>');
    let htmlStringContent =
      '<html><head>' +
      frameDoc?.document.head.innerHTML +
      '</head><body>' +
      content +
      '</body></html>';
    return htmlStringContent
  }
}
