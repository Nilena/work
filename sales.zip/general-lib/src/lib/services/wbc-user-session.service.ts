import { Injectable } from '@angular/core';
import { WbcUserSession } from '../models/wbc-user-session.model';
import { WbcLocalStorageService } from './wbc-local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class WbcUserSessionService {
  constructor(private localStorageService: WbcLocalStorageService) {}

  /**
   * Responsible for setting the user session
   * @param appKey  key of the localstorage item against which the details to be stored
   * @param apiReponse login/renew token api response;
   */
  setUsersessionDetails(appKey: string, apiReponse) {
    let userInfo: WbcUserSession = {
      token: apiReponse.token,
      email: apiReponse.email,
      name: apiReponse.name,
      expiry_time: apiReponse.expire,
      user_type: apiReponse.user_type,
      show_password_alert: false
    };
    if (apiReponse.hasOwnProperty('uuid')) {
      userInfo.uuid = apiReponse.uuid;
    }
    if (apiReponse.show_password_alert) {
      userInfo.show_password_alert = apiReponse.show_password_alert;
    }
    if (apiReponse.password_set_time) {
      userInfo.password_set_time = apiReponse.password_set_time;
    }
    if (apiReponse.password_expiry_days) {
      userInfo.password_expiry_days = apiReponse.password_expiry_days;
    }
    if (apiReponse.hospital_id) {
      userInfo.hospital_id = apiReponse.hospital_id;
    }
    this.localStorageService.storeObject(appKey, userInfo);
  }

  /**
   * Responsible for getting the user session
   * @param appKey  key of the localstorage item against which the details is stored
   */
  getUserSessionDetails(appKey): WbcUserSession {
    let userSession = this.localStorageService.retrieveObject(appKey);
    return userSession;
  }

  /**
   * Responsible for checking the existence of the valid session
   * @param appKey  key of the localstorage item against which the details is stored
   * @param userType the type of the users allowed.
   */
  isValidSession(appKey: string, userType: Array<number>) {
    let userSession = this.getUserSessionDetails(appKey);
    let currentTime = new Date().getTime();
    if (
      userSession &&
      userSession.token != null &&
      Number(userSession.expiry_time) > currentTime &&
      userType.indexOf(userSession.user_type) != -1
    ) {
      return true;
    } else {
      return false;
    }
  }

  /** 
removes the user session
*/
  clearUserSession(appKey: string) {
    this.localStorageService.removeObject(appKey);
  }

  setUsersessionDetailsOauth(
    key: string,
    decodedToken,
    tokenResponse,
    clientId: string,
    refreshToken: string
  ) {
    let expiryTime = decodedToken.exp * 1000;
    let userType = Number(decodedToken.user_type);
    let credentials: WbcUserSession = {
      email: decodedToken.email,
      token: tokenResponse.id_token,
      refresh_token: refreshToken,
      user_type: userType,
      name: decodedToken.name,
      client_id: clientId,
      expiry_time: expiryTime,
      is_qc: decodedToken.is_qc,

      hospital_id: decodedToken.hospital_id
    };
    if (decodedToken.hasOwnProperty('preferred_file_format')) {
      credentials['preferred_file_format'] = decodedToken.preferred_file_format;
    }
    if (decodedToken.hasOwnProperty('segment')) {
      credentials['segment'] = decodedToken.segment;
    }
    if (decodedToken.hasOwnProperty('signature_name')) {
      credentials['signature_name'] = decodedToken.signature_name;
    }
    if (decodedToken.hasOwnProperty('PK')) {
      credentials['user_id'] = decodedToken.PK;
    }
    if (
      decodedToken.hasOwnProperty('show_password_alert') &&
      decodedToken.show_password_alert
    ) {
      credentials['show_password_alert'] = true;
      credentials['password_set_time'] = decodedToken.password_set_time;
      credentials['password_expiry_days'] = decodedToken.password_expiry_days;
    }
    if (decodedToken.hasOwnProperty('uuid')) {
      credentials['uuid'] = decodedToken.uuid;
    }
    if (decodedToken.hasOwnProperty('advanced_technician')) {
      credentials['advanced_technician'] = decodedToken.advanced_technician;
    } else {
      credentials['advanced_technician'] = false;
    }
    this.localStorageService.storeObject(key, credentials);
  }

  deleteSession(key) {
    this.localStorageService.removeObject(key);
  }
}
