import { TestBed } from '@angular/core/testing';

import { WbcHTMLCSSTemplateService } from './wbc-html-css-template.service';

describe('WbcHTMLCSSTemplateService', () => {
  let service: WbcHTMLCSSTemplateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcHTMLCSSTemplateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
