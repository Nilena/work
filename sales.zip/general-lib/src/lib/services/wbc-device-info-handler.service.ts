import { Injectable } from '@angular/core';
import { patchStates } from '../general-lib-constants';

@Injectable({
  providedIn: 'root'
})
export class WbcDeviceInfoHandlerService {

  constructor() { }



isNewApp(patch : any) {
    if (patch && (patch.hasOwnProperty('user_state') && 
    patch.user_state == patchStates.unused) || patch && 
    (patch.hasOwnProperty('app_version') && Number(patch.app_version.split('.')[0]) >= 6)
    ) {
      return true;
    } else {
      return false;
    }
  }

  checkPayment(patch : any){
    if (patch && (patch.hasOwnProperty('payment_history'))
    ) {
      return true;
    } else {
      return false;
    }
  }

  showSettings(patch : any){
    if(patch && patch.user_state == patchStates.ongoing || patch && patch.user_state == patchStates.completed){
      return true;
    }else{
      return false;
    }
  }

  showRSTrigger(patch : any){
    if(patch && this.isFullDataReady(patch?.files) && patch?.reports){
      return true;
    }else{
      return false;
    }
  }

  isFullDataReady (files : any){
    var ready = false;
    if(!files){
        ready = false;
    }else if(!files.bin180){
        ready = false
    }else if(files.bin180.length>0){
        files=files.bin180;
        for (var i = 0;i < files.length;i++){
            var fileKeys = Object.keys(files[i]);
            for(var k = 0 ; k < fileKeys.length;k++){
                var fileList = files[i][fileKeys[k]];
                if(fileList instanceof Array && fileList.indexOf("Full Data")!=-1){
                    ready = true;
                    break;
                }
            }
            
        }
    }
    return ready;
    
}

  showInsertDrive(patch : any){
    if(patch && patch.hasOwnProperty('session') && !this.isFullDataReady(patch?.files)){
      return true;
    }else{
      return false;
    }
  }

  checkUserState(patch : any){
    
    if(patch && patch.user_state === patchStates.ongoing){
      console.log('user state == 1, returning true');
              return true;
          }else{
              return false;
            }
  }

  showChooseCat( patch : any){
  
    if(patch && patch.user_state === patchStates.completed &&
        patch.manually_terminated && 
        !patch.hasOwnProperty('category')){
                  return true;
                }else{
                  return false;
                }
  }

  isProcedureOngoing(patch) {
    return patch.user_state == patchStates.ongoing;
  }

  isProcedureCompleted(patch) {
    return patch.user_state == patchStates.completed;
  }


  hasReports(device) {
    return device.reports || device.interim_reports;
  }

  isMailSentToTechnician(deviceInfo) {
    return !(
      !deviceInfo.hasOwnProperty('mail_status') ||
      (deviceInfo.hasOwnProperty('mail_status') &&
        deviceInfo.mail_status.status == patchStates.unused)
    );
  }
  

}