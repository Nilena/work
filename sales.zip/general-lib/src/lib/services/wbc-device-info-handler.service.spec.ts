import { TestBed } from '@angular/core/testing';

import { WbcDeviceInfoHandlerService } from './wbc-device-info-handler.service';

describe('WbcDeviceInfoHandlerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcDeviceInfoHandlerService = TestBed.get(WbcDeviceInfoHandlerService);
    expect(service).toBeTruthy();
  });
});
