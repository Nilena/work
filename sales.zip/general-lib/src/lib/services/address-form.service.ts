import { Injectable } from '@angular/core';
import { WbcAjaxService } from './wbc-ajax.service';
import { catchError, map, take } from 'rxjs/operators';
import { of as observableOf, BehaviorSubject } from 'rxjs';
import { LIB_CONSTANT } from '../general-lib-constants.enum';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
@Injectable({
  providedIn: 'root'
})
export class AddressFormService {

  constructor(private ajaxService: WbcAjaxService) { }

  getPathName(apiConfig, path, country?, state?) {
    debugger
    let urlPath;
    switch (path) {
      case 'country':
        urlPath = apiConfig.operations;
        break;
      case 'state':
        if (country) urlPath = apiConfig.operations + `?country=${country}`;
        break;
      case 'dist':
        if (country && state) urlPath = apiConfig.operations + `?country=${country}&state=${state}`;
        break;
    }
    return urlPath;
  }


  geoLocations(apiConfig, path, country?, state?) {
    let spinnerOptions = { spinner: true },
      message = LIB_CONSTANT.DATA_LOADED_SUCCESS;
    let urlPath = this.getPathName(apiConfig, path, country, state);
    if (urlPath) {
      return this.ajaxService
        .getWithRoutePath(
          urlPath,
          { token: null, apiBaseUrl: apiConfig.apiBaseUrl },
          apiConfig.routePath,
          spinnerOptions,
        )
        .pipe(
          map((res) => {
            const response: any = res;
            if (response) {
              return {
                message: 'success',
                data: response
              };
            } else {
              return {
                data: [],
                message: 'failure'
              };
            }
          }),
          catchError((err) =>
            observableOf(err).pipe(
              map((err) => {
                if (!navigator.onLine && err.statusText == 'Unknown Error') {
                  return {
                    data: [],
                    message: 'failure',
                    displayMessage: LIB_CONSTANT.NETWORK_CONNECTION_FAILED
                  };
                } else {
                  return {
                    data: [],
                    message: 'failure',
                    displayMessage: LIB_CONSTANT.SOME_WENT_WRONG
                  };
                }
              })
            )));
    } else {
      return {
        data: [],
        message: 'failure'
      };
    }

  }
  geoLocationUnderFieldstaff(apiConfig) {
    let spinnerOptions = { spinner: true },
      message = LIB_CONSTANT.DATA_LOADED_SUCCESS;
    return this.ajaxService
      .getWithRoutePath(
        apiConfig.operations,
        { token: null, apiBaseUrl: apiConfig.apiBaseUrl },
        apiConfig.routePath,
        spinnerOptions,
      )
      .pipe(
        map((res) => {
          const response: any = res;
          if (response) {
            return {
              message: 'success',
              data: response
            };
          } else {
            return {
              data: [],
              message: 'failure'
            };
          }
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              if (!navigator.onLine && err.statusText == 'Unknown Error') {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: LIB_CONSTANT.NETWORK_CONNECTION_FAILED
                };
              } else {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: LIB_CONSTANT.SOME_WENT_WRONG
                };
              }
            })
          )
        )
      );
  }

}