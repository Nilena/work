import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class WbcErrorInterceptorService {

  /**
  * Interceptor for all the http opertions. 
  * @param request  request is injected by the library
  * @param next  injected by the library
  */
     intercept(request : HttpRequest<any> ,next:HttpHandler):Observable<HttpEvent<any>>{
 //console.log("the request",request)
         //this is the place where we can add a spinner service.
              return next.handle(request).pipe(retry(1));
     }
}
