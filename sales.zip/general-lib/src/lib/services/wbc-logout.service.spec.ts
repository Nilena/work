import { TestBed } from '@angular/core/testing';

import { WbcLogoutService } from './wbc-logout.service';

describe('WbcLogoutService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcLogoutService = TestBed.get(WbcLogoutService);
    expect(service).toBeTruthy();
  });
});
