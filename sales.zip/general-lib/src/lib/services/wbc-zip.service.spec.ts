import { TestBed } from '@angular/core/testing';

import { WbcZipService } from './wbc-zip.service';

describe('WbcZipService', () => {
  let service: WbcZipService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcZipService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
