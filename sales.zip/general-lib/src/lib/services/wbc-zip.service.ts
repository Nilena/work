import { Injectable } from '@angular/core';
import JSZip from 'jszip';
import { isNullOrUndefined } from '../shared/util';

@Injectable({
  providedIn: 'root'
})
export class WbcZipService {
  constructor() {}

  getCompressOptions(type = 'base64', compression = 'DEFLATE', level = 9) {
    return {
      type,
      compression,
      compressionOptions: { level }
    };
  }

  async compress(content, zipfileName, compressOptions = null) {
    if (isNullOrUndefined(compressOptions)) {
      compressOptions = this.getCompressOptions();
    }

    let zip = new JSZip();
    zip.file(zipfileName, content);
    return await zip.generateAsync(compressOptions);
  }

  async uncompress(
    zipContent: any,
    zipfileName: string,
    base64Encoded: boolean = true
  ) {
    let zip = new JSZip();
    let unzipContent = await zip.loadAsync(zipContent, {
      base64: base64Encoded
    });
    return await unzipContent.file(zipfileName)?.async('string');
  }
}
