import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { of as observableOf, of } from 'rxjs';
import { WbcAjaxService } from './wbc-ajax.service';
import { ActivatedRoute } from '@angular/router';
import { WbcUserSessionService } from './wbc-user-session.service';
import { WbcRedirectionService } from './wbc-redirection.service';
import { WbcPkceService } from './wbc-pkce.service';
import { HttpParams } from '@angular/common/http';
import jwtDecode from 'jwt-decode';
import { USER_TYPES } from '../general-lib.config';
@Injectable({
  providedIn: 'root'
})
export class WbcOauthService {
  constructor(
    private redirectService: WbcRedirectionService,
    private userSessionService: WbcUserSessionService,
    private ajaxService: WbcAjaxService,
    private route: ActivatedRoute,
    private pkceService : WbcPkceService
  ) {}

  getClientId(baseUrl: string) {
    return this.ajaxService
      .getWithRoutePath(
        'client-id',
        { token: 'token', apiBaseUrl: baseUrl },
        'cognito',
        { spinner: false }
      )
      .pipe(
        map((res) => {
          return res;
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              return err;
            })
          )
        )
      );
  }

  getCode() {
    let code = this.route.snapshot.queryParamMap.get('code');
    if (code) {
      return { code: code };
    } else {
      return {};
    }
  }

  authenticateUser(appData, allowedUserTypes) {
    let sessionDetails = this.userSessionService.getUserSessionDetails(
      appData.env
    );
    let code = this.getCode();

    this.getClientId(appData.url).subscribe((clientDetails) => {
      if (clientDetails.hasOwnProperty('id')) {
        if (!sessionDetails && !code.hasOwnProperty('code')) {

          this.redirectService.redirectToAuthPage(
            appData,
            clientDetails.id
          );
        } else if (code.hasOwnProperty('code')) {
          this.getAndSetAccessToken(
            code,
            clientDetails.id,
            appData,
            allowedUserTypes
          );
        } 
        
        else if (sessionDetails) {
          let user = window.location.pathname.replace(/([/])/g, '');
          
         if(Object.keys(USER_TYPES).includes(user) && (USER_TYPES[user] == sessionDetails.user_type || USER_TYPES[user].indexOf(Number(sessionDetails.user_type)) !== -1)){
          let userType = sessionDetails.user_type;
          
          let redirectionRoute = this.getRedirectionRoute(
            Number(userType), 
            allowedUserTypes,
            {advanced_technician: sessionDetails['advanced_technician']}
          );   
          this.redirectService.redirectToRoute(redirectionRoute);
        }else{          
              this.redirectService.redirectToCustomLoginPage(appData,sessionDetails.client_id);
        }
          //redirect to type page
        } else { 
          this.handleError();
        }
      } else { 
        let user = window.location.pathname.replace(/([/])/g, '');
        if(Object.keys(USER_TYPES).includes(user)){
          this.redirectService.redirectToRoute(user);
        }
        else{ 
        this.handleError();
        }
      }
      
    });
    
  }

  getRedirectionRoute(userType, allowedUserTypes, segments = {}) {
    let redirectionRoute = allowedUserTypes[userType];
    if (
      USER_TYPES.tech.includes(userType) &&
      segments['advanced_technician']
    ) {
      redirectionRoute = 'holter'
    }
    else if(USER_TYPES.spoUser.includes(userType) &&
    userType == USER_TYPES.spoUser[0]){ 
      redirectionRoute = 'successPage'
    }
    return redirectionRoute;
  }

  parseBoolean(decoded, keysToParse: any[]) {
    keysToParse.forEach((key) => {
      if (
        decoded.hasOwnProperty(key) &&
        typeof decoded[key] === 'string' &&
        decoded[key].toLowerCase() === 'true'
        ) {
        decoded[key] = true;
      } else {
        decoded[key] = false;
      }
    })
  }

  getAndSetAccessToken(code, clientId, appConfig, allowedUserTypes) {
    let url = appConfig.oauth_api_base_url + 'oauth2/token';
    let urlencoded = new URLSearchParams();
    urlencoded.set('grant_type', 'authorization_code');
    urlencoded.set('client_id', clientId);
    urlencoded.set('redirect_uri', appConfig.redirect_oauth_uri);
    urlencoded.set('code', code.code);
    urlencoded.set('code_verifier', this.pkceService.getCodeVerifier(appConfig.verifier));
    this.ajaxService
      .postWithDifferentUrl({ spinner: false }, url, urlencoded.toString())
      .pipe(
        map((res) => {
          if (res.hasOwnProperty('access_token')) {
            let decoded = jwtDecode(res['id_token']);
            this.parseBoolean(decoded, ['advanced_technician']);
            if (allowedUserTypes.hasOwnProperty(Number(decoded['user_type']))) {
              this.userSessionService.setUsersessionDetailsOauth(
                appConfig.env,
                decoded,
                res,
                clientId,
                res['refresh_token']
              );

              if(sessionStorage.getItem('touchpoint') && USER_TYPES['operator'].includes(Number(decoded['user_type']))){
                sessionStorage.removeItem('touchpoint')
                this.redirectService.redirectToRoute(
                  'touchpoint'
                );
              }
              else{
                let redirectionRoute = this.getRedirectionRoute(
                  Number(decoded['user_type']),
                  allowedUserTypes,
                  {advanced_technician: decoded['advanced_technician']}
                );
                this.redirectService.redirectToRoute(
                  redirectionRoute
                );
              }
            } else {
              this.handleError();
            }
          } else {
            this.handleError();
          }
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              this.handleError();
            })
          )
        )
      ).subscribe();
  }

  handleError() {
    this.redirectService.redirectToCommonErrorPage();
  }

  refreshToken(sessionDetails, appConfig){
    let url = appConfig.oauth_api_base_url + 'oauth2/token';
    let body = new HttpParams();
    body = body.set('grant_type', 'refresh_token');
    body = body.set('client_id', sessionDetails.client_id);
    body = body.set('refresh_token', sessionDetails.refresh_token);

    return this.ajaxService
    .postWithDifferentUrl({spinner:false}, url, body)
    .pipe(
      map(response => {
        let res:any=response
        let decoded:any = jwtDecode(res.id_token);
        this.parseBoolean(decoded, ['advanced_technician']);
        decoded.email = sessionDetails.email;
        decoded.name == sessionDetails.name;
        decoded.hospital_id = sessionDetails.hospital_id;
      if (res.hasOwnProperty('access_token')) {
        this.userSessionService.setUsersessionDetailsOauth(
          appConfig.env,
          decoded, 
          res,
          sessionDetails.client_id,
          sessionDetails.refresh_token          
        );
        return { error: false, response: null }
      } else {
        return { error: true, response: response }
      }
      }),
      catchError(err => of({ error: true, response: err }))
    )
  }

  globalLogout(appConfig, clientId) {
    this.userSessionService.deleteSession(appConfig.env)
    this.redirectService.redirectToLoginPage(appConfig, clientId);
  }

  checkForRefreshTokenAndRefresh(appConfig, allowedUserTypes: any[]) {
    let appKey = appConfig.env
    let sessionDetails = this.userSessionService.getUserSessionDetails(appKey);
    let nowTime = new Date().getTime();

    if (
      sessionDetails &&
      sessionDetails.token &&
      allowedUserTypes.includes(sessionDetails.user_type)
    ) {

      let clientId = sessionDetails.client_id;
      let expiryTime = Number(sessionDetails.expiry_time);
      if (expiryTime - nowTime < 900000 && expiryTime - nowTime > 0) {
        //15 minutes && not expired
        return this.refreshToken(sessionDetails, appConfig)
        .pipe(
          map(
            (res) => {
              if (res.error) {
                this.handleError()
                return res;
              }
              return res;
            }
          )
        )
      } else if (expiryTime - nowTime <= 0) {
        // expired
        return this.refreshToken(sessionDetails, appConfig)
        .pipe(
          map(
            (res) => {
              let {response, error} = res
              
              if (
                error &&
                response &&
                response.error &&
                response.error == 'invalid_grant'
              ) {
                this.globalLogout(appConfig, clientId);
              } else if (response && response.error) {
                this.userSessionService.deleteSession(appConfig.env);
                this.redirectService.redirectToCustomLoginPage(appConfig, clientId);
              } 
              
              return res;
            }
          ) 
        )
      } else {
        return of({ error: false, response: null })
      }
    } else if (sessionDetails && sessionDetails.token) {
      this.redirectService.redirectToHome();
      return of({ error: false, response: null })
    } else {
      let baseUrl = ''
      if(window.location.href.indexOf("localhost")>0){
        baseUrl = appConfig.local_url
      }
      else {
        baseUrl = appConfig.url;  
      }
      
      return this.getClientId(baseUrl)
        .pipe(
          map(
            (clientDetails) => {
              if (clientDetails.hasOwnProperty('id')) {
                this.redirectService.redirectToCustomLoginPage(appConfig, clientDetails.id);
              } else {
                this.handleError();
              }
              return { response: null, error: true }
            }
          ) 
        )
    }
  }

  userLogout(appConfig) {
    let sessionDetails = this.userSessionService.getUserSessionDetails(appConfig.env);
    let clientId = sessionDetails.client_id;
    this.globalLogout(appConfig, clientId)
  }
}
