import { TestBed } from '@angular/core/testing';

import { WbcSnackbarService } from './wbc-snackbar.service';

describe('WbcSnackbarService', () => {
  let service: WbcSnackbarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcSnackbarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
