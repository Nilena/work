import { Injectable } from '@angular/core';
import moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { TimeOperationService } from './time-operation.service';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {
  currentMoment = moment();
  currentYear: string = moment().year().toString();
  currentMonth: string = (moment().month() + 1).toString().padStart(2, '0');
  currentDate: string = moment().date().toString().padStart(2, '0');
  currentTime: string = moment().format('hh:mm A');
  displayedYear: string = this.currentYear;
  displayedMonth: string = this.currentMonth;
  displayedDay: string;
  displayedDate: string = this.currentDate;
  displayedView: string = '';
  private monthandYearSubject = new BehaviorSubject<{ date: string, month: string, year: string, view: string, action?: number }>({ date: this.currentDate, month: this.currentMonth, year: this.currentYear, view: this.displayedView });
  data$ = this.monthandYearSubject.asObservable();
  private emittedEventData = new BehaviorSubject<{ date: string, month: string, year: string, view?: string, event?: any, hour?: string } | null>(null);
  eventDetails$ = this.emittedEventData.asObservable();
  constructor(private timeService: TimeOperationService) { }

  public updateData(newData: { date: string, month: string; year: string, view: string, action?: number }): void {
    this.monthandYearSubject.next(newData);
  }
  // public updateEmittedData(newData: { date: string, month: string, year: string, view?: string, event?: any, hour?: string }): void {
  //   this.emittedEventData.next(newData);
  // }

  getHourList(format: any): any[] {
    const hours = [];
    for (let i = 0; i < 24; i++) {
      const hourObject = {
        name: this.currentMoment.startOf('day').add(i, 'hours').format(format.formattedHr),
        value: i.toString().padStart(2, '0'),
        month: this.displayedMonth,
        year: this.displayedYear,
        date: this.displayedDate,
        day: this.timeService.getDayName(this.displayedYear, this.displayedMonth, this.displayedDate, format.day)
      };
      hours.push(hourObject);
    }
    return hours;
  }

}
