import { TestBed } from '@angular/core/testing';

import { WbcUserSessionService } from './wbc-user-session.service';

describe('WbcUserSessionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcUserSessionService = TestBed.get(WbcUserSessionService);
    expect(service).toBeTruthy();
  });
});
