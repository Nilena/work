import { Injectable } from '@angular/core';
import moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class TimeOperationService {

  constructor() { }
  /**
   * @description to get name of month
   * @param monthNumber 
   * @returns string which contain month name
   */
  getMonthName(monthNumber: string, format): string {
    const monthMoment = moment().month(parseInt(monthNumber) - 1); // Subtract 1 since moment uses 0-indexed months
    const monthName = monthMoment.format(format);
    return monthName;
  }
  /**
   * @description to get no of days in a month
   * @param year 
   * @param month 
   * @returns array which contain no of days in a month
   */

  getDaysInAMonth(year: string, month: string): number {
    const firstDay = moment([parseInt(year), parseInt(month) - 1]);
    const lastDay = firstDay.clone().endOf('month');
    return lastDay.date();
  }

  /**
   * @description to get month number ex jan- 01 from month name
   * @param monthName 
   * @returns no of that month
   */
  getMonthNumber(monthName: string, format): string {
    const monthMoment = moment(monthName, format);
    const monthNumber = monthMoment.month()+ 1;
    return (monthNumber ).toString().padStart(2, '0');
  }

  /**
   * @description to get name of the day from year month and date
   * @param year number
   * @param month string
   * @param day number
   * @returns string contain name of that day
   */
  getDayName(year: string, month: string, date: string, format: string): string {
    const dateObject = moment({ year: parseInt(year), month: parseInt(month) - 1, date: parseInt(date) }); // Subtract 1 from the month because it's 0-based
    const dayName = dateObject.format(format);
    return dayName;

  }
  /**
   * @description get formatted date in 'YYYY-MM-DD'
   * @param year 
   * @param month 
   * @param day 
   * @returns return date 'YYYY-MM-DD' in format
   */
  getFormatedDate(year: string, month: string, date: string, format: string): string {
    const formattedDate = moment({  year: parseInt(year), month: parseInt(month) - 1, date: parseInt(date) }).format(format);
    return formattedDate;
  }

  /**
   * @description return true or false date on inputed time and current time
   * @param hour 
   * @returns boolean 
   */
  isCurrentTime(hour: string, format: string): boolean {
    const currentHour = moment().hours();
    const selectedHour = moment(hour, format).hours();
    return currentHour === selectedHour;
  }
  /**
   * @description to get date
   * @param date number
   * @param format 
   * @returns return in given date
   */
  getDate(date, format) {
    const formattedDate = moment(date).format(format);
    return formattedDate;
  }

  /**
    * @description to get week of date starting from sunday to sat 
    * @param date 
    * @returns array contains week starting from sunday to sat 
    */
  getWeekRange(date: string, format): any {
    const momentDate = moment(date, format.formattedDate);
    const sundayBefore = momentDate.clone().startOf('isoWeek').subtract(1, 'day');
    const weekDates: any[] = [];
    const currentDate = moment();
    for (let i = 0; i < 7; i++) {
      const currentMoment = sundayBefore.clone().add(i, 'days');
      weekDates.push({
        fullDate: sundayBefore.clone().add(i, 'days').format(format.formattedDate),
        dayname: sundayBefore.clone().add(i, 'days').format(format.day),
        month: sundayBefore.clone().add(i, 'days').format(format.month),
        year: sundayBefore.clone().add(i, 'days').format(format.year),
        date: sundayBefore.clone().add(i, 'days').format(format.date),
        day: sundayBefore.clone().add(i, 'days').format(format.shortDay),
        isCurrentDate: currentMoment.isSame(currentDate, 'day'),
        events: []
      });
    }
    return weekDates;
  }

  /**
   * @description to get year from date
   * @param date 
   * @returns year of that date
   */
  getYear(date: string): number {
    const year = moment(date).year();
    return year;
  }
  /**
   * @description to get month from date
   * @param date 
   * @returns month of that date
   */
  getMonth(date: string): string {
    const month = (moment(date).month() + 1).toString().padStart(2, '0'); // add 1 for current month 
    return month
  }
  /**
     * @description to get month from date
     * @param date 
     * @returns month of that date
     */
  getDateObj(datadate: string): number {
    const date = moment(datadate).date();
    return date;
  }

  /**
   * @desription to convert time in 24 hour format
   * @param time 
   * @returns 24 hour formatted hour
   */
  convertTo24HrFormat(time: string, format): string {
    //'HH' for hour only in number
    //''h:mm A' 24hr format
    const momentObj = moment(time, format.formattedHr);
    const timeIn24HourFormat = momentObj.format(format.hour);
    return timeIn24HourFormat;
  }

  /**
   * @description to get the current timestamp
   * @returns return the current timestamp as a number type
   */
  getCurrentTimestamp(): number {
    return moment().valueOf()
  }
  
  /**
   * @description to get the time stamp of the date provided
   * @param dateString date in a string format eg: 01/02/2024
   * @param format format of the date eg: DD/MM/YYYY, MM/DD/YYYY
   * @returns returns the timestamp of the date provided in number format
   */
  convertDateStringIntoTimestamp(dateString: string, format: string): number {
    return moment(dateString, format).valueOf()
  }
  
  /**
   * @description to get the start of a particular timestamp
   * @param timestamp timestamp from which we need to find the starting timstamp
   * @returns returns the start of the timestamp as a number
   */
  getStartTimestampOfDay(timestamp?: number): number {
    if(timestamp){
        return moment(timestamp).startOf('day').valueOf()
    }
    return moment().startOf('day').valueOf()
  }
  
  /**
   * @description to get the end of a particular timestamp
   * @param timestamp timestamp from which we need to find the ending timstamp
   * @returns returns the end of the timestamp as a number
   */
  getEndTimestampOfDay(timestamp?: number): number {
    if(timestamp){
        return moment(timestamp).endOf('day').valueOf()
    }
    return moment().endOf('day').valueOf()
  }

  getMomentObj(format: string, momentObj: moment.Moment){
    return moment(momentObj.format(format),format)
  }
  getCurrentMomentObj(format: string){
    return moment(moment().format(format), format)
  }
  getMomentTimestamp(value: any){
    return moment(value).valueOf()
  }
  convertTimestampToMoment(value: number){
    return moment.unix(value)
  }

}

