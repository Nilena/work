import { Injectable } from '@angular/core';
import { WbcUserSessionService } from './wbc-user-session.service';

@Injectable({
  providedIn: 'root'
})
export class WbcAppDataService {
  constructor(private userSession: WbcUserSessionService) {}

  getAppData(AppConfig) {
    let appKey = AppConfig.env;
    let userSession = this.userSession.getUserSessionDetails(appKey);
    let token = 'token';
    if (userSession && userSession.token) {
      token = userSession.token;
    }
    let url = AppConfig.base_url;
    if (window.location.href.indexOf('localhost') > 0) {
      url = AppConfig.local_url;
    } else {
      url = AppConfig.url;
    }
    return { token: token, apiBaseUrl: url };
  }
}