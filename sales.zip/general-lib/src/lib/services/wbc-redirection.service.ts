import { Injectable } from '@angular/core';
import { WbcPkceService } from './wbc-pkce.service';

@Injectable({
  providedIn: 'root'
})
export class WbcRedirectionService {
  constructor(private pkceService: WbcPkceService) {}

  redirectToCustomLoginPage(appConfig, clientId) {
    //redirect to custom login
    let url =
      appConfig.oauth_api_base_url +
      'login?client_id=' +
      clientId +
      '&response_type=code&scope=openid&redirect_uri=' +
      appConfig.redirect_oauth_uri;
    this.redirect(url);
  }

  redirectToAuthPage(appConfig, clientId) {
    let verifier = this.pkceService.getCodeVerifier(appConfig.verifier);
    let codeChallenge = this.pkceService.getCodeChallenge(verifier);
    let url =
      appConfig.oauth_api_base_url +
      'oauth2/authorize?response_type=code&scope=openid&redirect_uri=' +
      appConfig.redirect_oauth_uri +
      '&client_id=' +
      clientId +
      '&code_challenge_method=S256&code_challenge=' +
      codeChallenge;
    this.redirect(url);
  }

  redirect(url: string) {
    window.location.href = url;
  }

  redirectToCommonErrorPage() {
    let url = location.origin + '/errorPage.html';
    this.redirect(url);
  }

  redirectToRoute(route) {
    let url = location.origin + '/' + route;
    this.redirect(url);
  }
  redirectToHome() {
    window.location.href = location.origin;
  }
  redirectToLoginPage(appConfig, clientId) {
    let url =
      appConfig.oauth_api_base_url +
      'logout?response_type=code&scope=openid&redirect_uri=' +
      appConfig.redirect_oauth_uri +
      '&client_id=' +
      clientId;
    this.redirect(url);
  }

  redirectToResetPassword(appConfig, clientId) {
    let url =
      appConfig.oauth_api_base_url +
      'forgotPassword?client_id=' +
      clientId +
      '&response_type=code&scope=openid&redirect_uri=' +
      appConfig.redirect_oauth_uri;
    this.redirect(url);
  }

  redirectErrorPage() {
    window.location.href = location.origin + '/errorPage.html';
  }
  redirectToCustomRoute(local_route,custom_route,is_localPath) {
    if (window.location.href.indexOf(is_localPath) == -1) {
      window.location.href = location.origin + local_route;
    } else {
      location.href = custom_route;
    }
  }
}
