import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureflagDirective } from './feature-flag.directive';



@NgModule({
  declarations: [
    FeatureflagDirective
  ],
  imports: [
    CommonModule
  ],
  exports:[FeatureflagDirective]
})
export class DirectivesModule { }
