export interface WbcUserSession {
  token: string;
  expiry_time: number;
  user_type: number;
  is_qc?: boolean;
  email: string;
  name: string;
  uuid?: string;
  password_set_time?: number;
  password_expiry_days?: number;
  show_password_alert?: boolean;
  hospital_id?: string;
  client_id?: string;
  refresh_token?: string;
  preferred_file_format?: number;
  segment?: number;
  signature_name?: string;
  user_id?: string;
}
