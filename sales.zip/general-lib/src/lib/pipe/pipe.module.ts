import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcDynamicPipe } from './wbc-dynamic.pipe';



@NgModule({
  declarations: [WbcDynamicPipe],
  imports: [
    CommonModule
  ],
  exports:[WbcDynamicPipe]
})
export class PipeModule { }
