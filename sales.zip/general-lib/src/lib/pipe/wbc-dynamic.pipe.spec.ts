import { Injector } from '@angular/core';
import { WbcDynamicPipe } from './wbc-dynamic.pipe';

describe('WbcDynamicPipe', () => {
  it('create an instance', () => {
    let injector: Injector;
    const pipe = new WbcDynamicPipe(injector);
    expect(pipe).toBeTruthy();
  });
});
