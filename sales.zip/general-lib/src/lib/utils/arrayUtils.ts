export function findMedian(arr, property = '') {
  // First, sort the array in ascending order
  const sortedArr = arr.slice().sort((a, b) => a - b);

  const length = sortedArr.length;

  if (length % 2 === 1) {
    // If the array has an odd number of elements, return the middle element.
    return (sortedArr.some(
      value => { return typeof value == "object" }))
      ? sortedArr[Math.floor(length / 2)][property]
      : sortedArr[Math.floor(length / 2)];
  } else {
    // If the array has an even number of elements, return the average of the two middle elements
    const middle1 = sortedArr[length / 2 - 1];
    const middle2 = sortedArr[length / 2];
    if (sortedArr.some(
      value => { return typeof value == "object" })) {
      return (middle1[property] + middle2[property]) / 2;
    } else {
      return (middle1 + middle2) / 2;
    }
  }
}
