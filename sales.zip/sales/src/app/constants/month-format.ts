export const monthInFyOrder = [
    'april',
    'may',
    'june',
    'july',
    'august',
    'september',
    'october',
    'november',
    'december',
    'january',
    'february',
    'march'
];

export const monthInOrder = [
    'january',
    'february',
    'march',
    'april',
    'may',
    'june',
    'july',
    'august',
    'september',
    'october',
    'november',
    'december'
  ];

  export const monthsInNum = {
    jan:'01',
    feb:'02',
    mar:'03',
    apr:'04',
    may:'05',
    jun:'06',
    jul:'07',
    aug:'08',
    sep:'09',
    oct:'10',
    nov:'11',
    dec:'12'
  }


  export const monthNames = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'June',
    'July',
    'Aug',
    'Sept',
    'Oct',
    'Nov',
    'Dec'
  ];
  export const monthOrder = [
    '01',
    '02',
    '03',
    '04',
    '05',
    '06',
    '07',
    '08',
    '09',
    '10',
    '11',
    '12'
  ];
