export const States =  [{
    "id": "AN",
    "text": "Andaman and Nicobar Islands",
    "code": "35",
    "value":"Andaman and Nicobar Islands"
},
{
    "id": "AD",
    "text": "Andhra Pradesh",
    "code": "37",
    "value":"Andhra Pradesh"
},
{
    "id": "AR",
    "text": "Arunachal Pradesh",
    "code": "12",
    "value":"Arunachal Pradesh"
},
{
    "id": "AS",
    "text": "Assam",
    "code": "18",
    "value":"Assam"

},
{
    "id": "BR",
    "text": "Bihar",
    "code": "10",
    "value":"Bihar"
},
{
    "id": "CH",
    "text": "Chandigarh",
    "code": "04",
    "value":"Chandigarh"
},
{
    "id": "CG",
    "text": "Chhattisgarh",
    "code": "22",
    "value":"Chhattisgarh"
},
{
    "id": "DN",
    "text": "Dadra and Nagar Haveli",
    "code": "26",
    "value":"Dadra and Nagar Haveli"
},
{
    "id": "DD",
    "text": "Daman and Diu",
    "code": "25",
    "value":"Daman and Diu"
},
{
    "id": "DL",
    "text": "Delhi",
    "code": "07",
    "value":"Delhi"
},
{
    "id": "GA",
    "text": "Goa",
    "code": "30",
    "value":"Goa"
},
{
    "id": "GJ",
    "text": "Gujarat",
    "code": "24",
    "value":"Gujarat"
},
{
    "id": "HR",
    "text": "Haryana",
    "code": "06",
    "value":"Haryana"
},
{
    "id": "HP",
    "text": "Himachal Pradesh",
    "code": "02",
    "value":"Himachal Pradesh"
},
{
    "id": "JK",
    "text": "Jammu and Kashmir",
    "code": "01",
    "value":"Jammu and Kashmir"
},
{
    "id": "JH",
    "text": "Jharkhand",
    "code": "20",
    "value":"Jharkhand"
},
{
    "id": "KA",
    "text": "Karnataka",
    "code": "29",
    "value":"Karnataka"
},
{
    "id": "KL",
    "text": "Kerala",
    "code": "32",
    "value":"Kerala"
},
{
    "id": "LD",
    "text": "Lakshadweep",
    "code": "31",
    "value":"Lakshadweep"
},
{
    "id": "MP",
    "text": "Madhya Pradesh",
    "code": "23",
    "value":"Madhya Pradesh"
},
{
    "id": "MH",
    "text": "Maharashtra",
    "code": "27",
    "value":"Maharashtra"
},
{
    "id": "MN",
    "text": "Manipur",
    "code": "14",
    "value":"Manipur"
},
{
    "id": "ML",
    "text": "Meghalaya",
    "code": "17",
    "value":"Meghalaya"
},
{
    "id": "MZ",
    "text": "Mizoram",
    "code": "15",
    "value":"Mizoram"
},
{
    "id": "NL",
    "text": "Nagaland",
    "code": "13",
    "value":"Nagaland"
},
{
    "id": "OD",
    "text": "Odisha",
    "code": "21",
    "value":"Odisha"
},
{
    "id": "PY",
    "text": "Puducherry",
    "code": "34",
    "value":"Puducherry"
},
{
    "id": "PB",
    "text": "Punjab",
    "code": "03",
    "value":"Punjab"
},
{
    "id": "RJ",
    "text": "Rajasthan",
    "code": "08",
    "value":"Rajasthan"
},
{
    "id": "SK",
    "text": "Sikkim",
    "code": "11",
    "value":"Sikkim"
},
{
    "id": "TN",
    "text": "Tamil Nadu",
    "code": "33",
    "value":"Tamil Nadu"
},
{
    "id": "TS",
    "text": "Telangana",
    "code": "36",
    "value": "Telangana",
},
{
    "id": "TR",
    "text": "Tripura",
    "code": "16",
    "value": "Tripura",
},
{
    "id": "UP",
    "text": "Uttar Pradesh",
    "code": "09",
    "value": "Uttar Pradesh",
},
{
    "id": "UK",
    "text": "Uttarakhand",
    "code": "05",
    "value": "Uttarakhand",
    
},
{
    "id": "WB",
    "text": "West Bengal",
    "code": "19",
    "value": "West Bengal"

}
];