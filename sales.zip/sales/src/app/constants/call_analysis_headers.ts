import { APP_CONSTANT } from '../app.enum';

export const call_analysis = [
    {
        viewValue: APP_CONSTANT.TOTAL_FIELD_WORKING_DAYS
      },
      {
        viewValue: APP_CONSTANT.TOTAL_NUMBER_OF_CALLS
      },
      {
        viewValue: APP_CONSTANT.CALL_AVERAGE,
      }
  ];

export const missedCall_analysis = [
    {
        viewValue: APP_CONSTANT.AGGREGATED_TOTAL_DOC_MISSED_COUNT
      },
    
      {
        viewValue: APP_CONSTANT.AGGREGATED_CORE_DOC_MISSED_COUNT
      },
     
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_MISSED_COUNT
      }
];

export const coverage_analysis = [
    {
        viewValue: APP_CONSTANT.DOCTOR_TOTAL_FIELD_WORKING_DAY
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_TOTAL_DOC_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_TOTAL_DOC_MET_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_TOTAL_DOC_MISSED_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_DOC_TOTAL_COVERAGE_COUNT,
        infoIcon:true,
        infoLabel:APP_CONSTANT.DOCTOR_COVERAGE_CALCULATION
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_ADDITIONAL_DOC_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_ADDITIONAL_DOC_MET_COUNT
      },
      {
        viewValue: APP_CONSTANT.TOTAL_DOC_COUNT
      },
      {
        viewValue: APP_CONSTANT.DOCTOR_CALL_AVERAGE,
        infoIcon:true,
        infoLabel:APP_CONSTANT.DOCTOR_CALL_AVG_CALCULATION
      },
      // {
      //   viewValue: APP_CONSTANT.AGGREGATED_CORE_DOC_COUNT
      // },
      // {
      //   viewValue: APP_CONSTANT.AGGREGATED_CORE_DOC_MET_COUNT
      // },
      // {
      //   viewValue: APP_CONSTANT.AGGREGATED_CORE_DOC_MISSED_COUNT
      // },
      // {
      //   viewValue: APP_CONSTANT.AGGREGATED_CORE_COVERAGE_COUNT,
      // },
  
      
      
      
      
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_MET_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_MISSED_COUNT
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_COVERAGE_COUNT,
        infoIcon:true,
        infoLabel:APP_CONSTANT.HOSPITAL_COVERAGE_CALCULATION
      },
      {
        viewValue: APP_CONSTANT.AGGREGATED_HOSPITAL_CALL_AVERAGE,
        infoIcon:true,
        infoLabel:APP_CONSTANT.HOSPITAL_CALL_AVG_CALCULATION
      }
      
];