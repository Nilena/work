export const targetHighchartConstants = {
    HIGHCHART_NAME : 'spline',
    HIGHCHART_FONT: 'Arial',
    HIGHCHART_TITLE: 'Trend',
    HIGHCHART_BOLD: 'bold',
    HIGHCHART_DESCRIPTION: 'Months of the year',
    HIGHCHART_SYMBOL: 'circle',
    HIGHCHART_TYPE: 'line',
    HIGHCHART_SERIES_NAME1: 'Potential',
    HIGHCHART_SERIES_NAME2: 'Target'
}