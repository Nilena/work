export const visitTypes = [
  { value: 0, viewValue: 'IN-PERSON' },
  { value: 1, viewValue: 'TELEPHONIC' },
  { value: 2, viewValue: 'MESSAGING' },
  { value: 3, viewValue: 'OTHERS' }
];

export const doctorRatings = [
  { value: 0, viewValue: 'CHAMPION' },
  { value: 1, viewValue: 'REGULAR' },
  { value: 2, viewValue: 'ACTIVE' },
  { value: 3, viewValue: 'INACTVE' },
  { value: 4, viewValue: 'NON PRESCRIBER' }
];

export const acceptanceLevel = [
  { value: 0, viewValue: 'ONE DAY IS ENOUGH' },
  { value: 1, viewValue: 'HIGH COST' },
  { value: 2, viewValue: 'PHONE DEPENDENCY' },
  { value: 3, viewValue: 'NON AVAILABILITY IN_HOSPITAL' },
  { value: 4, viewValue: 'OUT SOURCED ANALYSIS' },
  { value: 5, viewValue: 'AFFINITY TO COMPETITOR' },
  { value: 6, viewValue: 'SINGLE LEAD LIMITATION' },
  { value: 7, viewValue: 'CONVENIENCE' },
  { value: 8, viewValue: 'EXTENDED DURATION' },
  { value: 9, viewValue: 'OTHERS' }
];
