import { Injectable } from '@angular/core';
import { APP_CONSTANT } from 'src/app/app.enum';
import { WbcAjaxService } from 'src/app/services/wbc-ajax.service';
import { WbcSpinnerService } from 'src/app/services/wbc-spinner.service';
import { catchError, map, take } from 'rxjs/operators';
import { of as observableOf } from 'rxjs';
import { APINAME, callStatus } from 'src/app/app.config';
@Injectable({
  providedIn: 'root'
})
export class WbcApprovalsService {
  constructor(
    private ajaxService: WbcAjaxService,
    private spinnerService: WbcSpinnerService
  ) {}

  getUnlockCallRequestList() {
    var spinnerOptions = { spinner: true };
    return this.ajaxService
      .getRequestWithoutOperationHeader(
        APINAME.LIST_UNLOCK_CALL_REQUEST,
        spinnerOptions,
        APP_CONSTANT.SFA_URL_BASE
      )
      .pipe(
        map((res: any) => {
          this.spinnerService.hideSpinner();
          return {
            message: 'success',
            data: this.dataFormat(res?.data)
          };
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              this.spinnerService.hideSpinner();
              if (!navigator.onLine && err.statusText == 'Unknown Error') {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.NETWORK_CONNECTION_FAILED
                };
              } else {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.SOME_WENT_WRONG
                };
              }
            })
          )
        )
      );
  }
  UnlockCallRequestApproval(data) {
    return this.ajaxService
      .postRequestWithoutOperationHeader(
        APINAME.UNLOCK_CALL_REQUEST_APPROVAL,
        data,
        'apiEndPointBase',
        { spinner: true }
      )
      .pipe(
        take(1),
        map((res) => {
          const response: any = res;
          this.spinnerService.hideSpinner();
          if (response) {
            return {
              message: 'success'
            };
          } else {
            return {
              data: [],
              message: 'failure'
            };
          }
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              this.spinnerService.hideSpinner();
              if (!navigator.onLine && err.statusText == 'Unknown Error') {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.NETWORK_CONNECTION_FAILED
                };
              } else {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.SOME_WENT_WRONG
                };
              }
            })
          )
        )
      );
  }
  dataFormat(data) {
    data.hos_call = this.addCallProperty(data.hos_call, 2);
    data.doc_call = this.addCallProperty(data.doc_call, 1);
    data = [...data.hos_call, ...data.doc_call];
    return data;
  }

  addCallProperty(array, value) {
    const viewValue = callStatus.find((x) => x.key === value);
    return array.map((obj) => ({
      ...obj,
      call: viewValue.value,
      callKey: viewValue.key,
      id: value === 1 ? obj.email + 1 : obj.email + 2
    }));
  }
}
