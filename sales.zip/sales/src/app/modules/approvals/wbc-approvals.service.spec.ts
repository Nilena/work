import { TestBed } from '@angular/core/testing';

import { WbcApprovalsService } from './wbc-approvals.service';

describe('WbcApprovalsService', () => {
  let service: WbcApprovalsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcApprovalsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
