import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcApprovalsContainerComponent } from './wbc-approvals-container.component';

describe('WbcApprovalsContainerComponent', () => {
  let component: WbcApprovalsContainerComponent;
  let fixture: ComponentFixture<WbcApprovalsContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcApprovalsContainerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcApprovalsContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
