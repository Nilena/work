import { Component, OnInit } from '@angular/core';
import { APP_CONSTANT } from 'src/app/app.enum';
import { Router } from '@angular/router';
import { ViewportService } from '../../../../../../general-lib/src/lib/services/viewport.service';

@Component({
  selector: 'app-wbc-approvals-container',
  templateUrl: './wbc-approvals-container.component.html',
  styleUrls: ['./wbc-approvals-container.component.css']
})
export class WbcApprovalsContainerComponent implements OnInit {
  constants = APP_CONSTANT;
  tiles = [
    {
      icon: 'people',
      caption: this.constants.DOCTORS,
      path: '/add-doctor-list'
    },
    {
      icon: 'contact_phone',
      caption: this.constants.CALLS,
      path: '/call-approvals'
    }
  ];
  constructor(public router: Router, public viewportService: ViewportService) {}

  ngOnInit(): void {}

  navigateToDoctor(path) {
    this.router.navigate([path]);
  }
  checkMobile() {
    return this.viewportService.isMobileView;
  }
}
