import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcApprovalsContainerComponent } from './wbc-approvals-container/wbc-approvals-container.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MaterialModule } from '../material/material.module';
import { WbcCallApprovalsComponent } from './wbc-call-approvals/wbc-call-approvals.component';
import { WbcTablePaginationModule } from '../../../../../general-lib/src/lib/modules/table-pagination/wbc-table-pagination.module';



@NgModule({
  declarations: [
    WbcApprovalsContainerComponent,
    WbcCallApprovalsComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    SharedModule,
    WbcTablePaginationModule
  ]
})
export class ApprovalsModule { }
