import { Injectable } from '@angular/core';
import { APP_CONSTANT } from 'src/app/app.enum';
import { WbcAjaxService } from 'src/app/services/wbc-ajax.service';
import { WbcSpinnerService } from 'src/app/services/wbc-spinner.service';
import { catchError, map, take } from 'rxjs/operators';
import { of as observableOf, Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AccountService {
  constructor(
    private ajaxService: WbcAjaxService,
    private spinnerService: WbcSpinnerService
  ) {}
  listOutStanding(reportee_id) {
    var spinnerOptions = { spinner: true };
    let sumAmount = 0;
    let is_outstanding = false;
    return this.ajaxService
      .postRequestWithoutOperationHeader( 'getFieldStaffDetails?reportee_id='+encodeURIComponent(reportee_id),{},'apiEndPointBase', spinnerOptions)
      .pipe(
        map((res) => {
          this.spinnerService.hideSpinner();
          const response: any = res;
          if(response.outstanding_amount){
            response.outstanding_amount.transactions.forEach(element => {
              if(!is_outstanding){
              sumAmount = sumAmount + element.debit;
              if(sumAmount >= response.outstanding_amount.amount){
                element["is_debit"] = true;
                is_outstanding = true
              }
              else{
                element["is_debit"] = true;
              }
            }
            else{
              element["is_debit"] = false;
            }
          });
        }
          return {
            message: 'success',
            data: response.outstanding_amount,
            displayMessage: ''
          };
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              this.spinnerService.hideSpinner();
              if (!navigator.onLine && err.statusText == 'Unknown Error') {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.NETWORK_CONNECTION_FAILED
                };
              } else {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.SOME_WENT_WRONG
                };
              }
            })
          )
        )
      );
  }

  requestOutStanding() {
    var spinnerOptions = { spinner: true };
    return this.ajaxService
      .postRequest({}, 'requestForOutstandingAmount', spinnerOptions)
      .pipe(
        map((res) => {
          this.spinnerService.hideSpinner();
          const response: any = res;
          return {
            message: 'success',
            data: response.outstanding_amount,
            displayMessage: response.reason
          };
        }),
        catchError((err) =>
          observableOf(err).pipe(
            map((err) => {
              this.spinnerService.hideSpinner();
              if (!navigator.onLine && err.statusText == 'Unknown Error') {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.NETWORK_CONNECTION_FAILED
                };
              } else {
                return {
                  data: [],
                  message: 'failure',
                  displayMessage: APP_CONSTANT.SOME_WENT_WRONG
                };
              }
            })
          )
        )
      );
  }
}
