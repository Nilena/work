import { Component, OnInit } from '@angular/core';
import { AccountService } from './account.service';
import { Outstanding } from 'src/app/models/outstanding-model';
import { APP_CONSTANT } from 'src/app/app.enum';
import { WbcAuthService } from 'src/app/services/wbc-auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { WbcListReporteesService } from 'src/app/shared/wbc-list-reportees/wbc-list-reportees.service';
@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.scss']
})
export class MyAccountComponent implements OnInit {
  outstanding: Outstanding;
  constants;
  userDetails;
  reportees = [];
  search_values = {};
  reportee = '';
  listOfReportees = [];

  constructor(
    private service: AccountService,
    private authService: WbcAuthService,
    private snackBar: MatSnackBar,
    private listReporteesService: WbcListReporteesService
  ) {
    this.constants = APP_CONSTANT;
  }

  ngOnInit() {
    this.listReporteesService.listReportees().subscribe((res) => {
      if (res.message==="success") {
        this.listOfReportees = res.data;
      }
    });
    this.userDetails = this.authService.getUserDetails();
  }
  listOutstandingAmount(reportee) {
    this.service.listOutStanding(reportee).subscribe((val) => {
      if (val.message == 'success') {
        this.outstanding = val.data;
      } else {
        this.snackBar.open(val.displayMessage, '', { duration: 3000 });
      }
    });
  }
  updateOutStanding() {
    this.service.requestOutStanding().subscribe((val) => {
      this.snackBar.open(val.displayMessage, '', { duration: 3000 });
    });
  }
  onFilterSelected(event) {
    if (event) {
      this.reportee = event.data.value;
      this.userDetails = {
        name: event.data.viewValue,
        email: event.data.value
      };
      this.listOutstandingAmount(event.data.value);
    }
  }
}
