import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from '../material/material.module';

import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { MyAccountComponent } from './my-account/my-account.component';
import { AccountUserInfoComponent } from './account-user-info/account-user-info.component';
import { OutstandingInfoComponent } from './outstanding-info/outstanding-info.component';
@NgModule({
  imports: [CommonModule, MaterialModule, SharedModule, ReactiveFormsModule],
  declarations: [MyAccountComponent, AccountUserInfoComponent,OutstandingInfoComponent],

})
export class AccountModule {}
