import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { APP_CONFIG } from 'src/app/app.config';
import { APP_CONSTANT } from 'src/app/app.enum';
import { WbcAuthService } from 'src/app/services/wbc-auth.service';

@Component({
  selector: 'app-outstanding-info',
  templateUrl: './outstanding-info.component.html',
  styleUrls: ['./outstanding-info.component.scss']
})
export class OutstandingInfoComponent implements OnInit {
  constants;
  @Input() reportee;
  constructor(private authService: WbcAuthService,) {
    this.constants = APP_CONSTANT;
  }
  @Input() outstanding;
  @Output() updateOutStanding = new EventEmitter<any>();
  ngOnInit() {}
  onUpdateOutStanding(){
    this.updateOutStanding.emit();
  }
  checkLoginUser(reportee){
    return this.authService.getUserDetails().email == reportee ? true:false;
  }
}
