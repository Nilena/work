import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-user-info',
  templateUrl: './account-user-info.component.html',
  styleUrls: ['./account-user-info.component.scss']
})
export class AccountUserInfoComponent implements OnInit {
  constructor() {}
  @Input() userinfo;
  ngOnInit() {}
}
