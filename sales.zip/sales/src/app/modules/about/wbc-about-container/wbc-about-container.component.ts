import { Component, OnInit } from '@angular/core';
import { APP_CONFIG} from '../../../app.config';
import { APP_CONSTANT } from 'src/app/app.enum';
@Component({
  selector: 'app-wbc-about-container',
  templateUrl: './wbc-about-container.component.html',
  styleUrls: ['./wbc-about-container.component.scss']
})
export class WbcAboutContainerComponent implements OnInit {
  public gudid: string = null;
  public releaseId: string = null;
  public releaseDate:string=null;
  manufacturer;
  address;
  aboutConfig;
  email: string = null;
  webAddress: string = null;
   constants = APP_CONSTANT;
  constructor() { }

  ngOnInit() {
    this.getmanufacturer();
    this.gudid = APP_CONFIG.gudid;
    this.releaseId = APP_CONFIG.release_id;
    this.releaseDate = APP_CONFIG.release_date;
    this.aboutConfig = APP_CONFIG.holter_about
    this.getContact();
    
  }

  getContact() {
    let contactGroup = this.aboutConfig.holteraboutcontacts.split(',');
    if (contactGroup.length > 1) {
      this.email = contactGroup[0];
      this.webAddress = contactGroup[1].trim();
    } else {
      this.webAddress = contactGroup[0].trim();
    }
  }

  getmanufacturer = () =>{
    var address = APP_CONFIG.manufacturer.split(" ");
    this.address = address.length > 1 ? address.pop():'';
    this.manufacturer = address.join(" ");
  }

}
