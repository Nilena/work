import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcAboutContainerComponent } from './wbc-about-container/wbc-about-container.component';
import { QRCodeModule } from 'angularx-qrcode';
import { SharedModule } from 'src/app/shared/shared.module';
import { MaterialModule } from '../material/material.module';

@NgModule({
  imports: [CommonModule, QRCodeModule, SharedModule,MaterialModule],
  declarations: [WbcAboutContainerComponent],
  exports: [WbcAboutContainerComponent]
})
export class AboutModule {}
