import { APP_CONSTANT, HOS_CAT, HOS_TYPE, Calendar_Status, Quarter } from './app.enum';

export let APP_CONFIG = {
  url: 'https://' + '%SERVER_BASE_URI%/%ENVIRONMENT%',
  env: '%ENVIRONMENT%',
  key: '%ENVIRONMENT%' + '/sales',
  login_base_url: '',
  release_id: '%RELEASE_ID%',
  release_date: '%RELEASE_DATE%',
  commit_id: '%COMMIT_ID%',
  local_url: 'https://api.webcardio.net/wbcqa01',
  sfa_module_url_base: '/sfa',
  zoho_module_url_base: '-zoho-people',
  payment_module_url_base: '-record-payment',
  master_warehouse_id: 'master_warehouse',
  gudid: '%GUDID%',
  manufacturer: '%MANUFACTURER%',
  holter_about: {
    releasedate: '%HOLTER_ABOUT_RELEASE_DATE%',
    holteraboutproductlabel1: '%HOLTER_ABOUT_PRODUCT_LABEL1%',
    holteraboutproductlabel2: '%HOLTER_ABOUT_PRODUCT_LABEL2%',
    holteraboutmodellabel1: '%HOLTER_ABOUT_MODEL_LABEL1%',
    holteraboutmodellabel2: '%HOLTER_ABOUT_MODEL_LABEL2%',
    holteraboutuniquedevicelabel1: '%HOLTER_ABOUT_UNIQUE_DEVICE_LABEL1%',
    holteraboutuniquedevicelabel2: '%HOLTER_ABOUT_UNIQUE_DEVICE_LABEL2%',
    holteraboutmedicaldevicelabel1: '%HOLTER_ABOUT_MEDICAL_DEVICE_LABEL1%',
    holteraboutmedicaldevicelabel2: '%HOLTER_ABOUT_MEDICAL_DEVICE_LABEL2%',
    holteraboutmanufacturedby: '%HOLTER_ABOUT_MANUFACTURED_BY%',
    holteraboutaddress: '%HOLTER_ABOUT_ADDRESS%',
    holteraboutcontacts: '%HOLTER_ABOUT_CONTACTS%'
  }
};

// export const FINANCIAL_YEAR = {
//   fyStart: {
//     month: 3,
//     day: 1
//   },
//   fyEnd: {
//     month: 2,
//     day: 31
//   }
// }

export const USER_TYPES = {
  fieldstaff: 12,
  businessAnalystUser: 36
};

export const NOTIFICATION_TYPES = {
  attendence: 0,
  approval_rejection: 6,
  outstanding_update: 7,
  unlock_core_non_core: 8
};
export const NOTIFICATION_ACTION = {
  5: 'transfer-patch',
  6: 'transfer-patch',
  7: 'account',
  8: 'doctors'
};
export const MESSAGE_READ_STATUS = {
  read: 0,
  unread: 1
};

export const APP_TYPE = {
  sales: 1,
  insight: 2,
  caretouch: 3
};

export const DEPARTMENT = {
  SALES: 0,
  FIELD_OPERATION: 1,
  PMT: 2
};

export const actions = [{ actionValue: 0, actionName: 'Reassign doctors' }];

export const HOSPITAL_ACTIONS = [
  { actionValue: 0, actionName: 'Reassign hospital' }
];

export const REASON_FOR_CHANGE = [
  { value: 0, viewValue: 'Doctor Changed Location' },
  { value: 1, viewValue: 'Doctor changed hospital in the same location' },
  { value: 2, viewValue: 'Doctor List Correction' },
  { value: 3, viewValue: 'New SBO onboarding' }
];

export const HOLTER_STROKE_USAGE = [
  { value: 0, viewValue: 'Holter is not at all done' },
  { value: 1, viewValue: 'One day hospital holter is being done in-patient' },
  { value: 2, viewValue: 'One day Outsourced holter is being done in-patient' },

  {
    value: 3,
    viewValue: 'One day hospital holter is being done post discharge'
  },
  { value: 4, viewValue: 'One day Outsourced holter is done post discharge' },
  { value: 5, viewValue: 'Multi day hospital holter is being done in-patient' },
  {
    value: 6,
    viewValue: 'Multi day Outsourced holter is being done in-patient'
  },
  {
    value: 7,
    viewValue: 'Multi day hospital holter is being done post discharge'
  },
  { value: 8, viewValue: 'Multi day Outsourced holter is done post discharge' },
  { value: 9, viewValue: 'WebCardio SP3 is being used' },
  { value: 10, viewValue: 'WebCardio SP7 is being used' }
];

export const STROKE_USAGE_BLOCKING_PERCEPTION = [
  { value: 5, viewValue: 'None' },
  { value: 0, viewValue: 'Holter is not required clinically' },
  { value: 1, viewValue: 'One day holter is good enough clinically' },
  {
    value: 2,
    viewValue:
      'Multi day holter is required clinically, but practical difficulties to get it done'
  },

  {
    value: 3,
    viewValue: 'Multi days holter is required clinically, but cost is a concern'
  },
  {
    value: 4,
    viewValue:
      'Holter is required clinically required and is being taken care by the cardiology department as required'
  }
];

export const CAPABILITY_RATING_SOURCE = [
  { value: 1, viewValue: 'Poor' },
  { value: 2, viewValue: 'Below average' },
  { value: 3, viewValue: 'Average' },
  { value: 4, viewValue: 'Good' },
  { value: 5, viewValue: 'Excellent' }
];
export const DESIGNATION_ROLE = [
  { value: 1, viewValue: 'Holter/Echo/TMT technician' },
  { value: 2, viewValue: 'Doctor secretary' },
  { value: 3, viewValue: 'Physician assistant' },
  { value: 4, viewValue: 'Cardiology coordinator' },
  { value: 5, viewValue: 'Floor coordinator' },
  { value: 6, viewValue: 'Neurology coordinator' },
  { value: 7, viewValue: 'Nurse' },
  { value: 8, viewValue: 'ICU in-charge' },
  { value: 9, viewValue: 'Other' }
];
export const MONTHS = [
  { value: '1', viewValue: 'January' },
  { value: '2', viewValue: 'February' },
  { value: '3', viewValue: 'March' },
  { value: '4', viewValue: 'April' },
  { value: '5', viewValue: 'May' },
  { value: '6', viewValue: 'June' },
  { value: '7', viewValue: 'July' },
  { value: '8', viewValue: 'August' },
  { value: '9', viewValue: 'September' },
  { value: '10', viewValue: 'October' },
  { value: '11', viewValue: 'November' },
  { value: '12', viewValue: 'December' }
];
export const SLICEDMONTHS = [
  { value: 1, viewValue: 'Jan' },
  { value: 2, viewValue: 'Feb' },
  { value: 3, viewValue: 'Mar' },
  { value: 4, viewValue: 'Apr' },
  { value: 5, viewValue: 'May' },
  { value: 6, viewValue: 'Jun' },
  { value: 7, viewValue: 'Jul' },
  { value: 8, viewValue: 'Aug' },
  { value: 9, viewValue: 'Sept' },
  { value: 10, viewValue: 'Oct' },
  { value: 11, viewValue: 'Nov' },
  { value: 12, viewValue: 'Dec' }
];

export const doctorType = [
  { label: 'All', value: 'All' },
  { label: 'Master', value: 'Master' },
  { label: 'Additional', value: 'Additional' }
];

export const PrescriberType = [
  { label: 'All', value: 'all' },
  { label: 'Prescriber', value: 'presc' },
  { label: 'Non - Prescriber', value: 'noPresc' }
];
export const specialization = [
  { label: APP_CONSTANT.CARDIOLOGIST, value: 'Cardiologist', key: 0, viewValue: 'Cardiologist' },
  { label: APP_CONSTANT.NEUROLOGIST, value: 'Neurologist', key: 1, viewValue: 'Neurologist' },
  {
    label: APP_CONSTANT.PHYSICIAN_CARDIOLOGIST,
    value: 'Physician Cardiologist',
    key: 2,
    viewValue: 'Physician Cardiologist'
  },
  {
    label: APP_CONSTANT.PHYSICIAN_NEUROLOGIST,
    value: 'Physician Neurologist',
    key: 3,
    viewValue: 'Physician Neurologist'
  },
  {
    label: APP_CONSTANT.PAEDIATRIC_CARDIOLOGIST,
    value: 'Paediatric cardiologist',
    key: 4,
    viewValue: 'Paediatric cardiologist'
  },
  {
    label: APP_CONSTANT.ELECTROPHYSIOLOGIST,
    value: 'Electrophysiologist',
    key: 5,
    viewValue: 'Electrophysiologist'
  },
  { label: APP_CONSTANT.CARDIAC_SURGEON, value: 'Cardiac Surgeon', key: 6, viewValue: 'Cardiac Surgeon' },
  { label: APP_CONSTANT.NEURO_SURGEON, value: 'Neuro Surgeon', key: 7, viewValue: 'Neuro Surgeon' },
  {
    label: APP_CONSTANT.CONSULTING_PHYSICIAN,
    value: 'Consulting Physician',
    key: 8,
    viewValue: 'Consulting Physician'
  },
  { label: APP_CONSTANT.OTHERS, value: 'Others', key: 9, viewValue: 'Others' }
];

export const REJECTREASONS = [
  { name: APP_CONSTANT.DUPLICATE, value: 0 },
  {
    name: APP_CONSTANT.INCORRECT_DR_NAME_ENTRY,
    value: 1
  },
  { name: APP_CONSTANT.INCORRECT_EMAIL_ID, value: 2 },
  {
    name: APP_CONSTANT.INCORRECT_CONTACT_NO,
    value: 3
  },
  { name: APP_CONSTANT.OTHERS, value: 4 }
];

export const GUIDELINES_STROKE = [
  {
    value: 0,
    viewValue: 'AHA/ASA2021'
  },
  {
    value: 1,
    viewValue: 'ESC 2020'
  },
  {
    value: 2,
    viewValue: 'AHA/ASA 2021 and ESC 2020'
  },
  {
    value: 3,
    viewValue: 'MOHFW'
  },
  {
    value: 4,
    viewValue: 'OTHERS'
  },
  {
    value: 5,
    viewValue: 'NONE'
  }
];

export const BELIEF_STROKE = [
  {
    value: 0,
    viewValue:
      'I think clinically Holter is not required as I can make Afib diagnostic without that'
  },
  {
    value: 1,
    viewValue:
      'I think clinically Holter is not required as the treatment is not going to be different based on the holter result'
  },
  {
    value: 2,
    viewValue: 'I think clinically one day is good enough'
  },
  {
    value: 3,
    viewValue: 'I think clinically 3 days is good enough'
  },
  {
    value: 4,
    viewValue: 'I think clinically 7 day is required'
  },
  {
    value: 5,
    viewValue: 'I think clinically even 7 day is not sufficient'
  },
  {
    value: 6,
    viewValue:
      'I decide on case by case basis as clinical need to AFib diagnosis varies with patient'
  }
];

export const HABIT_STROKE = [
  {
    value: 0,
    viewValue:
      'I refer this to cardiologist as cardiac evaluation and let them take care of giving me a report and based on that I can decide the treatment'
  },
  {
    value: 1,
    viewValue:
      'I refer this to cardiologist and let them take care of the diagnosis and treatment'
  },
  {
    value: 2,
    viewValue: 'I refer this to cardiologist specifying the duration of Holter'
  },
  {
    value: 3,
    viewValue: 'I will go with the number of days suggested by neurologist'
  },
  {
    value: 4,
    viewValue:
      'As a cardiologist I will decide the number of days of for cases referred by neurologist'
  },
  {
    value: 5,
    viewValue:
      'I directly prescribe Holters and if any event occurs, will refer to Cardio for further treatment'
  }
];

export const BLOCKER_STROKE = [
  {
    value: 0,
    viewValue:
      'I know multiday is required but due to existing practice I just use hospital holter for a day'
  },
  {
    value: 1,
    viewValue:
      'I know multiday is required but due to Cost to the patient I go for single day'
  },
  {
    value: 2,
    viewValue:
      'I know multiday is required but due to Inconvenience to the patient I go for single day(based on understanding of traditional Holter)'
  },
  {
    value: 3,
    viewValue:
      'I know multiday is required but due to Cost and inconvenience to the patient I go for single day'
  },
  {
    value: 4,
    viewValue:
      'I know multiday is required but since it increases the waiting period for other patients who require Holter, I go for single day'
  }
];

export const POSITION_ON_WEBCARDIO = [
  {
    value: 0,
    viewValue:
      'I think WebCardio SP7 is the right product and will prescribe if its available in hospital'
  },
  {
    value: 1,
    viewValue:
      'I think WebCardio SP7 is the right product and I will give WebCardio contact details to patient'
  },
  {
    value: 2,
    viewValue: 'I can refer WebCardio SP7 to cardiologist'
  },
  {
    value: 3,
    viewValue:
      'I think WebCardio SP3 is the right product and will prescribe if its available in hospital'
  },
  {
    value: 4,
    viewValue:
      'I think WebCardio SP3 is the right product and I will give WebCardio contact details to patient'
  },
  {
    value: 5,
    viewValue: 'I can refer WebCardio SP3 to cardiologist'
  },
  {
    value: 6,
    viewValue:
      'I dont want to be involved and will leave it completely to cardiologist.You just need to communicate to them'
  },
  {
    value: 7,
    viewValue: 'I don’t think Webcardio is required'
  },
  {
    value: 8,
    viewValue: 'I use Webcardio SP7 since it’s available in the hospital'
  },
  {
    value: 9,
    viewValue:
      'I use Webcardio SP7 by giving Webcardio contact details to patient.'
  },
  {
    value: 10,
    viewValue: 'I Use Webcardio SP3 since it’s available in the hospital,'
  },
  {
    value: 11,
    viewValue:
      'I use Webcardio SP3 by giving Webcardio contact details to patient'
  },
  {
    value: 12,
    viewValue:
      'I use Webcardio SP3 or SP7 as per the Clinical needs of the patient'
  }
];

export const HOLTER_IN_STROKE_WORKFLOW = [
  {
    value: 0,
    viewValue: 'Neurologist prescribes and honoured by Holter room'
  },
  {
    value: 1,
    viewValue:
      'Neurologist prescribes and honoured with dedicated Holter for stroke'
  },
  {
    value: 2,
    viewValue:
      'Neurology refers to cardiology, cardiologist prescribes and honoured by Holter room'
  },
  {
    value: 3,
    viewValue: 'Neurologist prescribes and sends to third party'
  },
  {
    value: 4,
    viewValue:
      'Neurology refers to cardiology, cardiologist prescribes and sends to third party'
  }
];
export const ELECTRO_DOC = [
  {
    value: false,
    viewValue: 'NO'
  },
  {
    value: true,
    viewValue: 'YES'
  }
];

export const DOCTOR_ROLE = [
  {
    value: 1,
    viewValue: 'Speaker'
  },
  {
    value: 2,
    viewValue: 'Delegate'
  },
  {
    value: 3,
    viewValue: 'Organising Committee'
  }
];

export const APINAME = {
  LIST_MISSED_HOSPITAL_CALLS: 'list-missed-hospital-calls',
  GET_ASSIGNED_HOS_INFO: 'get-assigned-hospital-info',
  GET_ASSIGNED_DR_INFO: 'getAssignedDoctorInfo',
  LISTMISSEDDOCTORCALLS: 'listMissedDoctorCalls',
  LIST_MONTHLY_CALL_REPORTS: 'list-monthly-call-reports',
  GET_TARGET_POTENTIAL: 'get-target-potential',
  FY_TARGET_LIST: 'fy-target-list',
  SBO_TARGET_ACTUAL_POTENTIAL: 'sbo-target-actual-potential',
  GET_DISTRICT_PROFILE: 'get-district-profile',
  DOCTOR_REASSIGN: 'doctor-reassign',
  HOSPITAL_REASSIGN: 'hospital-assignment',
  APPROVAL_AWAITING_HOSPITAL_LIST: 'approval-awaiting-hospital-list',
  APPROVAL_AWAITING_HOS_INFO: 'approval-awaiting-hos-info',
  ADD_NEW_HOSPITAL: 'add-new-hospital',
  GET_HOSPITAL_DOCTORS: 'get-hospital-doctors',
  GET_DOCTOR_COUNT: 'get-doctor-count',
  GEO_LOCATION_UNDER_FIELDSTAFF: 'geo-location-under-fieldstaff',
  GET_HOSPITAL_PRESCRIPTION_LEVEL_ANALYSIS:
    'get-hospital-prescription-level-analysis',
  GET_DOCTORS_PRESCRIPTION_LEVEL_ANALYSIS:
    'get-doctors-prescription-level-analysis',
  LIST_ALL_DEVICE_TYPES: 'listAllDeviceTypes',
  GET_HOS_ADDRESS: 'get-hos-address',
  GET_TODAY_ONGOING_PROCEDURES: 'get-today-ongoing-procedures',
  GET_ASSIGNED_HOSPITALS: 'get-fieldtaff-hospital-plan',
  GET_HOS_DEV_PLAN: 'get-hos-dev-plan',
  HOSPITAL_SPECIFIC_OBJECTIVE: 'hos-specific-objectives',
  LIST_UNLOCK_CALL_REQUEST: 'list-unlock-call-request',
  ADD_CAMPAIGN: 'add-campaign',
  LIST_CAMPAIGN: 'list-campaign',
  GET_CAMPAIGN: 'get-campaign',
  ADD_INSURANCE: 'dictionary-type-add-edit',
  GET_INSURANCE: 'dictionary-type-list',
  ADD_DICTIONARY: 'dictionary-type-add-edit',
  GET_DICTIONARY: 'dictionary-type-list',
  GET_CONFERENCE_DETAILS: 'get-conference-details',
  GEO_LOCATIONS: 'geo-locations',
  LIST_ASSIGNED_HOSPITAL: 'listAssignedHospitals',
  GET_HOSPITAL_SUVERY_SUMMARY: 'get-hospital-survey-summary',
  GET_HOSPITAL_TREND: 'get-hospital-trend',
  GET_HOSPITAL_DOCTOR_PLAN: 'get-hospital-doctor-plan',
  GET_FEILD_STAFF_MONTHLY_PLAN: 'get-fieldstaff-monthly-plan',
  SUBMIT_HOSPITAL_PLAN: 'approve-hos-plan',
  GET_LIST_REPORTEE: 'listReportees',
  SUBMIT_REVIEW: 'save-fs-review',
  GET_SALES_DATA: 'get-sales-data',
  CONVERT_TO_NON_PRESCRIBER: 'convert-to-non-prescriber',
  GET_CAMPAIGN_DETAILS: 'get-compaign-fs-details',
  UNLOCK_CALL_REQUEST_APPROVAL: 'unlock-call-request-approval',
  GET_AGG_HOSP_CALL_COV_STAT: 'getAggregatedHospitalCallCoverageStatistics',
  GET_AGG_DOC_CALL_COV_STAT: 'getAggregatedDoctorCallCoverageStatistics',
  GET_SIGNED_URL: 'get-signed-url',
  TAG_CONFERENCE: 'tag-conference',
  GET_CONFERENCE: 'get-conference-details',
  GET_FS_REVIEW: 'get-fs-review',
  GET_UNIVERSAL_LIST: 'list-universal-doctor',
  CREATE_PO:'create-po',
  EDIT_HOS_ADDRESS:'edit-hos-address',
  SAVE_HOSP_QRCODE: 'hospital_qr_code',
  GET_QUARTER_SALES: 'get-quarter-sales',
  GET_QUARTER_CAPABILITY_REPORT: 'get-quarter-capability-report',
  GET_NEW_PRESCRIBER_COUNT: 'get-new-prescriber-count'

};

export const STATUS_NAMES = [
  {
    name: APP_CONSTANT.NOT_SUBMITTED,
    value: 3
  },
  {
    name: APP_CONSTANT.WAITING_FOR_APPROVAL,
    value: 0
  },
  {
    name: APP_CONSTANT.APPROVED,
    value: 1
  },
  {
    name: APP_CONSTANT.REJECTED,
    value: 2
  }
];

export const APPROVALAWAITINGFSDOCSTATUS = [
  { name: APP_CONSTANT.MANAGER_APPROVAL_PENDING, value: 0 },
  { name: APP_CONSTANT.REJECTED, value: 1 },
  { name: APP_CONSTANT.PMT_APPROVAL_PENDING, value: 2 },
  { name: APP_CONSTANT.APPROVED, value: 3 }
];

export const APPROVALAWAITINGFSDOCCOLOR = [
  { backgroundColor: '#038f0d', color: '#fcf7f7' }, //manager pending
  { backgroundColor: '#d80000', color: '#ffffff' }, //Rejected
  { backgroundColor: '#7d0303', color: '#faf3f3' } //PMT pending
];

export const ENTRYSTATUSDOCSTATUS = [
  { name: APP_CONSTANT.NEW_ENTRY, value: 0 },
  { name: APP_CONSTANT.NEW_DOC_EDITED, value: 1 },
  { name: APP_CONSTANT.IGNORED, value: 2 }
];

export const PRESCRIBERCOLOR = [
  { backgroundColor: '#d80000', color: '#ffffff' }, //prescriber
  { backgroundColor: '#088204', color: '#faf3f3' } //nonprescriber
];
export const AVAILABILITYOPTIONS = [
  {
    value: 0,
    displayValue: APP_CONSTANT.NOT_INITIATED
  },
  {
    value: 1,
    displayValue: APP_CONSTANT.DOCTOR_ACCEPTANCE
  },
  {
    value: 2,
    displayValue: APP_CONSTANT.DUE_DELIGENCE
  },
  {
    value: 3,
    displayValue: APP_CONSTANT.PROCURMENT
  },
  {
    value: 4,
    displayValue: APP_CONSTANT.INITIAL_ORDER
  },
  {
    value: 5,
    displayValue: APP_CONSTANT.LIMITED_SCALE
  },
  {
    value: 6,
    displayValue: APP_CONSTANT.VOULME_BUSINESS
  }
];

export const HOSPITAL_STEPS = [
  {
    value: 0,
    viewValue: APP_CONSTANT.CONVINCE_PROCUREMENT
  },
  {
    value: 1,
    viewValue: APP_CONSTANT.CONVINCE_BIOMEDICAL
  },
  {
    value: 2,
    viewValue: APP_CONSTANT.RATE_NEGOTIATION
  },
  {
    value: 3,
    viewValue: APP_CONSTANT.GET_PO
  },
  {
    value: 4,
    viewValue: APP_CONSTANT.ADDRESS_CHALLENGES
  },
  {
    value: 5,
    viewValue: APP_CONSTANT.ESTABLISH_WORKFLOW
  }
];

export const DOCTOR_STEPS = [
  {
    value: 0,
    viewValue: APP_CONSTANT.CONVINCE_DOCTOR_PATIENTS
  },
  {
    value: 1,
    viewValue: APP_CONSTANT.CONVINCE_DOCTOR_DAILY_PRACTICE
  },
  {
    value: 2,
    viewValue: APP_CONSTANT.CONVINCE_DOCTOR_HOSPITAL_ADVANTAGE
  },
  {
    value: 3,
    viewValue: APP_CONSTANT.GET_INTEND
  },
  {
    value: 4,
    viewValue: APP_CONSTANT.TRAINING_TO_ASSISTANTS
  },
  {
    value: 5,
    viewValue: APP_CONSTANT.PRESCRIPTION_ARRHYTHMIA
  },
  {
    value: 6,
    viewValue: APP_CONSTANT.PRESCRIPTION_STROKE
  }
];
export const PrescriptionLevels = [
  {
    value: 1,
    displayValue: 'L0'
  },
  {
    value: 2,
    displayValue: 'L1'
  },
  {
    value: 3,
    displayValue: 'L2'
  },
  {
    value: 4,
    displayValue: 'L3'
  },
  {
    value: 5,
    displayValue: 'L4'
  },
  {
    value: 6,
    displayValue: 'L5'
  },
  {
    value: 7,
    displayValue: 'L6'
  },
  {
    value: 8,
    displayValue: 'L7'
  }
];

export const OBJECTIVES = [
  {
    value: 0,
    viewValue: APP_CONSTANT.HOSPITAL_ENTRY
  },
  {
    value: 1,
    viewValue: APP_CONSTANT.ENHANCE_PRESCRIPTION
  }
];

export const HOSCATEGORY = [
  { value: HOS_CAT.A, viewValue: APP_CONSTANT.A },
  { value: HOS_CAT.B, viewValue: APP_CONSTANT.B },
  { value: HOS_CAT.C, viewValue: APP_CONSTANT.C },
  { value: HOS_CAT.D, viewValue: APP_CONSTANT.D },
  { value: HOS_CAT.E, viewValue: APP_CONSTANT.E }
];

export const AUDIENCE = [
  {
    value: 1,
    viewValue: APP_CONSTANT.CARDIOLOGISTS
  },
  {
    value: 2,
    viewValue: APP_CONSTANT.NUEROLOGISTS
  },
  {
    value: 3,
    viewValue: APP_CONSTANT.ELECTROPHYSIOLOGISTS
  },
  {
    value: 4,
    viewValue: APP_CONSTANT.OTHERS
  }
];

export const DATE_FORMAT = {
  parse: {
    dateInput: 'DD/MM/YYYY'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY'
  }
};

export const HOSPTYPES = [
  { value: HOS_TYPE.State_Govt, viewValue: APP_CONSTANT.STATE_GOVT },
  { value: HOS_TYPE.Central_Govt, viewValue: APP_CONSTANT.CENTRAL_GOVT },
  {
    value: HOS_TYPE.Private_Hospital_Chain,
    viewValue: APP_CONSTANT.PRIVATE_HOST
  },
  {
    value: HOS_TYPE.Govt_Hospital_Chain,
    viewValue: APP_CONSTANT.Govt_Hospital_Chain
  },
  { value: HOS_TYPE.Private, viewValue: APP_CONSTANT.PRIVATE },
  { value: HOS_TYPE.Clinic, viewValue: APP_CONSTANT.CLINIC },
  { value: HOS_TYPE.Pharma, viewValue: APP_CONSTANT.PHARMA },
  { value: HOS_TYPE.Diagnostic, viewValue: APP_CONSTANT.DIAGNOSTIC },
  {
    value: HOS_TYPE.Home_Healthcare,
    viewValue: APP_CONSTANT.HOME_HEALTHCARE
  },
  {
    value: HOS_TYPE.Domestic_Distributor,
    viewValue: APP_CONSTANT.DOMESTIC_DISTRIBUTOR
  },
  {
    value: HOS_TYPE.Overseas_Distributor,
    viewValue: APP_CONSTANT.OVERSEAS_DISTRIBUTOR
  },
  { value: HOS_TYPE.Demo, viewValue: APP_CONSTANT.DEMO },
  { value: HOS_TYPE.Internal, viewValue: APP_CONSTANT.INTERNAL },
  { value: HOS_TYPE.Others, viewValue: APP_CONSTANT.OTHERS_HOSP }
];

export const QUALIFICATIONS = [
  {
    key: 0,
    viewValue: 'MBBS'
  },
  {
    key: 1,
    viewValue: 'MD'
  },
  {
    key: 2,
    viewValue: 'DNB'
  },
  {
    key: 3,
    viewValue: 'DM'
  },
  {
    key: 4,
    viewValue: 'DIP'
  }
];

export const HOSPITAL_FILTER = {
  stroke_protocol: [
    { key: 'YES', value: 'true' },
    { key: 'NO', value: 'false' }
  ],
  target_filter: [
    { key: 'SP3 current month', value: 'sp3' },
    { key: 'SP7 current month', value: 'sp7' }
  ],
  survey_completion: [
    { key: 'Basic Info 1', value: 'is_basic_info_1' },
    { key: 'Basic Info 2', value: 'is_basic_info_2' },
    { key: 'Others', value: 'other' }
  ]
};

export const USER_STATES = {
  PRE_ACTIVE: 0,
  ACTIVE: 1,
  INACTIVE: 2,
  DISABLED: 3,
  NO_NETWORK: 4,
  EXPIRED: 5,
  DISCARDED: 6,
  PROVISIONED: 7
};

export const DefaulfSettings = {
  time: '9:00 AM'
};

export const CalendarFormat = {
  yearMonthDate: 'YYYY/MM/DD'
};

export const calendarStatus = [
  { key: Calendar_Status.Pending, value: 'pending' },
  { key: Calendar_Status.Approved, value: 'approved' },
  { key: Calendar_Status.Rejected, value: 'rejected' },
  { key: Calendar_Status.In_Progress, value: 'inProgress' },
  { key: Calendar_Status.Done, value: 'done' },
  { key: Calendar_Status.Deleted, value: 'deleted' }
];

export const CAPABILITY_QUARTER = [
  { value: 'Q1', viewValue: 'Q1' },
  { value: 'Q2', viewValue: 'Q2' },
  { value: 'Q3', viewValue: 'Q3' },
  { value: 'Q4', viewValue: 'Q4' }
]

export const callStatus = [
  { key: 1, value: 'Doctor' },
  { key: 2, value: 'Hospital' }
];

export const QR_ALPHA_NUMERIC_MAXLIMIT = 4296;

export const CAPABILITY_REPORT_TAB = [
  { id: 0, name: 'Review Form', icon: 'subject', show: true, open: false },
  { id: 1, name: 'Summary Assessment', icon: 'assessment', show: true, open: false },
  { id: 2, name: 'Quarterly Review Report', icon: 'next_week', show: true, open: false },
  { id: 3, name: 'Improvement Task', icon: 'next_week', show: true, open: false },
  { id: 4, name: "Rating of SBO's", icon: 'transfer_within_a_station', show: true, open: false },
  { id: 5, name: 'Highest-Lowest Rated Parameters', icon: 'low_priority', show: true, open: false },
  { id: 6, name: 'Percentage of Completed Task and Comments Added', icon: 'comment', show: true, open: false }
]

export const CAPABILITY_STATES = {
  REVIEW_FORM: 0,
  SUMMARY_ASSESSMENT: 1,
  QUARTERLY_REVIEW: 2,
  IMPROVEMENT_TASK: 3,
  RATING_SBO: 4,
  PARAMETER_RATING: 5,
  PERCENTAGE_AND_COMMENTS: 6,
};

export const CALENDAR_VIEW = {
  WEEK: 'week',
  MONTH: 'month',
  DAY: 'day'
}

export const ROUTE_LIST = {
  BUSINESS_DASHBOARD: '/business-dashboard',
  CONSOLE: '/console',
  REVIEW_DASHBOARD: '/review-dashboard',
  PURCHASE_ORDER: '/purchase-order',
  ADD_HOSPITAL_LIST: '/add-hospital-list',
}

export const dateFormat = 'DD-MM-YYYYY';

export const ADD_DICTIONARY_API_TYPES = {
  INSURANCE: 1,
  CONFERENCE: 3
}

export const DOCTOR_SPLIT = 15