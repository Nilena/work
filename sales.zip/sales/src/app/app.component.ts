import { Component, OnInit, Renderer2 } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { WbcAssignedPatchesService } from './services/wbc-assigned-patches.service';
import { WbcAuthService } from './services/wbc-auth.service';
import { WbcOfflineService } from './services/wbc-offline.service';
import { WbcSpinnerService } from './services/wbc-spinner.service';
import { WbcPushService } from './services/wbc-push.service';
import { Router } from '@angular/router';
import { WbcNotificationService } from './modules/notifications/wbc-notifications/wbc-notification.service';
import * as confetti from 'canvas-confetti';
import { WbcTokenManagementService } from './services/wbc-token-management.service';
import { USER_TYPES } from './app.config';
import { WbcIconLoadService } from './services/wbc-icon-load.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'sales';
  isExpanded = false;
  validSession = false;
  isLoggedIn$: Observable<boolean>;
  userTypes = USER_TYPES;

  constructor(private offlineService: WbcOfflineService,
    private ongoingPatchService: WbcAssignedPatchesService,
    private authService: WbcAuthService,
    private spinnerService: WbcSpinnerService,
    private pushService: WbcPushService,
    private renderer: Renderer2,
    private notificationService: WbcNotificationService,
    private tokenManagementService: WbcTokenManagementService,
    private iconLoadService: WbcIconLoadService) {
    this.spinnerService.renderer = this.renderer;
    this.iconLoadService.loadInitialIcons();
  }
  ngOnInit() {
    this.isLoggedIn$ = this.authService.isLoggedIn;
    this.offlineService.startService();
    this.isLoggedIn$.subscribe(value => {
      if (value) {
        if (!this.validSession) {
          this.tokenManagementService.checkForRenewToken();
          /**as the api 'listActiveAndUnpaidPatches' is not required for BA User*/
          if (this.authService.getUserDetails().userType != this.userTypes.businessAnalystUser) {
            this.ongoingPatchService.setUnPaidCount();
          }
          this.pushService.intialiseForNotification();
          /**as the api 'check-attendance-status' & 'listConfigurations' is not required for BA User*/
          if (window.location.pathname.indexOf("notification") == -1 && this.authService.getUserDetails().userType != this.userTypes.businessAnalystUser) {
            this.notificationService.getNotifications(false);

          }
          if (new Date().getMonth() + 1 == 10) {
            this.confetti();
          }
        }
        this.validSession = true;
      } else {
        this.validSession = false;
      }
    })

    if (new Date().getMonth() + 1 == 10 && this.validSession) {
      this.confetti();
    }
  }
  confetti() {
    var count = 200;
    var duration = 3 * 1000;
    var animationEnd = Date.now() + duration;
    var defaults = {
      origin: { y: 0.7 }
    };
    var interval = setInterval(function () {
      var timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }
      function fire(particleRatio, opts) {
        confetti.create(null, {
          resize: true,
          useWorker: true
        })(Object.assign({}, defaults, opts, {
          particleCount: Math.floor(count * particleRatio)
        }));
      }

      fire(0.25, {
        spread: 26,
        startVelocity: 55,
      });
      fire(0.2, {
        spread: 60,
      });
      fire(0.35, {
        spread: 100,
        decay: 0.91,
        scalar: 0.8
      });
      fire(0.1, {
        spread: 120,
        startVelocity: 25,
        decay: 0.92,
        scalar: 1.2
      });
      fire(0.1, {
        spread: 120,
        startVelocity: 45,
      });
    }, 850);
  }


}
