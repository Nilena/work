export interface wbcStatisticsFilter {
    type:string,
    month:string,
    year:number,
    id:string,
    aggredatedView?:boolean
 }