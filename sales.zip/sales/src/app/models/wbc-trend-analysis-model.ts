export interface TrendAnalysisModel {
  name:string,
  total:number,
  january:number,
  february:number,
  march:number,
  april:number,
  may:number,
  june:number,
  july:number,
  august:number,
  september:number,
  october:number,
  november:number,
  december:number,
  patientdirect?:object,
  patient_direct?:boolean

}