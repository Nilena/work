export interface WbcTreeHierachy {
    name : string,
    children? : Array<WbcTreeHierachy>,
    highLightMessage?:string,
    id:string,
    visible?:boolean
 }