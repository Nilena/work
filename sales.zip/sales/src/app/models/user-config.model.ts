export interface UserConfig {
  roleName: string; // User role name
  themeName: string; // Selected theme name
  appTitle: string; // Application title
  appType: number;
  allowedUsertypes: Array<number>; // Array of allowed user types
  allowedRoutes: Array<string>; // Array of allowed routes
  basehref: string; // Base href for the application
  apiEndPointBase: string; // Base API endpoint
  initialRoute: string, //Initial Route after login

  // Configuration for displaying various services and features
  serviceDisplayConfig: {
    ongoingProcedure: ongoingProcedureConfig;
    hospitalDoctors: hospitalDoctorsConfig;
    statisticsAnalysis: statisticsAnalysisConfig;
    performance: performanceConfig;
    logistics: logisticsConfig;
    paymentRemittance: paymentRemittanceConfig;
    others: OtherConfig;
    businessDashboard: businessDashboardConfig;
  };
}

export interface ongoingProcedureConfig {
  display: boolean;
}
export interface hospitalDoctorsConfig {
  display: boolean;
  hospitals: boolean;
  doctors: boolean;
  hospitalCalls: boolean;
  doctorCalls: boolean;
}
export interface statisticsAnalysisConfig {
  display: boolean;
  statistics: boolean;
  districtProfile: boolean;
}
export interface performanceConfig {
  display: boolean;
  band: boolean;
  target: boolean;
  capabilityReview: boolean;
  weeklyReview:boolean;
}
export interface logisticsConfig {
  display: boolean;
  patchTransfer: boolean;
  patchRequest: boolean;
  unused: boolean;
}
export interface businessDashboardConfig {
  display: boolean;
  reviewDashboard?: boolean;
}

export interface paymentRemittanceConfig {
  display: boolean;
  payment: boolean;
  history: boolean;
  hospitalRemittance: boolean;
}

export interface OtherConfig {
  display: boolean;
  attendance: boolean;
  approvals: boolean;
  settings: boolean;
  account?: boolean;
  about?:boolean;
  conference?:boolean;
  campaign?:boolean;
  insurance?:boolean
  hospitalChain?:boolean
}
