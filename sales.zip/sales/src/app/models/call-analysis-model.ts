export interface TreeNode {
    id: string;
    name: string;
    manager_id?: string;
    doctor_call_aggr_stats: Object;
    hospital_call_aggr_stats: Object;
    doctor_call_stats: Object;
    hospital_call_stats: Object;
    reportees?: TreeNode[];
    expandable?: boolean;
  }
  
  export interface FlatNode {
    expandable: boolean;
    name: string;
    level: number;
    id: string;
  }

  export interface CallAnalysisTreeNode {
    id: string;
    name: string;
    manager_id?: string;
    call_analysis_aggr_stats:Object;
    call_analysis_stats:Object;
    reportees?: CallAnalysisTreeNode[];
    expandable?: boolean;
  }