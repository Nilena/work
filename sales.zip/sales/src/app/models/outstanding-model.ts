interface Transactions {
  customer_name: string;
  date: string;
  credit: number;
  debit: number;
}
export interface Outstanding {
  amount: number;
  outstanding_amount_id: string;
  time: number;
  transactions: Array<Transactions>;
}
