export interface WbcNotificationCount {
    new_notification:number,
    attendance_notification:number
 }


 export interface WbcNotificationMessage {
    title:string,
    message:string,
    date:Date,
    type:number,
    actionText?:string,
    actionRoute?:string,
    state:number,
    reminder?:boolean
 }