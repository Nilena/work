export interface FilterItem {
    key: string;
    label: string;
    noSearchResultText: string;
    selectedList: any[];
    list: any[];
    isDisabled: boolean;
  }