import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { WbcLoginComponent } from './modules/login/wbc-login/wbc-login.component';
import { WbcProcedureStatisticsComponent } from './modules/procedure-statistics/wbc-procedure-statistics/wbc-procedure-statistics.component';
import { WbcAuthGuard } from './guards/wbc-auth.guard'
import { WbcRemittanceComponent } from './modules/remittance/wbc-remittance/wbc-remittance.component';
import { ServiceListComponent } from './modules/services/service-list/service-list.component';
import { MoreComponent } from './modules/services/more/more.component';
import { SettingsContainerComponent } from './modules/settings/settings/settings-container.component';
import { WbcCallAnalysisComponent } from './modules/call-analysis/wbc-call-analysis/wbc-call-analysis.component';
import { WbcPatchRequestComponent } from './modules/patch-request/wbc-patch-request/wbc-patch-request.component';
import { WbcDoctorsComponent } from './modules/doctors/wbc-doctors/wbc-doctors.component';
import { TransferPatchComponent } from './modules/transfer-patch/transfer-patch/transfer-patch.component';
import { PatchTransferContainerComponent } from './modules/patch-transfer/patch-transfer-container/patch-transfer-container.component';
import { RecordPaymentComponent } from './modules/record-payment/record-payment/record-payment.component';
import { WbcAboutContainerComponent } from './modules/about/wbc-about-container/wbc-about-container.component';
import { UnusedUnacknowledgeComponent } from './modules/unused-unacknowledge/unused-unacknowledge/unused-unacknowledge.component';
import { WbcHospitalsComponent } from './modules/hospitals/wbc-hospitals/wbc-hospitals.component'
import { OngoingProceduresComponent } from './modules/ongoing-procedures/ongoing-procedures/ongoing-procedures.component';
import { WbcNotificationsComponent } from './modules/notifications/wbc-notifications/wbc-notifications.component'
import { WbcProcedureStatContainerComponent } from './modules/procedure-statistics/wbc-procedure-stat-container/wbc-procedure-stat-container.component';
import { WbcHospitalCallsComponent } from './modules/hospital-calls/wbc-hospital-calls/wbc-hospital-calls.component';
import { DoctorCallsComponent } from './modules/doctor-call/doctor-calls/doctor-calls.component';
import { WbcHospitalInvoiceComponent } from './modules/hospitals/wbc-hospital-invoice/wbc-hospital-invoice.component';
import { MyAccountComponent } from './modules/account/my-account/my-account.component';
import { WbcDoctorProfileComponent } from './modules/doctor-profile/wbc-doctor-profile/wbc-doctor-profile.component';
import { CapabilityContainerComponent } from './modules/capability-review/capability-container/capability-container.component';
import { PerformanceBandComponent } from './modules/performance-band/band-container/performance-band.component';
import { DistPopulationContainerComponent } from './modules/dist-population-profile/dist-population-container/dist-population-container.component';
import { ReporteeTargetComponent } from './modules/target/reportee-target/reportee-target.component'
import { WbcAddDoctorComponent } from './modules/doctors/wbc-add-container/wbc-add-doctor.component';
import { WbcNewDocDetailsComponent } from './modules/doctors/wbc-new-doc-details/wbc-new-doc-details.component';
import { WbcAddHopitalComponent } from './modules/hospitals/wbc-add-hopital/wbc-add-hopital.component';
import { WbcNewHospitalDetailsComponent } from './modules/hospitals/wbc-add-hopital/wbc-new-hospital-details/wbc-new-hospital-details.component';
import { WbcPlanComponent } from './modules/hospitals/wbc-plan/wbc-plan.component';
import { WbcCampaignContainerComponent } from './modules/campaign/wbc-campaign-container/wbc-campaign-container.component'
import { WbcInsuranceListComponent } from './modules/insurance/wbc-insurance-list/wbc-insurance-list.component';
import { WbcChainContainerComponent } from './modules/hospital-chain/wbc-chain-container/wbc-chain-container.component';
import { WbcCalendarViewContainerComponent } from './modules/calender-view/wbc-calendar-view-container/wbc-calendar-view-container.component';
import { WbcWeeklyReviewContainerComponent } from './modules/weekly-review/wbc-weekly-review-container/wbc-weekly-review-container.component';
import { WbcConferenceContainerComponent } from './modules/conference/wbc-conference-container/wbc-conference-container.component';
import { WbcApprovalsContainerComponent } from './modules/approvals/wbc-approvals-container/wbc-approvals-container.component';
import { WbcCallApprovalsComponent } from './modules/approvals/wbc-call-approvals/wbc-call-approvals.component';
import { WbcConferenceParticipantsComponent } from './modules/conference/wbc-conference-participants/wbc-conference-participants.component';
import { WbcBusinessDashboardComponent } from './modules/business-dashboard/wbc-business-dashboard/wbc-business-dashboard.component';
import { WbcReviewDashboardContainerComponent } from './modules/review-dashboard/wbc-review-dashboard-container/wbc-review-dashboard-container.component';

const routes: Routes = [

  { path: '', component: WbcLoginComponent, canActivate: [WbcAuthGuard] },
  { path: 'console', component: WbcProcedureStatContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'remittance/:id', component: WbcRemittanceComponent, canActivate: [WbcAuthGuard] },
  { path: 'services', component: ServiceListComponent, canActivate: [WbcAuthGuard] },
  { path: 'more', component: MoreComponent, canActivate: [WbcAuthGuard] },
  { path: 'settings', component: SettingsContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'call-analysis', component: WbcCallAnalysisComponent, canActivate: [WbcAuthGuard] },
  { path: 'patch-request', component: WbcPatchRequestComponent, canActivate: [WbcAuthGuard] },
  { path: 'doctors', component: WbcDoctorsComponent, canActivate: [WbcAuthGuard] },
  { path: 'transfer-patch', component: TransferPatchComponent, canActivate: [WbcAuthGuard] },
  { path: 'patch-transfer', component: PatchTransferContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'record-payment', component: RecordPaymentComponent, canActivate: [WbcAuthGuard] },
  { path: 'unused-unack', component: UnusedUnacknowledgeComponent, canActivate: [WbcAuthGuard] },
  { path: 'ongoing-procedures', component: OngoingProceduresComponent, canActivate: [WbcAuthGuard] },
  { path: 'about', component: WbcAboutContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'notification', component: WbcNotificationsComponent, canActivate: [WbcAuthGuard] },
  { path: 'doctor-calls', component: DoctorCallsComponent, canActivate: [WbcAuthGuard] },
  { path: 'account', component: MyAccountComponent, canActivate: [WbcAuthGuard] },
  { path: 'doctor-profile', component: WbcDoctorProfileComponent, canActivate: [WbcAuthGuard] },
  { path: 'hospitals', loadChildren: () => import('./modules/hospitals/hospitals.module').then(m => m.HospitalsModule), canLoad: [WbcAuthGuard] },
  { path: 'sbo', loadChildren: () => import('./modules/sbo/sbo.module').then(m => m.SboModule), canLoad: [WbcAuthGuard] },
  { path: 'capability-review', component: CapabilityContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'performance-band', component: PerformanceBandComponent, canActivate: [WbcAuthGuard] },
  { path: 'district-profile', component: DistPopulationContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'target', component: ReporteeTargetComponent, canActivate: [WbcAuthGuard] },
  { path: 'add-doctor-list', component: WbcAddDoctorComponent, canActivate: [WbcAuthGuard] },
  { path: 'add-new-doctor', component: WbcNewDocDetailsComponent, canActivate: [WbcAuthGuard] },
  { path: 'add-hospital-list', component: WbcAddHopitalComponent, canActivate: [WbcAuthGuard] },
  { path: 'add-new-hospital', component: WbcNewHospitalDetailsComponent, canActivate: [WbcAuthGuard] },
  { path: 'add-plan', component: WbcPlanComponent, canActivate: [WbcAuthGuard] },
  { path: 'campaign', component: WbcCampaignContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'insurance', component: WbcInsuranceListComponent, canActivate: [WbcAuthGuard] },
  { path: 'business-dashboard', component: WbcBusinessDashboardComponent, canActivate: [WbcAuthGuard] },
  { path: 'review-dashboard', component: WbcReviewDashboardContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'hospital-chain', component: WbcChainContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'calendar', component: WbcCalendarViewContainerComponent, canActivate: [WbcAuthGuard] },
  { path: 'weekly-review', component: WbcWeeklyReviewContainerComponent, canActivate: [WbcAuthGuard] },
  { path:'conference',component:WbcConferenceContainerComponent, canActivate:[WbcAuthGuard]},
  { path:'conference-participants',component:WbcConferenceParticipantsComponent, canActivate:[WbcAuthGuard]},
  { path:'approvals',component:WbcApprovalsContainerComponent, canActivate:[WbcAuthGuard]},
  { path:'call-approvals',component:WbcCallApprovalsComponent, canActivate:[WbcAuthGuard]}

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
