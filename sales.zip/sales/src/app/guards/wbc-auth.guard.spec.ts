import { TestBed } from '@angular/core/testing';

import { WbcAuthGuard } from './wbc-auth.guard';

describe('WbcAuthGuard', () => {
  let guard: WbcAuthGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(WbcAuthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
