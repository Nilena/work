import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
  CanLoad,
  Route,
  UrlSegment
} from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { WbcAuthService } from '../services/wbc-auth.service';
import { WbcUserConfigManagerService } from '../services/wbc-user-config-manager.service';
import { DEPARTMENT } from '../app.config';

@Injectable({
  providedIn: 'root'
})
export class WbcAuthGuard implements CanActivate,CanLoad {
  constructor(private authService: WbcAuthService,private router: Router,public dialog: MatDialog,private userConfigService:WbcUserConfigManagerService) {}
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot,
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    return this.authService.isLoggedIn.pipe(
      take(1),
      map((isLoggedIn: boolean) => {

        this.dialog.closeAll();
        let baseUrl = this.authService.getSplitUrl(state.url);
        baseUrl = this.authService.getSplitUrlDoubleHash(baseUrl);
        if (baseUrl != "/") { 

          if (!isLoggedIn) {

            this.router.navigate(['']);
            return isLoggedIn
          }
          else if((this.authService.getUserDetails()?.department === DEPARTMENT.FIELD_OPERATION || this.authService.getUserDetails()?.department === DEPARTMENT.PMT) && this.userConfigService.getConfig?.allowedRoutes.includes(baseUrl)){
            return isLoggedIn;
          }
          else if((this.authService.getUserDetails()?.department === DEPARTMENT.SALES )){
            return isLoggedIn;
          }
          else{
            return !isLoggedIn;
          }
        } else {

          if (isLoggedIn) {

            if (this.authService.getUserDetails()?.userType === 36)     
            this.router.navigate(['sbo']); 
            else if((this.authService.getUserDetails()?.department === DEPARTMENT.FIELD_OPERATION || this.authService.getUserDetails()?.department === DEPARTMENT.PMT) && this.userConfigService.getConfig?.allowedRoutes.includes(baseUrl)){
              this.router.navigate(['services']);
            }
            else if((this.authService.getUserDetails()?.department === DEPARTMENT.SALES )){
              this.router.navigate(['console']);           
            }
          }
          return !isLoggedIn;
        }
      })
    );
  }

  canLoad(route: Route, segments: UrlSegment[]): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    return this.authService.isLoggedIn.pipe(
      take(1),
      map((isLoggedIn: boolean) => {
        this.dialog.closeAll();
        if (route.path != "/") { 
          if (!isLoggedIn) {
            this.router.navigate(['']);
          }
          return isLoggedIn;
        } 
      })
    );
  }
}
