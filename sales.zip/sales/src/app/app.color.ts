export const ROW_STYLE_COLOR  = {
    GREEN : 'green',
    RED : 'red',
    BLUE : 'blue',
    ORANGE : 'orange',
    GREY : 'grey',
  }