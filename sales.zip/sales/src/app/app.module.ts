import { BrowserModule } from '@angular/platform-browser';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import {
  HttpClient,
  HttpClientModule,
  HTTP_INTERCEPTORS
} from '@angular/common/http';
import { WBCErrorInterceptor } from './services/wbc-error-interceptor';
import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './modules/material/material.module';
import { SharedModule } from './shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppEnumModule } from './app-enum.module'
import { LoginModule } from './modules/login/login.module';
import { ProcedureStatisticsModule } from './modules/procedure-statistics/procedure-statistics.module';
import { WbcConfigInitializerService } from './services/wbc-config-initializer.service';
import { SalesDashboardModule } from './modules/sales-dashboard/sales-dashboard.module'
import { RemittanceModule } from './modules/remittance/remittance.module';
import { CallAnalysisModule } from './modules/call-analysis/call-analysis.module'
import { ServicesModule } from './modules/services/services.module';
import { SettingsModule } from './modules/settings/settings.module';
import { PatchRequestModule } from './modules/patch-request/patch-request.module';
import { DoctorsModule } from './modules/doctors/doctors.module';
import { TransferPatchModule } from './modules/transfer-patch/transfer-patch.module';
import { PatchTransferModule } from './modules/patch-transfer/patch-transfer.module';
import { RecordPaymentModule } from './modules/record-payment/record-payment.module';
import { UnusedUnacknowledgeModule } from './modules/unused-unacknowledge/unused-unacknowledge.module';
import { AboutModule } from './modules/about/about.module';
import { HeaderModule } from './modules/header/header.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { OngoingProceduresModule } from './modules/ongoing-procedures/ongoing-procedures.module';
import { HospitalCallsModule } from './modules/hospital-calls/hospital-calls.module';
import { NotificationsModule } from './modules/notifications/notifications.module'
import { APP_BASE_HREF, DatePipe } from '@angular/common';
import { DoctorCallsModule } from './modules/doctor-call/doctor-calls.module';
import { AccountModule } from './modules/account/account.module';
import { DoctorProfileModule } from './modules/doctor-profile/doctor-profile.module';
import { CapabilityReviewModule } from './modules/capability-review/capability-review.module';
import { PerformanceBandModule } from './modules/performance-band/performance-band.module';
import { DistPopulationProfileModule } from './modules/dist-population-profile/dist-population-profile.module';
import { WbcPageHeaderComponent } from './shared/wbc-page-header/wbc-page-header.component';
import { WbcReporteeListComponent } from './modules/target/wbc-reportee-list/wbc-reportee-list.component'
import { TargetModule } from './modules/target/target.module'
import { ThemeModule } from './modules/theme/theme.module';
import { wbcCaretouchTheme } from './modules/theme/themeOptions/wbc-caretouch.theme';
import { wbcInsightTheme } from './modules/theme/themeOptions/wbc-insight.theme';
import { wbcDefaultTheme } from './modules/theme/themeOptions/wbc-default.theme';
import { CampaignModule } from './modules/campaign/campaign.module'
import { InsuranceModule } from './modules/insurance/insurance.module'
import { HospitalChainModule } from './modules/hospital-chain/hospital-chain.module'
import { ConferenceModule } from './modules/conference/conference.module'
import { BusinessDashboardModule } from './modules/business-dashboard/business-dashboard.module'
import { CalenderViewModule } from './modules/calender-view/calender-view.module'
import { CalendarModule } from '../../../general-lib/src/lib/modules/calendar/calendar.module';
import { ApprovalsModule } from './modules/approvals/approvals.module'
import { ReviewDashboardModule } from './modules/review-dashboard/review-dashboard.module'
import { WeeklyReviewModule } from './modules/weekly-review/weekly-review.module'
import { WBCRequestInterceptor } from './services/wbc-request-interceptor';

export function initialiseAPP(
  HttpClient: HttpClient,
  configService: WbcConfigInitializerService
) {
  return configService.init(HttpClient);
}
@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    ServiceWorkerModule.register('custom-service-worker.js', {
      enabled: true
    }),
    MaterialModule,
    SharedModule,
    AppRoutingModule,
    HttpClientModule,
    LoginModule,
    ProcedureStatisticsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    AppEnumModule,
    SalesDashboardModule,
    RemittanceModule,
    ServicesModule,
    SettingsModule,
    CallAnalysisModule,
    PatchRequestModule,
    UnusedUnacknowledgeModule,
    DoctorsModule,
    TargetModule,
    TransferPatchModule,
    PatchTransferModule,
    RecordPaymentModule,
    AboutModule,
    OngoingProceduresModule,
    HeaderModule,
    AttendanceModule,
    NotificationsModule,
    HospitalCallsModule,
    DoctorCallsModule,
    AccountModule,
    DoctorProfileModule,
    CapabilityReviewModule,
    CampaignModule,
    PerformanceBandModule,
    DistPopulationProfileModule,
    HospitalChainModule,
    ConferenceModule,
    InsuranceModule,
    CalenderViewModule,
    BusinessDashboardModule,
    CalendarModule,
    ApprovalsModule,
    ReviewDashboardModule,
    WeeklyReviewModule,
    ThemeModule.forRoot({
      themes: [wbcCaretouchTheme, wbcInsightTheme, wbcDefaultTheme],
      active: 'default'
    }),
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: WBCErrorInterceptor,
    multi: true,
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: WBCRequestInterceptor,
    multi: true,
  },
  {
    provide: APP_INITIALIZER, useFactory: initialiseAPP,
    deps: [HttpClient, WbcConfigInitializerService],
    multi: true
  }, DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
