export const isNullOrUndefined = function (checkVal) {
  return checkVal === null || checkVal === undefined;
};

export const getPercentage = function (val, totalVal, dec = 1) {
  return totalVal !== 0 ? `${((100 * val) / totalVal).toFixed(dec)}%` : '-';
};

export function downloadDocument(url: string, fileName: string) {
  let link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  window.URL.revokeObjectURL(link.href);
}
