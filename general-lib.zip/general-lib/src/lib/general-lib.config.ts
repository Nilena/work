export let USER_TYPES={
    "nurse": 1,
    "doctor": 2,
    "tech": [3,20],
    "operator": [5,14],
    "dataScientist": 6,
    "developer": 7,
    "admin": 10,
    "spa":17,
    "cfa":18,
    "monitoring":[21,22],
    "accountant":[32],
    "sales":[12],
    "insight":[12],
    "caretouch":[12],
    "spoUser":[35]
}