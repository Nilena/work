export interface WbcDropDown {
  value: any;
  viewValue: string;
  id?: string;
}
