import { CognitoUserSession } from "amazon-cognito-identity-js";

export interface CognitoConfig {
  COGNITO_USER_POOL_ID: string;
  COGNITO_APP_CLIENTID: string;
}
export interface ForgotPW {
  email: string;
  code?: string;
  password?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface ResetPW {
  password: string;
}

export interface Login {
  email: string;
  password: string;
}

export interface ErrAuth {
  name?: string;
  code?: string;
}

export interface AuthResponse {
  message?: string;
  data?: ErrAuth | CognitoUserSession;
}
