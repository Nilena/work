import { Injectable } from '@angular/core';
import {
  AuthenticationDetails,
  CognitoUser,
  CognitoUserPool,
  IAuthenticationCallback,
  ICognitoUserPoolData,
} from 'amazon-cognito-identity-js';
import { Observable } from 'rxjs';
import {
  AuthResponse,
  CognitoConfig,
  ForgotPW,
  LoginData,
  ResetPW,
} from '../models/cognito.model';

@Injectable({
  providedIn: 'root',
})
export class WbcCognitoService {
  // for the initial authentication attempt
  intialCognitoUser!: CognitoUser;
  cognitoConfig!: CognitoConfig;
  private authenticationFlowType = 'USER_PASSWORD_AUTH';
  constructor() {}

  authenticate(
    value: LoginData,
    cognitoConfig: CognitoConfig
  ): Observable<AuthResponse> {
    this.cognitoConfig = cognitoConfig;
    console.log('ressuccess', value, cognitoConfig);
    return new Observable((observer) => {
      let calBack: IAuthenticationCallback = {
        onSuccess: (result) => {
          console.log('success', result);

          observer.next({
            message: 'success',
            data: result,
          });
          observer.complete();
        },
        onFailure: (err) => {
          console.log('err', err);
          observer.next({
            message: 'error',
            data: err,
          });
          observer.complete();
        },
        newPasswordRequired: (userAttributes, requiredAttributes) => {
          console.log(
            'newPasswordRequired',
            userAttributes,
            requiredAttributes,
            this.intialCognitoUser
          );
          observer.next({
            message: 'newpasswordrequired',
            data: userAttributes,
          });
          observer.complete();
        },
      };

      this.cognitoLogin(value.email, value.password, calBack);
    });
  }

  /**
    login using Cognito 
     * @param username Name of the user or email
     * @param password user password
     * @param callbacks callback handle
    */
  cognitoLogin(
    username: string,
    password: string,
    callbacks: IAuthenticationCallback
  ) {
    let authenticationDetails = new AuthenticationDetails({
      Username: username,
      Password: password,
    });

    this.getCognitoUserByUserName(username).then((cognitoUser: CognitoUser) => {
      console.log('cognitoUserffffff', cognitoUser);
      this.intialCognitoUser = cognitoUser;
      cognitoUser.setAuthenticationFlowType(this.authenticationFlowType);
      return cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: (session) => {
          callbacks.onSuccess(session);
        },
        onFailure: (err) => {
          callbacks.onFailure(err);
        },
        newPasswordRequired: (userAttributes, requiredAttributes) => {
          if (callbacks.newPasswordRequired) {
            // null check is implemented to avoid type script error
            callbacks.newPasswordRequired(userAttributes, requiredAttributes);
          }
        },
      });
    });
  }

  resetPassword(
    value: ResetPW,
    cognitoConfig: CognitoConfig
  ): Observable<AuthResponse> {
    this.cognitoConfig = cognitoConfig;
    console.log('value', value);
    return new Observable((observer) => {
      let calBack: IAuthenticationCallback = {
        onSuccess: (result) => {
          console.log('success', result);
          observer.next({
            message: 'success',
            data: result,
          });
          observer.complete();
        },
        onFailure: (err) => {
          console.log('err', err);
          observer.next({
            message: 'error',
            data: err,
          });
          observer.complete();
        },
      };

      this.cognitoCompleteNewPasswordChallange(value.password, calBack);
    });
  }

  /**
   * Fucntion to handle update password on initial login by cognito
   * @param newPassword new password to be updated
   * @param callback call back handle
   */
  cognitoCompleteNewPasswordChallange(
    newPassword: string,
    callback: IAuthenticationCallback
  ) {
    console.log('intialCognitoUser1', this.intialCognitoUser, newPassword);
    if (this.intialCognitoUser) {
      this.intialCognitoUser.completeNewPasswordChallenge(newPassword, null, {
        onSuccess: (session) => {
          callback.onSuccess(session);
        },
        onFailure: (err) => {
          callback.onFailure(err);
        },
      });
    } else {
      //when initialCognitoUser is undefined
      let err = {
        code: 'UserNotFoundException',
        message: 'error',
      };
      callback.onFailure(err);
    }
  }

  /**
   * Function to reset password with verfication code via mail
   * @param username
   * @param verificationCode
   * @param password
   * @param callback
   */
  cognitoConfirmNewPassword(
    username: string,
    verificationCode: string,
    password: string
  ) {
    return this.getCognitoUserByUserName(username).then(
      (cognitoUser: CognitoUser) => {
        return new Promise((resolve) => {
          cognitoUser.confirmPassword(verificationCode, password, {
            onSuccess: function (succ) {
              const result = {
                message: 'success',
                data: succ,
              };
              resolve(result);
            },
            onFailure: function (err) {
              console.log('err2', err);
              const result = {
                message: 'error',
                data: err,
              };
              resolve(result);
            },
          });
        });
      }
    );
  }

  forgotPasswordWithCode(
    value: ForgotPW,
    cognitoConfig: CognitoConfig
  ): Observable<AuthResponse> {
    console.log('value,', value, cognitoConfig);
    const { code, password, email } = value;
    this.cognitoConfig = cognitoConfig;
    return new Observable((observer) => {
      if (code === undefined || password === undefined) {
        // Handle the case where code or password is undefined
        observer.error('Code and password are required');
        return;
      }
      this.cognitoConfirmNewPassword(email, code, password).then((result) => {
        console.log('result', result);
        observer.next(result as AuthResponse);
        observer.complete();
      });
    });
  }

  /**
   * Function to trigger cognito forgot password step
   * @param username maildId to send OTP (code for reseting password)
   * @param callback callback to excecute upon successfully senting verfication code
   */
  congnitoForgotPwMailRequest(username: string) {
    console.log('username', username);
    return this.getCognitoUserByUserName(username).then(
      (cognitoUser: CognitoUser) => {
        return new Promise((resolve) => {
          cognitoUser.forgotPassword({
            onSuccess: function (succ) {
              const result = {
                message: 'success',
                data: succ,
              };
              resolve(result);
            },
            onFailure: function (err) {
              console.log('err2', err);
              const result = {
                message: 'error',
                data: err,
              };
              resolve(result);
            },
            inputVerificationCode(data) {
              console.log('data', data);
              const result = {
                message: 'success',
                data: data,
              };
              resolve(result);
            },
          });
        });
      }
    );
  }

  forgotPasswordForCode(
    value: ForgotPW,
    cognitoConfig: CognitoConfig
  ): Observable<AuthResponse> {
    console.log('value,', value, cognitoConfig);
    this.cognitoConfig = cognitoConfig;
    return new Observable((observer) => {
      this.congnitoForgotPwMailRequest(value.email).then((result) => {
        console.log('result', result);
        observer.next(result as AuthResponse);
        observer.complete();
      });
    });
  }

  /**
   * Function to return cognitouser details corresponding to the username
   * @param userName mailId to get cognitoUser object of
   * @returns cognitoUser corresponding to the username
   */
  getCognitoUserByUserName(userName: string): Promise<CognitoUser> {
    console.log('userName', userName);
    return new Promise((resolve) => {
      this.getUserPoolData().then((poolData: ICognitoUserPoolData) => {
        let userPool = new CognitoUserPool(poolData);
        console.log('userPool', userPool);
        let userData = {
          Username: userName,
          Pool: userPool,
        };
        let cognitoUser = new CognitoUser(userData);
        console.log('cognitoUser', cognitoUser);
        resolve(cognitoUser);
      });
    });
  }

  /** 
    get cognito user pool data
     */
  getUserPoolData(): Promise<ICognitoUserPoolData> {
    return new Promise((resolve) => {
      console.log('this.cognitoConfig', this.cognitoConfig);
      let data: ICognitoUserPoolData = {
        UserPoolId: this.cognitoConfig.COGNITO_USER_POOL_ID,
        ClientId: this.cognitoConfig.COGNITO_APP_CLIENTID,
      };
      resolve(data);
    });
  }

  refreshAccessToken(callbacks: IAuthenticationCallback,config:CognitoConfig, canReload:boolean=false): void {
      const poolData = this.getPoolData(config)
      this.cognitoConfig = config
      let userPool = new CognitoUserPool(poolData);
      var cognitoUser = userPool.getCurrentUser();
      if (cognitoUser != null) {
        cognitoUser.getSession((err: any, session: any) => {
          if (err) {
            this.cognitoLogout(config);
            callbacks.onFailure(err);
          } else {
            callbacks.onSuccess(session);
            canReload && location.reload();
          }
        });
      } else {
        this.cognitoLogout(config);
        callbacks.onFailure({err:"error"});
      }
  }

  cognitoLogout(config:CognitoConfig): void {
      const poolData = this.getPoolData(config)
      let userPool = new CognitoUserPool(poolData);
      let cognitoUser = userPool.getCurrentUser();
      cognitoUser?.signOut();
  }

  getPoolData(config:CognitoConfig){
    const poolData = {
      UserPoolId: config.COGNITO_USER_POOL_ID,
      ClientId: config.COGNITO_APP_CLIENTID,
    }
    return poolData
  }
}
