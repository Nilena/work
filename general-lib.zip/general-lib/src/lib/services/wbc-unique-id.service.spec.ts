import { TestBed } from '@angular/core/testing';

import { WbcUniqueIdService } from './wbc-unique-id.service';

describe('WbcUniqueIdService', () => {
  let service: WbcUniqueIdService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcUniqueIdService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
