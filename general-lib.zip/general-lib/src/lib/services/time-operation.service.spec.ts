import { TestBed } from '@angular/core/testing';

import { TimeOperationService } from './time-operation.service';
import moment from 'moment';

describe('TimeOperationService', () => {
  let service: TimeOperationService;
  const dateMock = '2024-01-18';
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TimeOperationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should convert time to 24-hour format', () => {
    const inputTime = '10:30 AM';
    const expectedOutput = '10';
    const format = { hour: 'HH', formattedHr: 'hh:mm A' }

    const result = service.convertTo24HrFormat(inputTime,format);
    expect(result).toBe(expectedOutput);
  });
  
  it('should get week range based on input date', () => {
    const inputDate = '2024-01-15';
    const format = {
      formattedDate: 'YYYY-MM-DD',
      day: 'dddd',
      month: 'MM',
      year: 'YYYY',
      shortDay: 'ddd',
    };
  
    const weekRange = service.getWeekRange(inputDate, format);
  
    expect(weekRange).toEqual([
      { fullDate: '2024-01-14', dayname: 'Sunday', month: '01', year: '2024', date: '14', day: 'Sun', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-15', dayname: 'Monday', month: '01', year: '2024', date: '15', day: 'Mon', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-16', dayname: 'Tuesday', month: '01', year: '2024', date: '16', day: 'Tue', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-17', dayname: 'Wednesday', month: '01', year: '2024', date: '17', day: 'Wed', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-18', dayname: 'Thursday', month: '01', year: '2024', date: '18', day: 'Thu', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-19', dayname: 'Friday', month: '01', year: '2024', date: '19', day: 'Fri', isCurrentDate: false, events: [] },
      { fullDate: '2024-01-20', dayname: 'Saturday', month: '01', year: '2024', date: '20', day: 'Sat', isCurrentDate: false, events: [] },
    ]);
  });
  
  it('should get month name', () => {
    const monthName = service.getMonthName('03', 'MMMM');
    expect(monthName).toBe('March');
  });

  it('should get days in a month', () => {
    const daysInMarch = service.getDaysInAMonth('2022', '03');
    expect(daysInMarch).toBe(31);
  });

  it('should get month number', () => {
    const monthNumber = service.getMonthNumber('April', 'MMMM');
    expect(monthNumber).toBe('04');
  });

  it('should get day name', () => {
    const dayName = service.getDayName('2022', '03', '01', 'dddd');
    expect(dayName).toBe('Tuesday');
  });

  it('should get formatted date', () => {
    const formattedDate = service.getFormatedDate('2022', '03', '15', 'YYYY-MM-DD');
    expect(formattedDate).toBe('2022-03-15');
  });

  it('should get formatted date from input date', () => {
    const formattedDate = service.getDate(new Date('2022-03-15'), 'YYYY-MM-DD');
    expect(formattedDate).toBe('2022-03-15');
  });

  it('should check if the provided hour is the current time', () => {
    const mockCurrentTime = moment('12:00 PM', 'h:mm A').toDate();
    spyOn(moment, 'utc').and.returnValue(moment(mockCurrentTime).utc());
    const isCurrentTime = service.isCurrentTime('12:00 PM','YYYY-MM-DD');
    expect(isCurrentTime).toBe(false);
  });
  it('should get the year correctly', () => {
    const result = service.getYear(dateMock);

    expect(result).toBe(2024);
  });

  it('should get the month correctly', () => {
    const result = service.getMonth(dateMock);

    expect(result).toBe('01');
  });

  it('should get the date correctly', () => {
    const result = service.getDateObj(dateMock);
    expect(result).toBe(18);
  });

});
