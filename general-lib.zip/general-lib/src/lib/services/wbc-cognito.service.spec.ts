import { TestBed } from '@angular/core/testing';

import { WbcCognitoService } from './wbc-cognito.service';

describe('WbcCognitoService', () => {
  let service: WbcCognitoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcCognitoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
