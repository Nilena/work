import { TestBed } from '@angular/core/testing';

import { WbcAppDataService } from './wbc-app-data.service';

describe('WbcAppDataService', () => {
  let service: WbcAppDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcAppDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
