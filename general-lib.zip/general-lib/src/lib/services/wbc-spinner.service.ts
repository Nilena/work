import { Injectable,ComponentFactoryResolver,Inject, Renderer2, RendererFactory2 } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import {WbcDynamicSpinnerComponent } from '../modules/dynamic-spinner/wbc-dynamic-spinner/wbc-dynamic-spinner.component'
@Injectable({
  providedIn: 'root'
})
export class WbcSpinnerService {
   renderer: Renderer2 ;
   spinnerState = new BehaviorSubject<boolean>(false);
   factoryResolver;
  constructor(@Inject(ComponentFactoryResolver) factoryResolver,rendererFactory: RendererFactory2) {
    this.factoryResolver = factoryResolver;
    this.renderer = rendererFactory.createRenderer(null, null);
   }
   /**
    * Method to show the spinner
    */
  showSpinner(){
    
    this.spinnerState.next(true)
  }
  /**
   * Method to hide the spinner
   */
  hideSpinner(){
    
    this.spinnerState.next(false)
  }
  /**
   * 
   * @param elementToHide  
   */
  showSpinnerDisableElement(elementToDisable){
    this.renderer.addClass(elementToDisable.nativeElement, 'disableDiv');
    this.spinnerState.next(true)
  }
  /**
   * 
   * @param elementToShow 
   */
  disableSpinnerShowElement(elementToShow){
    this.renderer.removeClass(elementToShow.nativeElement, 'disableDiv');
    this.spinnerState.next(false)
   
  }
   /**
   * 
   * @param elementToHide  
   */
  showSpinnerHideElement(elementToHide){
    console.log(this.renderer)
    this.renderer.addClass(elementToHide.nativeElement, 'hidden');
    this.spinnerState.next(true)
  }
  /**
   * 
   * @param elementToShow 
   */
  hideSpinnerShowElement(elementToShow){
    this.renderer.removeClass(elementToShow.nativeElement, 'hidden');
    this.spinnerState.next(false)
   
  }
  /**
   * 
   * @param spinnerOptions 
   */
  chooseSpinner(spinnerOptions){
    if(spinnerOptions.spinner){
      if(spinnerOptions.elementToHide){
        this.showSpinnerHideElement(spinnerOptions.elementToHide)
      }
      else if(spinnerOptions.elementToReplace){
        this.showSpinnerReplaceElement(spinnerOptions.elementToReplace)
      }
      else if(spinnerOptions.elementToDisable){
        this.showSpinnerDisableElement(spinnerOptions.elementToDisable)
      }
      else {
        this.showSpinner()
      }
    }
   

  }
/**
 * 
 * @param elementToReplace 
 */
  showSpinnerReplaceElement(elementToReplace){
    console.log("replau",elementToReplace.element)

    for(var i = 0; i <elementToReplace.element.nativeElement.children.length; i++)
    { 
      let child = <HTMLScriptElement>elementToReplace.element.nativeElement.children[i];
      
        this.renderer.setStyle(child,'display','none');

      
    }
  
    const childComponent = this.factoryResolver.resolveComponentFactory(WbcDynamicSpinnerComponent); 
    let itemRef = elementToReplace.createComponent(childComponent);
    itemRef.destroy();
   
    itemRef.location.nativeElement.childNodes[0].classList.remove('hidden'); 
   
    this.renderer.appendChild(elementToReplace.element.nativeElement,itemRef.location.nativeElement);
  }
  /**
   * 
   * @param elementToReplace 
   */
  hideSpinnerReplaceElement(elementToReplace){
    
    var nativeElement = elementToReplace.element.nativeElement;
    console.log("inside the hide",nativeElement)
    let elements = nativeElement.querySelectorAll('.wrapped-spinner');
    console.log("the elements",elements)
    for(var i = 0; i < elements.length; i++)
    { 
      this.renderer.removeChild(nativeElement, elements[i]);
    }
    for(var i = 0; i < nativeElement.children.length; i++)
    { 
      let child = <HTMLScriptElement>nativeElement.children[i];
      console.log("the child",child)
      this.renderer.setStyle(child,'display','block');
    }
    
    
  }
}
