import { TestBed } from '@angular/core/testing';

import { WbcErrorInterceptorService } from './wbc-error-interceptor.service';

describe('WbcErrorInterceptorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcErrorInterceptorService = TestBed.get(WbcErrorInterceptorService);
    expect(service).toBeTruthy();
  });
});
