import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WbcLocalStorageService {

  constructor() { }
  //store or get data to/from localStorage
storeObject(key:string,value:object):void {
  localStorage.setItem(key,JSON.stringify(value));
}
retrieveObject(key:string) {
  return (JSON.parse(localStorage.getItem(key)));
}
 removeObject(key:string):void{
  localStorage.removeItem(key);
}
retrieveItem(key:string):string{
  return(localStorage.getItem(key));
}
storeItem(key:string,value:string):void{
  return(localStorage.setItem(key,value));
}


  
}
