import { TestBed } from '@angular/core/testing';

import { WbcSortService } from './wbc-sort.service';

describe('WbcSortService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcSortService = TestBed.get(WbcSortService);
    expect(service).toBeTruthy();
  });
});
