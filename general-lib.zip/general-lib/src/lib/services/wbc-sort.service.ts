import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WbcSortService {
  constructor() {}

  sortByAsc(property) {
    return function (a: any, b: any) {
      if (a[property] < b[property]) {
        return -1;
      }
      if (a[property] > b[property]) {
        return 1;
      }
      return 0;
    };
  }
  sortByDesc(property){
    return function (a: any, b: any){
      if (a[property] < b[property]) {
        return 1;
      }
      if (a[property] > b[property]) {
        return -1;
      }
      return 0;
    };
  }
}
