import { TestBed } from '@angular/core/testing';

import { CalendarService } from './calendar.service';
import moment from 'moment';
import { TimeOperationService } from './time-operation.service';

describe('CalendarService', () => {
  let calendarService: CalendarService;
  let timeService: TimeOperationService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CalendarService, TimeOperationService]
    });
    calendarService = TestBed.inject(CalendarService);
    timeService = TestBed.inject(TimeOperationService);

  });

  it('should be created', () => {
    expect(calendarService).toBeTruthy();
  });

  it('should update data', () => {
    const newData = { month: '02', year: '2022', date: '15', view: 'month' };
    calendarService.updateData(newData);
    calendarService.data$.subscribe(data => {
      expect(data).toEqual(newData);
    });
  });
  // it('should update data', () => {
  //   const newData = { month: '02', year: '2022', date: '15' }
  //   calendarService.updateEmittedData(newData);
  //   calendarService.eventDetails$.subscribe(data => {
  //     expect(data).toEqual(newData);
  //   });
  // });


  it('should generate an array of hours', () => {
    const format = { day: 'dddd', formattedHr: 'hh:mm A' }
    const hourList = calendarService.getHourList(format);
    expect(hourList.length).toBe(24);
    hourList.forEach((hour, index) => {
      expect(hour.name).toBeDefined();
      expect(hour.value).toBe((index).toString().padStart(2, '0'));
      expect(hour.month).toBe(calendarService.displayedMonth);
      expect(hour.year).toBe(calendarService.displayedYear);
      expect(hour.date).toBe(calendarService.displayedDate);
      expect(hour.day).toBe(timeService.getDayName(calendarService.displayedYear, calendarService.displayedMonth, calendarService.displayedDate, 'dddd'));
    });

  });


});