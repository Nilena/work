import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { WbcSpinnerService } from './wbc-spinner.service';

@Injectable({
  providedIn: 'root'
})
/**
 * Responsible for all the Ajax calls from the client side.
 *
 */
export class WbcAjaxService {

  constructor(private http: HttpClient, private spinnerService: WbcSpinnerService) {




  }
  /**
   * Responsible for making the post to API
   * @param data  Data to be posted to the server
   * @param operation The operation/API end point to where the post is made.
   * @example Simply call it with data and operation
   *   postRequest({},"<api end point name>") if there is no data to post
   *   postRequest(<Data Object>,"<api end point name>")
   */
  postRequest(data, operation: string, appData: { token: string, apiBaseUrl: string }, spinnerOptions) {
    console.log("inside the post request", data, operation, appData, spinnerOptions)
    this.spinnerService.chooseSpinner(spinnerOptions);
    let url = '';
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'operation': operation,
        'Authorization': appData.token
      })
    };
    console.log("reecahed here")
    url = appData.apiBaseUrl + "/v2";
    return this.http.post(url, data, httpOptions)

  }

  /**
   * Responsible for making the post to API
   * @param data  Data to be posted to the server
   * @param operation The operation/API end point to where the post is made.
   * @example Simply call it with data and operation
   *   postRequest({},"<api end point name>") if there is no data to post
   *   postRequest(<Data Object>,"<api end point name>")
   */
  getRequest(operation, appData: { token: string, apiBaseUrl: string }, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'operation': operation,
        'token': appData.token
      })
    };
    return this.http.get(appData.apiBaseUrl, httpOptions)

  }



  /**
   * Responsible for making the post to API
   * @param data  Data to be posted to the server
   * @param operation The operation/API end point to where the post is made.
   * @example Simply call it with data and operation
   *   postRequest({},"<api end point name>") if there is no data to post
   *   postRequest(<Data Object>,"<api end point name>")
   */
  getRequestWithoutOperationHeader(operation, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let token = appData.token
    let url = '';
    if (token == null) {
      token = 'token';
    }

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    url = appData.apiBaseUrl + "/v2";
    return this.http.get(url + "/" + routePath + "/" + operation, httpOptions);
  }

  /**
 * Responsible for making the post to API
 * @param data  Data to be posted to the server
 * @param operation The operation/API end point to where the post is made.
 * @example Simply call it with data and operation
 *   postRequest({},"<api end point name>") if there is no data to post
 *   postRequest(<Data Object>,"<api end point name>")
 */
  getRequestWithoutOperationHeaders(operation, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let token = appData.token
    let url = '';
    if (token == null) {
      token = 'token';
    }

    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    url = appData.apiBaseUrl + "-" + routePath;
    return this.http.get(url + "/" + operation, httpOptions);
  }
  /**
  * Responsible for making the post to API
  * @param data  Data to be posted to the server
  * @param operation The operation/API end point to where the post is made.
  * @example Simply call it with data and operation
  *   postRequest({},"<api end point name>") if there is no data to post
  *   postRequest(<Data Object>,"<api end point name>")
  */

  getWithRoutePath(operation, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let token = appData.token
    if (token == null) {
      token = 'token';
    }
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': token
      })
    };
    return this.http.get(appData.apiBaseUrl +"/" + routePath + "/" + operation, httpOptions);
  }


  /**
 * Responsible for making the post to API
 * @param data  Data to be posted to the server
 * @param operation The operation/API end point to where the post is made.
 * @example Simply call it with data and operation
 *   postRequest({},"<api end point name>") if there is no data to post
 *   postRequest(<Data Object>,"<api end point name>")
 */
  postRequestWithoutOperationHeader(operation, data, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let url = '';
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': appData.token
      })
    };
    url = appData.apiBaseUrl + "/v2";
    return this.http.post(url + "/" + routePath + "/" + operation, data, httpOptions)

  }

  /**
 * Responsible for making the post to API
 * @param data  Data to be posted to the server
 * @param operation The operation/API end point to where the post is made.
 * @example Simply call it with data and operation
 *   postRequest({},"<api end point name>") if there is no data to post
 *   postRequest(<Data Object>,"<api end point name>")
 */
  postRequestWithOutOperationHeaders(operation, data, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let url = '';
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': appData.token
      })
    };
    url = appData.apiBaseUrl + "-" + routePath;
    return this.http.post(url + "/" + operation, data, httpOptions)

  }

  postWithDifferentUrl(spinnerOptions, url, data) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/x-www-form-urlencoded'
      })
    };
    console.log("the bocy", url, data, httpOptions)
    return this.http.post(url, data, httpOptions)

  }

  /**
  * Responsible for making the put to API
  * @param data  Data to be put to the server
  * @param operation The operation/API end point to where the put is made.
  * @example Simply call it with data and operation
  *   putRequest({},"<api end point name>") if there is no data to put
  *   putRequest(<Data Object>,"<api end point name>")
  */
  putRequestWithOutOperationHeaders(operation, data, appData: { token: string, apiBaseUrl: string }, routePath: string, spinnerOptions) {
    this.spinnerService.chooseSpinner(spinnerOptions);
    let url = '';
    var httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': appData.token
      })
    };
    url = appData.apiBaseUrl + "-" + routePath;
    return this.http.put(url + "/" + operation, data, httpOptions)

  }



  /**
   * 
   * Methode to handle PUT request.
   * @param UploadUrl  DataURL to where the content needs to be uploaded
   * @param Content  Content to be uploaded
   * @param httpOptions  Http options
   */
  putRequest(UploadUrl, Content, httpOptions) {
    var httOption = httpOptions;
    return this.http.put(UploadUrl, Content, httOption);
  }

}



