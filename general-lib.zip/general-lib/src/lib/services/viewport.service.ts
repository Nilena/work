import { Injectable } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';

@Injectable({
  providedIn: 'root'
})
export class ViewportService {
  isMobileView:Boolean;
  constructor(private breakpointObserver: BreakpointObserver) { 
    this.isMobileView = this.breakpointObserver.isMatched(Breakpoints.Handset);
  }
}
