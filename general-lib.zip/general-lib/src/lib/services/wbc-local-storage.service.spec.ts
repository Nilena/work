import { TestBed } from '@angular/core/testing';

import { WbcLocalStorageService } from './wbc-local-storage.service';

describe('WbcLocalStorageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcLocalStorageService = TestBed.get(WbcLocalStorageService);
    expect(service).toBeTruthy();
  });
});
