import { TestBed } from '@angular/core/testing';

import { WbcAuthService } from './wbc-auth.service';

describe('WbcAuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcAuthService = TestBed.get(WbcAuthService);
    expect(service).toBeTruthy();
  });
});
