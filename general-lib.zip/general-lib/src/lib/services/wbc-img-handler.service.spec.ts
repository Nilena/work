import { TestBed } from '@angular/core/testing';

import { WbcImgHandlerService } from './wbc-img-handler.service';

describe('WbcImgHandlerService', () => {
  let service: WbcImgHandlerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WbcImgHandlerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
