import { Inject, Injectable, Renderer2, RendererFactory2 } from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarConfig,
  MatSnackBarHorizontalPosition,
  MatSnackBarRef,
  MatSnackBarVerticalPosition
} from '@angular/material/snack-bar';
import { WbcSnackbarComponent } from '../modules/snackbar/wbc-snackbar/wbc-snackbar.component';
import { DOCUMENT } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class WbcSnackbarService {
  constructor(
    private snackBar: MatSnackBar,
    @Inject(DOCUMENT) private document: Document,
    private rendererFactory: RendererFactory2
  ) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  renderer: Renderer2;
  snackBarRef: MatSnackBarRef<WbcSnackbarComponent>;
  /**
   *
   * @param message snackbar message which needs to be displayed
   * @param type snackbar type eg: success, error, info, warning
   * @param config we can customise the duration,vertical position and horizontal position by default the position will be left bottom and duration will be 3000
   */
  openSnackbar(message, type, config?: MatSnackBarConfig) {
    const defaultConfig: MatSnackBarConfig = {
      duration: 3000,
      horizontalPosition: 'left',
      verticalPosition: 'bottom'
    };
    const snackBarConfig: MatSnackBarConfig = { ...defaultConfig, ...config };
    const style = this.renderer.createElement('style');
    style.innerHTML = `
  .snackbar-container {
    padding:11px 0px 11px 14px !important;
    border-radius: 9px !important;
    background: linear-gradient(120deg, #4a5053 68%, #00adc6 275%);
    width: fit-content !important;
    min-width: 250px !important;
    max-width: 80% !important;
    }
  `;
    this.renderer.appendChild(this.document.head, style);

    this.snackBarRef = this.snackBar.openFromComponent(WbcSnackbarComponent, {
      data: { message: message, type: type },
      panelClass: 'snackbar-container',
      ...snackBarConfig
    });
  }

  closeSnackbar() {
    if (this.snackBarRef) {
      this.snackBarRef.dismiss();
    }
  }
}
