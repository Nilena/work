import { TestBed } from '@angular/core/testing';

import { WbcAjaxService } from './wbc-ajax.service';

describe('WbcAjaxService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: WbcAjaxService = TestBed.get(WbcAjaxService);
    expect(service).toBeTruthy();
  });
});
