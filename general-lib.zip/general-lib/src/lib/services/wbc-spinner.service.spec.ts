import { TestBed, inject } from '@angular/core/testing';

import { WbcSpinnerService } from './wbc-spinner.service';

describe('WbcSpinnerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WbcSpinnerService]
    });
  });

  it('should be created', inject([WbcSpinnerService], (service: WbcSpinnerService) => {
    expect(service).toBeTruthy();
  }));
});
