export const patchStates = {
  unused: 0,
  ongoing: 1,
  completed: 2
};

export const icon_type = {
  success: 'success',
  error: 'error',
  warning: 'warning',
  info: 'info'
};
