import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
@Directive({
  selector: '[libFeatureflag]'
})
export class FeatureflagDirective {

  @Input('libFeatureflag') libFeatureflag: string ;
  @Input() featureConfig: object;

  constructor(
    private vcr: ViewContainerRef,
    private tpl: TemplateRef<any>) {
  }

  ngOnInit() {
    if (this.featureConfig[this.libFeatureflag] ){
      this.vcr.createEmbeddedView(this.tpl);
    }
  }
}
