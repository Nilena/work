import { TemplateRef, ViewContainerRef } from '@angular/core';
import { FeatureflagDirective } from './feature-flag.directive';

describe('FeatureFlagDirective', () => {
  it('should create an instance', () => {
    const vcrMock: ViewContainerRef = {} as ViewContainerRef;
    const tplMock: TemplateRef<any> = {} as TemplateRef<any>;
    const directive = new FeatureflagDirective(vcrMock, tplMock);
    expect(directive).toBeTruthy();
  });
});
