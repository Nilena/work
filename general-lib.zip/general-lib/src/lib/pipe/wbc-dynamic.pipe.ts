import { Pipe, PipeTransform, Injector } from '@angular/core';

@Pipe({
  name: 'wbcDynamic'
})
export class WbcDynamicPipe implements PipeTransform {

  public constructor(private injector: Injector) {
  }

  transform(value: any, pipeToken: any, pipeArgs: any[]): any {
      if (!pipeToken) {
          return value;
      }
      else {
          let pipe = this.injector.get(pipeToken);
          if (Array.isArray(pipeArgs)){
             return pipe.transform(value, ...pipeArgs);
           } 
          else {
            console.log("the pip",pipeArgs)
             return pipe.transform(value, pipeArgs); 
            }
      }
  }

}
