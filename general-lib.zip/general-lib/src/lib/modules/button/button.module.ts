import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonComponent } from './button/button.component';
import { ActionButtonComponent } from './action-button/action-button.component';
import { ButtonWithIconComponent } from './button-with-icon/button-with-icon.component';
import { ButtonWithMatIconComponent } from './button-with-mat-icon/button-with-mat-icon.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [
    ButtonComponent,
    ActionButtonComponent,
    ButtonWithIconComponent,
    ButtonWithMatIconComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule
  ],
  exports: [ButtonComponent, ActionButtonComponent, ButtonWithIconComponent,ButtonWithMatIconComponent]
})
export class ButtonModule {}
