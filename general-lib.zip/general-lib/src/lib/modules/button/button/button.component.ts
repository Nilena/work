import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {
  constructor() {}
  @Input() label: string;
  @Input() customClass: string;
  @Output() buttonClickEvent = new EventEmitter();
  @Input() icon;
  @Input() isDisabled:boolean=false;

  ngOnInit(): void {}
  buttonClick() {
    this.buttonClickEvent.emit();
  }
}
