import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-button-with-icon',
  templateUrl: './button-with-icon.component.html',
  styleUrls: ['./button-with-icon.component.css']
})
export class ButtonWithIconComponent implements OnInit {

  @Input() type: string;
  @Input() icon:string;
  @Input() isDisabled:boolean=false;
  @Output() clickEvent: EventEmitter<any> = new EventEmitter();

  constructor() { }
  
  ngOnInit(): void {
  }
  
  onClick() {
    this.clickEvent.emit();
  }
}
