export interface IWbcLeftContent {
  title: string;
  subTitle: string;
  customClass?: string;
  icon?: string;
}

export interface Ribbon {
  title: string;
}

export interface IWbcIcon {
  iconPath: string;
  name: string;
  value?: number;
}
