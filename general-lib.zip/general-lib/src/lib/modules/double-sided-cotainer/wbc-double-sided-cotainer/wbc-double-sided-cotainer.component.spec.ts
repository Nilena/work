import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcDoubleSidedCotainerComponent } from './wbc-double-sided-cotainer.component';

describe('WbcDoubleSidedCotainerComponent', () => {
  let component: WbcDoubleSidedCotainerComponent;
  let fixture: ComponentFixture<WbcDoubleSidedCotainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcDoubleSidedCotainerComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(WbcDoubleSidedCotainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
