import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcDoubleSidedCotainerComponent } from './wbc-double-sided-cotainer/wbc-double-sided-cotainer.component';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { KeyValueListModule } from '../key-value-list/key-value-list.module';
import { IconListModule } from '../icon-list/icon-list.module';
import { WbcFabButtonModule } from '../fab-button/fab-button.module';

@NgModule({
  declarations: [WbcDoubleSidedCotainerComponent],
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    KeyValueListModule,
    IconListModule,
    WbcFabButtonModule
  ],
  exports: [WbcDoubleSidedCotainerComponent],
})
export class DoubleSidedCotainerModule {}
