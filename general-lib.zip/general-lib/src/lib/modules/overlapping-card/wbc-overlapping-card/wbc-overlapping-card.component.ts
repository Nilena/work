import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { FabButton } from '../../fab-button/wbc-fab-button-model';
import { OverlappingCard } from '../wbc-overlapping-card-model';

@Component({
  selector: 'lib-wbc-overlapping-card',
  templateUrl: './wbc-overlapping-card.component.html',
  styleUrls: ['./wbc-overlapping-card.component.css']
})
export class WbcOverlappingCardComponent {

  @Input() cardDetails !: OverlappingCard;
  @Input() contentTemplate !: TemplateRef<any> | null;

  @Output() btnActionEvent = new EventEmitter();
  constructor() { 
  }

  selectedBtn(item: FabButton) {
    this.btnActionEvent.emit(item);
  }

}
