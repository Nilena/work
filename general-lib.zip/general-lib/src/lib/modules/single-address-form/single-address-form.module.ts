import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { WbcOverlappingCardModule } from '../overlapping-card/overlapping-card.module';
import { WbcSingleAddressFormComponent } from './wbc-single-address-form/wbc-single-address-form.component';
import { MatButtonModule } from '@angular/material/button';



@NgModule({
  declarations: [
    WbcSingleAddressFormComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    WbcOverlappingCardModule,
  ],
  exports: [WbcSingleAddressFormComponent]
})
export class SingleAddressFormModule { }
