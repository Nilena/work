import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcSingleAddressFormComponent } from './wbc-single-address-form.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AddressFormService } from '../../../services/address-form.service';
import { of } from 'rxjs';
import { SimpleChange, SimpleChanges } from '@angular/core';
import { FabButton } from '../../fab-button/wbc-fab-button-model';


class MockaddressClassService {
  getPathName() {
    return "/geolocations?country=India";
  }
  geoLocations() {
    return of({
      data: {
        locations: [
          { createdAt: 1661758395286, SK: "INDIA", PK: "geo#loc#country", createdBy: "SYSTEM", country: "India " },
          { createdAt: 1661758395286, country: "Bangladesh", SK: "Bangladesh", PK: "geo#loc#country", createdBy: "SYSTEM" }
        ],
        result: "success"
      }
    });
  }

  geoLocationUnderFieldstaff() {
    return of({
      message: 'success',
      data: {
        geoLocationInfo: [
          {
            country: 'India',
            stateMap: [
              {
                state: 'Kerala',
                districts: ['Ernakulam', 'Idukki', 'Kannur', 'Palakkad']
              },
              {
                state: 'Tamil Nadu',
                districts: ['Chennai', 'Coimbatore']
              }
            ]
          }
        ],
        result: 'success'
      }
    });
  }

}

describe('WbcSingleAddressFormComponent', () => {
  let component: WbcSingleAddressFormComponent;
  let fixture: ComponentFixture<WbcSingleAddressFormComponent>;
  let addressFormService: AddressFormService; // Declare addressFormService
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcSingleAddressFormComponent],
      imports: [ReactiveFormsModule,
        HttpClientTestingModule
      ],
      providers: [{ provide: AddressFormService, useClass: MockaddressClassService }]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcSingleAddressFormComponent);
    component = fixture.componentInstance;
    addressFormService = TestBed.inject(AddressFormService);
    component.apiConfig = {
      operations: '/geolocations',
      routePath: '/sfa',
      apiBaseUrl: 'https://api.webcardio.net/wbcqa01/'

    }
    component.headerCardDetails = {
      title: 'Address Details',
      footerActions: [],
    };
    component.editMode = { edit: true };
    component.addressType =  [
      { title: 'isInvoiceAddr', disable: false, ribbonValue: 'Inv ', header: 'Invoice Address', required: true },
      { title: 'isShippingAddr', disable: false, ribbonValue: 'Shp ', header: 'Shipping Address', required: true },
      { title: 'isPrimaryAddr', disable: true, ribbonValue: 'Pri ', header: 'Primary Address', required: true }
    ]
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize form with correct initial values', () => {
    expect(component.addressForm).toBeTruthy();
    expect(component.addressForm.get('addressId').value).toBeNull();
    expect(component.addressForm.get('addressLane1').value).toBeNull();
    expect(component.addressForm.get('addressLane2').value).toBeNull();
    expect(component.addressForm.get('country').value).toBeNull();
    expect(component.addressForm.get('state').value).toBeNull();
    expect(component.addressForm.get('district').value).toBeNull();
    expect(component.addressForm.get('isGstRegistered').value).toBeFalse();
    expect(component.addressForm.get('gstin').value).toBeNull();
    expect(component.addressForm.get('pin').value).toBeNull();
  });

  it('should call getGeoLocation with "country" if fieldStaffDetails is falsy', () => {
    spyOn(component, 'getGeoLocation');
    component.fieldStaffDetails = false;
    component.ngOnInit();
    expect(component.getGeoLocation).toHaveBeenCalled();
  });

  it('should call getGeoLocationStaffDetails if fieldStaffDetails is truthy', () => {
    spyOn(component, 'getGeoLocationStaffDetails');
    component.fieldStaffDetails = true;
    component.ngOnInit();
    expect(component.getGeoLocationStaffDetails).toHaveBeenCalled();
  });

  it('should update address form controls when addressType changes', () => {
    const changes: SimpleChanges = {
      addressType: new SimpleChange(null, [
        { title: 'isInvoiceAddr', disable: false, ribbonValue: 'Inv ', header: 'Invoice Address', required: true },
        { title: 'isShippingAddr', disable: false, ribbonValue: 'Shp ', header: 'Shipping Address', required: true },
        { title: 'isPrimaryAddr', disable: true, ribbonValue: 'Pri ', header: 'Primary Address', required: true }
      ], true)
    };
    component.ngOnChanges(changes);
    expect(component.addressForm.controls['isInvoiceAddr']).toBeTruthy();
    expect(component.addressForm.controls['isShippingAddr']).toBeTruthy();
    expect(component.addressForm.controls['isPrimaryAddr']).toBeTruthy();
  });

  it('should patch address form when addressDetails changes', () => {
    const changes: SimpleChanges = {
      addressType: new SimpleChange(null, {
        currentValue: [],
        previousValue: null,
        isFirstChange: () => true
      }, true),
      addressDetails: new SimpleChange(null, {
        addressLane1: 'Sample Lane 1',
        country: 'Sample Country',
        state: 'Sample State',
        district: 'Sample District',
        pin: 123456,
        isGstRegistered: true,
        gstin: '123456789012345'
      }, true)
    };
    spyOn(component, 'patchAddressForm');
    component.ngOnChanges(changes);
    expect(component.patchAddressForm).toHaveBeenCalled();
  });

  it('should patch address form with correct values when addressDetails is provided', () => {
    component.addressType = [
      { title: 'isInvoiceAddr', disable: false, ribbonValue: 'Inv ', header: 'Invoice Address', required: true },
      { title: 'isShippingAddr', disable: false, ribbonValue: 'Shp ', header: 'Shipping Address', required: true },
      { title: 'isPrimaryAddr', disable: true, ribbonValue: 'Pri ', header: 'Primary Address', required: true }
    ];
    component.addressDetails = {
      addressFields: {
        addressId: undefined,
        addressLane1: "cddd",
        addressLane2: 'undefined',
        country:
          "India",
        district: "Anakapalli",
        gstin: "124",
        isGstRegistered: false,
        pin: "683021",
        state: "Andhra Pradesh",
        isInvoiceAddr: true,
        isShippingAddr: false,
        isPrimaryAddr: true
      }
    };
    const patchObject: any = {};
    if (component.addressType && component.addressType.length) {
      component.addressType.forEach(element => {
        if (element && component.addressDetails.hasOwnProperty(element.title)) {
          patchObject[element.title] = component.addressDetails[element.title];
        }
      });
    }

    component.patchAddressForm();

    expect(component.addressForm.value).toEqual({
      addressId: undefined,
      addressLane1: "cddd",
      addressLane2: 'undefined',
      country:
        "India",
      district: "Anakapalli",
      gstin: "124",
      isGstRegistered: false,
      pin: "683021",
      state: "Andhra Pradesh"
    });
  });

  it('should disable GSTIN control and clear validators when isGstRegistered is true', () => {
    component.addressForm.get('isGstRegistered').setValue(true);
    component.addressForm.get('gstin').setValue('1234567890');

    component.handleGstValidation();
    expect(component.addressForm.get('gstin').disabled).toBeTrue();
    expect(component.addressForm.get('gstin').validator).toBeFalsy();
    expect(component.addressForm.get('gstin').value).toBeNull();
  });

  it('should enable addressForm and submit addresses when action is "edit"', () => {
    const event: FabButton = { icon: 'edit', action: 'edit' };
    const submitAddressesSpy = spyOn(component, 'submitAddresses').and.stub();
    component.onFabButtonClick(event);
    expect(component.addressForm.enabled).toBeTrue();
    expect(submitAddressesSpy).toHaveBeenCalled();
  });

  it('should reset addressForm and update headerCardDetails and editMode when action is not "edit"', () => {
    component.headerCardDetails = {
      title: 'Address Details',
      footerActions: [],
    };
    component.editMode = { edit: true };
    const event: FabButton = { action: 'delete', icon: 'delete' };
    const resetSpy = spyOn(component.addressForm, 'reset').and.stub();

    component.onFabButtonClick(event);

    expect(resetSpy).toHaveBeenCalled();
    expect(component.headerCardDetails.footerActions).toEqual([]);
    expect(component.editMode.edit).toBeFalse();
  });

  it('should submit addresses when form is valid', () => {
    component.editMode = { edit: true };
    const emitSpy = spyOn(component.savedAddressEvent, 'emit').and.stub();
    const resetSpy = spyOn(component.addressForm, 'reset').and.stub();
    component.addressDetails = { id: '123' };
    component.addressForm.setValue({
      addressId: null,
      addressLane1: "cddd",
      addressLane2: 'undefined',
      country:
        "India",
      district: "Anakapalli",
      gstin: "124",
      isGstRegistered: false,
      pin: "683021",
      state: "Andhra Pradesh"
    });
    component.state = ['state1', 'state2'];
    component.dist = ['dist1', 'dist2'];
    component.headerCardDetails.footerActions = [{ action: 'edit', icon: 'edit' }];
    spyOn(component, 'handleGstValidation');

    component.submitAddresses();

    expect(component.handleGstValidation).toHaveBeenCalled();
    expect(emitSpy).toHaveBeenCalledWith({ value: component.addressForm.value, edit: component.editMode.edit, id: '123' });
    expect(component.addressDetails).toEqual({});
    expect(resetSpy).toHaveBeenCalled();
    expect(component.state).toEqual([]);
    expect(component.dist).toEqual([]);
    expect(component.headerCardDetails.footerActions).toEqual([]);
  });

  it('should update property and call dropDownValues()', () => {
    const type = 'state';
    const value = 'kerala';
    const dropDownValuesSpy = spyOn(component, 'dropDownValues');

    component.onSelectionChange(type, value);

    expect(component[type]).toEqual(value);
    expect(dropDownValuesSpy).toHaveBeenCalledWith(type);
  });

  it('should assign geo locations if countryListSource is not null and has length greater than 0', () => {
    const countryListSource = ['India', 'USA'];
    component.countryListSource = countryListSource;
    component.addressDetails = {
      addressFields: {
        country: 'India',
        state: 'Kerala',
        district: 'Ernakulam'
      }
    };

    const dropDownValuesSpy = spyOn(component, 'dropDownValues').and.stub();

    component.assignGeoLocations();

    expect(dropDownValuesSpy).toHaveBeenCalledTimes(2);
    expect(dropDownValuesSpy).toHaveBeenCalledWith('country');
    expect(dropDownValuesSpy).toHaveBeenCalledWith('state');
    expect(component.country).toEqual('India');
    expect(component.state).toEqual('Kerala');
    expect(component.dist).toEqual('Ernakulam');
  });

  it('should not assign geo locations if countryListSource is null or has length 0', () => {
    component.countryListSource = [];
    component.addressDetails = {
      addressFields: {
        country: 'India',
        state: 'Kerala',
        district: 'Ernakulam'
      }
    };

    const dropDownValuesSpy = spyOn(component, 'dropDownValues').and.stub();

    component.assignGeoLocations();

    expect(dropDownValuesSpy).not.toHaveBeenCalled();
    expect(component.country).toBeUndefined();
    expect(component.state).toBeUndefined();
    expect(component.dist).toBeUndefined();
  });

  it('should map states correctly', () => {
    const data = [
      { states: [{ state: 'State1', districts: ['Dist1', 'Dist2'] }] },
      { states: [{ state: 'State2', districts: ['Dist3', 'Dist4'] }] }
    ];
    const result = component.dropDownMapStates(data);
    expect(result.length).toBe(2);
  });

  it('should map districts correctly', () => {
    const dists = [
      { dists: ['Dist1', 'Dist2'] },
      { dists: ['Dist3', 'Dist4'] }
    ];
    const result = component.dropDownMapDists(dists);
    expect(result.length).toBe(4);
  });



  it('should update geoLocation, countryListSource, and call assignGeoLocations()', () => {
    const mockGeoLocationData = {
      message: 'success',
      data: {
        geoLocationInfo: [
          {
            country: 'India',
            stateMap: [
              {
                state: 'Kerala',
                districts: ['Ernakulam', 'Idukki', 'Kannur', 'Palakkad']
              },
              {
                state: 'Tamil Nadu',
                districts: ['Chennai', 'Coimbatore']
              }
            ]
          }
        ],
        result: 'success'
      }
    };

    const dropDownCountrySpy = spyOn(component, 'dropDownCountry').and.callThrough();

    const geoLocationSpy = spyOn(addressFormService, 'geoLocationUnderFieldstaff').and.returnValue(of(mockGeoLocationData));

    component.getGeoLocationStaffDetails();
    expect(component.geoLocation).toEqual(mockGeoLocationData.data.geoLocationInfo);
    expect(dropDownCountrySpy).toHaveBeenCalledWith(mockGeoLocationData.data.geoLocationInfo);
    expect(geoLocationSpy).toHaveBeenCalled();
  });

  it('should update stateListSource when key is "country" and fieldStaffDetails is truthy', () => {
    const key = 'country';
    component.fieldStaffDetails = true;
    component.country = 'India';
    const filteredCountry = [{
      value: 'India', viewValue: 'India', states: [
        {
          state: 'Kerala',
          districts: ['Ernakulam', 'Idukki', 'Kannur', 'Palakkad']
        },
        {
          state: 'Tamil Nadu',
          districts: ['Chennai', 'Coimbatore']
        }
      ]
    }];
    component.countryListSource = filteredCountry;
    component.dropDownValues(key);
    expect(component.stateListSource).toEqual(component.dropDownMapStates(filteredCountry)); // Ensure stateListSource is updated
  });

  it('should update distSource when key is "state" and fieldStaffDetails is truthy', () => {
    const key = 'state';
    component.fieldStaffDetails = true;
    component.state = 'Kerala';
    const filteredStateWithDists = [{ value: 'Kerala', viewValue: 'Kerala', dists: ['Dist1', 'Dist2'] }]; // Example filtered state with districts
    component.stateListSource = filteredStateWithDists;
    component.dropDownValues(key);
    expect(component.distListSource).toEqual(component.dropDownMapDists(filteredStateWithDists)); // Ensure distListSource is updated
  });

});
