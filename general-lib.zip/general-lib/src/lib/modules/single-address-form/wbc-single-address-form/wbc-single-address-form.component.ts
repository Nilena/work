import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FabButton } from '../../fab-button/wbc-fab-button-model';
import { LIB_CONSTANT } from '../../../general-lib-constants.enum';
import { ApiConfig } from '../../mutliple-address-form/wbc-muliple-address-form-model';
import { AddressFormService } from '../../../services/address-form.service';
import { getPincodePattern } from '../../../general-lib-pattern-constants';

@Component({
  selector: 'lib-single-address-form',
  templateUrl: './wbc-single-address-form.component.html',
  styleUrls: ['./wbc-single-address-form.component.css']
})
export class WbcSingleAddressFormComponent implements OnInit {


  constants = LIB_CONSTANT;
  country;
  state;
  dist;
  countryListSource;
  stateListSource;
  distListSource;
  @Input() addressDetails;// to edit pass address details
  @Input() addressType;// to pass fields to check for mat-check 
  @Input() headerCardDetails // header details ;
  @Input() fieldStaffDetails: boolean;// to get details state country details of field staff or common api call of country
  @Input() apiConfig: ApiConfig // api details;
  @Input() editMode //true for edit and false for add default false pass as obj editMode.edit;
  @Output() fabBtnClick = new EventEmitter();
  @Output() savedAddressEvent = new EventEmitter();
  address = {
    addressId: new FormControl(null),
    addressLane1: new FormControl(null, [
      Validators.required,
      Validators.maxLength(200)
    ]),
    addressLane2: new FormControl(null, [
      Validators.maxLength(200)
    ]),
    country: new FormControl(null, Validators.required),
    state: new FormControl(null, Validators.required),
    district: new FormControl(null, Validators.required),
    isGstRegistered: new FormControl(false),
    gstin: new FormControl(null, Validators.maxLength(15)),
    pin: new FormControl(null, [
      Validators.required,
      Validators.pattern(getPincodePattern())
    ]),
  };
  addressForm: FormGroup;
  geoLocation;

  constructor(private addressFormService: AddressFormService) {
    this.addressForm = new FormGroup(this.address);
  }

  ngOnInit(): void {
    if (!this.fieldStaffDetails) this.getGeoLocation('country');
    else this.getGeoLocationStaffDetails();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.hasOwnProperty('addressType')) {
      if (this.addressType.length) {
        const formControls = {};
        Object.keys(this.addressForm.controls).forEach(key => {
          formControls[key] = this.addressForm.get(key);
        });
        this.addressType.forEach(element => {
          if (element) {
            formControls[element.title] = new FormControl(element.value);
          }
        });
        this.addressForm = new FormGroup(formControls);

        if (changes.hasOwnProperty('addressDetails')) {
          this.patchAddressForm();
        }
      }
    }
  }


  patchAddressForm() {
    if (this.addressDetails && this.addressDetails.addressFields) {
      let data = this.addressDetails.addressFields;
      if (data) {
        const patchObject = {
          addressLane1: data.addressLane1 && data.addressLane1,
          addressLane2: data.addressLane2 && data.addressLane2,
          country: data.country,
          state: data.state,
          district: data.district,
          isGstRegistered: (data.gstin) ? false : true,
          gstin: data.gstin,
          addressId: data.addrId,
          pin: data.pin,
        }
        if (this.addressType && this.addressType.length) {
          this.addressType.forEach(element => {
            if (element && data.hasOwnProperty(element.title)) {
              patchObject[element.title] = data[element.title];
            }
          });
          this.addressForm.patchValue(patchObject);
        }
      }

      this.assignGeoLocations()

    }

    this.handleGstValidation()
  }

  handleGstValidation() {
    const isChecked = this.addressForm.get('isGstRegistered').value;
    const gstinControl = this.addressForm.get('gstin');
    const gstinControlvalue = this.addressForm.get('gstin').value;

    if (isChecked) {
      gstinControl.disable();
      gstinControl.clearValidators();
      gstinControl.setValue(null);

    } else {
      gstinControl.enable();
      gstinControl.setValue(gstinControlvalue);
      gstinControl.setValidators([Validators.required]);
    }
    gstinControl.updateValueAndValidity();
  }

  onFabButtonClick(event: FabButton) {
    if (event.action === 'edit') {
      this.addressForm.enable()
      this.submitAddresses();
    } else {
      this.addressForm.reset();
      this.headerCardDetails.footerActions = [];
      this.addressDetails = {}
      this.editMode.edit = false;
    }
  }
  submitAddresses() {
    this.handleGstValidation();
    if (this.addressForm.valid) {
      this.savedAddressEvent.emit({ value: this.addressForm.value, edit: this.editMode.edit, id: this.addressDetails?.id });
      this.addressDetails = {};
      this.addressForm.reset();
      this.state = []
      this.dist = []
      this.stateListSource = [];
      this.distListSource = [];
      this.headerCardDetails.footerActions = [];
      this.handleGstValidation();
    }
  }
  onSelectionChange(type, value) {
    this[type] = value;
    this.dropDownValues(type);
  }

  dropDownValues(key) {
    if (key === 'country') {
      if (!this.fieldStaffDetails) {
        this.getGeoLocation('state', this.country);
        this.state = null;
        this.dist = null;
      } else {
        this.state = null;
        const filteredCountry = this.countryListSource.filter(
          (x) => x.value === this.country
        );
        this.stateListSource = this.dropDownMapStates(filteredCountry);
      }
    }
    if (key === 'state') {
      if (!this.fieldStaffDetails) {
        this.getGeoLocation('dist', this.country, this.state);
        this.dist = null;
      }
      else {
        this.dist = null;
        const filteredState = this.stateListSource.filter(
          (x) => x.value === this.state
        );
        this.distListSource = this.dropDownMapDists(filteredState);
      }
    }
  }


  getGeoLocation(path, country?, state?) {
    debugger
    this.addressFormService
      .geoLocations(this.apiConfig, path, country, state)
      .subscribe(val => {
        if (val && val.data) {
          let data = val?.data?.locations;
          this.getPathName(path, data);
        }

      });
  }

  getPathName(path, data) {
    switch (path) {
      case 'country':
        this.initializeCountry(data);
        break;
      case 'state':
        this.initializeState(data);
        break;
      case 'dist':
        this.initializeDist(data);
        break;
    }
  }
  initializeCountry(data) {
    this.countryListSource = this.dropDownCountry(data);
    this.assignGeoLocations();
  }

  initializeState(data) {
    this.stateListSource = this.dropDownMapState(data);
  }
  initializeDist(data) {
    this.distListSource = this.dropDownMapDist(data);
  }

  dropDownMapState(data) {
    return data?.map((x, i) => ({
      value: x.state,
      viewValue: x?.state
    }));
  }

  dropDownMapDist(dists) {
    return dists?.map((dist) => ({
      value: dist.district,
      viewValue: dist.district
    }));
  }
  dropDownCountry(countries) {
    return countries?.map((x, i) => ({
      value: x.country,
      viewValue: x.country,
      states: x?.stateMap
    }));
  }

  getGeoLocationStaffDetails() {
    this.addressFormService.geoLocationUnderFieldstaff(this.apiConfig).subscribe((val) => {
      this.geoLocation = val?.data?.geoLocationInfo;
      this.countryListSource = this.dropDownCountry(this.geoLocation);
      this.assignGeoLocations();
    });
  }

  dropDownMapStates(data) {
    const stateArray = data?.map(({ states }) => states).flat();
    return stateArray?.map((x, i) => ({
      value: x.state,
      viewValue: x?.state,
      dists: x?.districts
    }));
  }
  dropDownMapDists(dists) {
    const districtArray = dists?.map(({ dists }) => dists).flat();
    return districtArray.map((district) => ({
      value: district,
      viewValue: district
    }));
  }
  assignGeoLocations() {
    if (this.countryListSource && this.countryListSource.length > 0) {
      this.country = this.addressDetails?.addressFields?.country;
      this.dropDownValues('country');
      this.state = this.addressDetails?.addressFields?.state;
      this.dropDownValues('state');
      this.dist = this.addressDetails?.addressFields?.district;
    }
  }

}
