import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcCircularSpinnerComponent } from './wbc-circular-spinner/wbc-circular-spinner.component';

import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";


@NgModule({
  declarations: [WbcCircularSpinnerComponent],
  imports: [
    CommonModule,
    MatProgressSpinnerModule

  ],
  exports:[
    WbcCircularSpinnerComponent
  ]
})
export class CircularSpinnerModule { }
