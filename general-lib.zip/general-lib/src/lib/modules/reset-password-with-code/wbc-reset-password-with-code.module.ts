import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcResetPasswordWithCodeComponent } from './wbc-reset-password-with-code.component';
import { WbcAuthContainerModule } from '../auth-container/wbc-auth-container.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { WbcPasswordFieldModule } from '../password-field/wbc-password-field.module';
import { ButtonModule } from '../button/button.module';

@NgModule({
  declarations: [WbcResetPasswordWithCodeComponent],
  imports: [
    CommonModule,
    WbcAuthContainerModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    WbcPasswordFieldModule,
    ButtonModule
  ],
  exports: [WbcResetPasswordWithCodeComponent],
})
export class WbcResetPasswordWithCodeModule {}
