import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import { WbcFabButtonComponent } from './wbc-fab-button/wbc-fab-button.component';
import { MatTooltipModule } from '@angular/material/tooltip';



@NgModule({
  declarations: [
    WbcFabButtonComponent
  ],
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatTooltipModule
  ],
  exports: [WbcFabButtonComponent]
})
export class WbcFabButtonModule { }
