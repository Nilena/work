import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FabButton } from '../wbc-fab-button-model';

@Component({
  selector: 'lib-wbc-fab-button',
  templateUrl: './wbc-fab-button.component.html',
  styleUrls: ['./wbc-fab-button.component.css']
})
export class WbcFabButtonComponent {
  @Input() fabBtn !: FabButton;
  @Output() clickEvent = new EventEmitter();

  constructor() {}

  selectedBtn(action: string) {
    this.clickEvent.emit(action);
  }
}
