import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-table-row-cards',
  templateUrl: './wbc-table-row-cards.component.html',
  styleUrls: ['./wbc-table-row-cards.component.css']
})
export class WbcTableRowCardsComponent implements OnInit {
  @Input() tableData: any = [];
  @Input() tableHeaders: any[];
  @Input() tableActions: any[];
  constructor() {}

  ngOnInit(): void {}

  getButtonType(action: any, rowConfig: any) {
    if (action?.enableAlert && rowConfig?.alertEnabled) return 'alert';
    else return action.type;
  }

  renderButtonLabel(action: any, rowConfig: any) {
    if (
      rowConfig?.renderActionBtnSecondaryLabel?.enableSecondaryLabel &&
      rowConfig?.renderActionBtnSecondaryLabel?.actionKeyList.includes(
        action?.key
      )
    )
      return action?.secondaryLabel;
    else return action.label;
  }

  isButtonDisabled(action: any, rowConfig: any) {
    if (
      rowConfig?.disableActionBtn?.disabled &&
      rowConfig?.disableActionBtn?.actionKeyList.includes(action?.key)
    )
      return true;
    else return false;
  }
}
