import {
  Component,
  OnInit,
  Input,
  ViewChild,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter,
  ElementRef
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'lib-wbc-table',
  templateUrl: './wbc-table.component.html',
  styleUrls: ['./wbc-table.component.css']
})
export class WbcTableComponent implements OnInit {
  constructor(
    private iconRegistry: MatIconRegistry,
    private sanitizer: DomSanitizer
  ) {
    this.iconRegistry.addSvgIcon(
      'ecg-icon',
      this.sanitizer.bypassSecurityTrustResourceUrl('assets/images/ecg.svg')
    );
  }

  @Input() data: any[] = [];
  @Input() className = '';
  @Input() allColumns: string[];
  @Input() headerColumns = {};
  @Input() rowSelectionEnabled;
  @Input() filterText = '';
  @Input() noDataMessage;
  @Input() pipes = {};
  @Input() sortOptions = { active: 'name', order: 'asc' };
  @Input() actions = [];
  @Input() isDisabled: Function;
  @Input() isPaginatorEnabled = true;
  @Input() rowColor = false;
  @Input() tableIsElevated = true;
  @Input() enableRouterEvents = false;
  @Input() footerColumns = false;
  @Input() footerValues = {};
  @ViewChild('selectAllButton', { static: true }) selectAllButton;
  tableIsEmpty = false;
  selectedRows: Set<any> = new Set();
  dataSource = new MatTableDataSource(this.data);
  public displayedColumns: string[] = [];
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @Output() emitSelectedRows: EventEmitter<any> = new EventEmitter<any>();
  @Output() tableAction = new EventEmitter();
  @Output() onRowClicked = new EventEmitter();
  @Input() rowColorAction: (value: any) => string;
  @Output() rowsHeightCalculated: EventEmitter<Array<any>> = new EventEmitter();
  paginationRow = 0;

  private el: ElementRef;
  @ViewChild('table', { static: false }) set content(content: ElementRef) {
    let heightOfRows = [];
    if (content && this.className != '') {
      // initially setter gets called with undefined
      this.el = content;
      var result = document.getElementsByClassName(
        this.className
      ) as HTMLCollectionOf<HTMLElement>;
      if (result.length > 0) {
        for (let k = 0; k < result[0].children.length; k++) {
          let h = result[0].children[k] as HTMLElement;
          if (h.tagName == 'TBODY') {
            for (let m = 0; m < h.children.length; m++) {
              let n = h.children[m] as HTMLElement;
              heightOfRows.push(n.offsetHeight);
            }
          }
        }
        this.rowsHeightCalculated.emit(heightOfRows);
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.data) {
      this.data = changes.data.currentValue;
    }
    if (changes.allColumns) {
      this.allColumns = changes.allColumns.currentValue;
    }
    if (this.data) {
      this.dataSource.data = this.data;
      this.paginationRow = this.data.length;
      this.tableIsEmpty = this.data.length === 0;
    }

    if (this.displayedColumns) {
      this.displayedColumns =
        this.displayedColumns.length <= 0
          ? this.allColumns
          : this.displayedColumns;
    }

    this.dataSource.filter = this.filterText
      ? this.filterText.trim().toLowerCase()
      : '';
    this.dataSource.filterPredicate = (data, filter) => {
      return this.objectToString(data).includes(
        filter ? filter.trim().toLowerCase() : ''
      );
    };
  }
  objectToString = (complexObject): string => {
    let resultValue = '';
    Object.values(complexObject).forEach((objectValue) => {
      if (typeof objectValue !== 'object') {
        resultValue = resultValue + ' ' + objectValue;
      } else if (objectValue !== null) {
        resultValue = resultValue + ' ' + this.objectToString(objectValue);
      }
    });
    return resultValue.trim().toLowerCase();
  };
  ngOnInit() {
    if (this.rowSelectionEnabled === 'true') {
      this.allColumns = ['select'].concat(this.allColumns);
    }
    this.setupDataSource();
    this.displayedColumns = this.allColumns;
  }
  ngAfterViewInit() {
    this.displayedColumns = this.allColumns;
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  private setupDataSource() {
    this.dataSource.data = this.data;
  }

  getTotalAmount(column: string) {
    if (this.footerColumns && column === 'name') {
      return this.footerColumns[column];
    } else if (this.footerColumns && this.footerColumns[column]) {
      return this.footerValues[column];
    } else {
      return;
    }
  }

  getColumnHeaderRowText = (column: string) => {
    if (this.headerColumns && this.headerColumns[column]) {
      return this.headerColumns[column];
    } else {
      return column === 'select' ? '' : column;
    }
  };

  selectAllRows(checked) {
    if (checked) {
      this.selectedRows = new Set(this.data);
    } else {
      this.selectedRows.clear();
    }
    let rowSelected = Array.from(this.selectedRows);
    this.emitSelectedRows.emit(rowSelected);
  }

  selectRowItem(row) {
    if (this.selectedRows.has(row)) {
      this.selectedRows.delete(row);
      this.emitSelectedRows.emit(Array.from(this.selectedRows));
    } else {
      let rowSelected = Array.from(this.selectedRows);
      this.emitSelectedRows.emit(rowSelected);
      this.selectedRows.add(row);
    }

    if (
      this.dataSource &&
      this.dataSource.data &&
      this.selectedRows.size == this.dataSource.data.length
    ) {
      this.selectAllButton.checked = true;
      this.selectAllRows(true);
    } else {
      this.selectAllButton.checked = false;
    }
    this.emitSelectedRows.emit(Array.from(this.selectedRows));
  }

  isRowSelected(row) {
    return this.selectedRows.has(row);
  }

  getPipe(column) {
    if (this.pipes[column]) {
      return this.pipes[column].name;
    } else {
      return null;
    }
  }
  getPipeArg(column) {
    if (this.pipes[column]) {
      return this.pipes[column].arg;
    } else {
      return null;
    }
  }

  tableActionEmit(row, action) {
    this.tableAction.emit({ action: action, row: row });
  }

  getRowColor(row: any): string {
    return this.rowColorAction(row);
  }

}
