import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CopyToClipboardComponent } from './copy-to-clipboard.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    CopyToClipboardComponent
  ],
  imports: [
    CommonModule,
    MatIconModule
  ],
  exports:[
    CopyToClipboardComponent
  ]
})
export class CopyToClipboardModule { }
