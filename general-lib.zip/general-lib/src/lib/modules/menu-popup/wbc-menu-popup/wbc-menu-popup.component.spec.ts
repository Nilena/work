import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcMenuPopupComponent } from './wbc-menu-popup.component';

describe('WbcMenuPopupComponent', () => {
  let component: WbcMenuPopupComponent;
  let fixture: ComponentFixture<WbcMenuPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcMenuPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcMenuPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
