import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcAuthContainerComponent } from './wbc-auth-container.component';

describe('WbcAuthContainerComponent', () => {
  let component: WbcAuthContainerComponent;
  let fixture: ComponentFixture<WbcAuthContainerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcAuthContainerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcAuthContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
