import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-auth-container',
  templateUrl: './wbc-auth-container.component.html',
  styleUrls: ['./wbc-auth-container.component.css']
})
export class WbcAuthContainerComponent implements OnInit {

  @Input() titleDescription!:string;
  @Input() imagesrc!:string;
  constructor() { }

  ngOnInit(): void {
    console.log('first', this.imagesrc)
  }

}
