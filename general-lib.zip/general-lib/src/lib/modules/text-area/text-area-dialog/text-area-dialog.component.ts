import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'lib-text-area-dialog',
  templateUrl: './text-area-dialog.component.html',
  styleUrls: ['./text-area-dialog.component.css']
})
export class TextAreaDialogComponent implements OnInit {
  text: string = '';

  constructor(
    public dialogRef: MatDialogRef<TextAreaDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public textData
  ) {}

  ngOnInit(): void {}
  onSaveClick() {
    this.dialogRef.close(this.text);
  }
}
