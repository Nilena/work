import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcForgotPasswordEmailComponent } from './wbc-forgot-password-email.component';
import { WbcAuthContainerModule } from '../auth-container/wbc-auth-container.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { ButtonModule } from '../button/button.module';

@NgModule({
  declarations: [WbcForgotPasswordEmailComponent],
  imports: [
    CommonModule,
    WbcAuthContainerModule,
    ReactiveFormsModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    ButtonModule,
  ],
  exports: [WbcForgotPasswordEmailComponent],
})
export class WbcForgotPasswordEmailModule {}
