import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcDynamicSpinnerComponent } from './wbc-dynamic-spinner.component';

describe('WbcDynamicSpinnerComponent', () => {
  let component: WbcDynamicSpinnerComponent;
  let fixture: ComponentFixture<WbcDynamicSpinnerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcDynamicSpinnerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcDynamicSpinnerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
