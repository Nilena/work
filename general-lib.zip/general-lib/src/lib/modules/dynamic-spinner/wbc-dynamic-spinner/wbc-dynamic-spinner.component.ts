import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-dynamic-spinner',
  templateUrl: './wbc-dynamic-spinner.component.html',
  styleUrls: ['./wbc-dynamic-spinner.component.css']
})
export class WbcDynamicSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
