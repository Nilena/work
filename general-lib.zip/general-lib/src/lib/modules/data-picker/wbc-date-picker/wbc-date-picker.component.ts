import { EventEmitter,Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-date-picker',
  templateUrl: './wbc-date-picker.component.html',
  styleUrls: ['./wbc-date-picker.component.css']
})
export class WbcDatePickerComponent implements OnInit {

  constructor() { }
  @Input() date:Date;
  @Input() label:string;
  @Input() mode?:string;
  @Input() dateKey:string;
  @Input() minDate:Date;
  @Input() maxDate:Date;
  @Output() changeHandler = new EventEmitter<{key:string,value:Date}>();
  ngOnInit() {
  }

  dateChange(){
    this.changeHandler.emit({key:this.dateKey,value:this.date})
  }



}
