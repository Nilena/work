import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcDatePickerComponent } from './wbc-date-picker.component';

describe('WbcDatePickerComponent', () => {
  let component: WbcDatePickerComponent;
  let fixture: ComponentFixture<WbcDatePickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcDatePickerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcDatePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
