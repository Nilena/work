import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { ApiConfig } from '../wbc-muliple-address-form-model';
import { AddressFormService } from '../../../services/address-form.service';

@Component({
  selector: 'lib-wbc-multiple-address-form',
  templateUrl: './wbc-multiple-address-form.component.html',
  styleUrls: ['./wbc-multiple-address-form.component.css']
})
export class WbcMultipleAddressFormComponent implements OnInit {
  @Input() addressListCardDetails //header of list details;
  @Input() availableAddresses //list of addressses;
  @Input() footerActions //pass icon details for double side container;
  @Input() hideAddressForm  //hide form if list only required;
  @Input() addressDetails;// to edit pass address details
  @Input() addressType;//dynamically handling fields
  @Input() headerCardDetails // to header details for form;
  @Input() editMode //true for edit and false for add default false editMode.edit ;
  @Input() apiConfig: ApiConfig//api details;
  @Input() fieldStaffDetails // to call field staff api;
  @Output() savedSingleAddressClick = new EventEmitter();
  @Output() footerActionFabBtnClick = new EventEmitter();

  constructor() { }

  ngOnInit(): void { }

  savedAddressList(event) {
    this.savedSingleAddressClick.emit(event);
  }

  onAddressBtnAction(event) {
    this.footerActionFabBtnClick.emit(event);
  }
}

