import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcBidirectionalSkipComponent } from './wbc-bidirectional-skip/wbc-bidirectional-skip.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    WbcBidirectionalSkipComponent
  ],
  imports: [
    CommonModule,
    MatIconModule
  ],
  exports:[WbcBidirectionalSkipComponent]
})
export class BidirectionalSkipModule { }
