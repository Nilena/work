import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IWbcIcon } from '../wbc-icon-list-model';

@Component({
  selector: 'lib-wbc-icon-list',
  templateUrl: './wbc-icon-list.component.html',
  styleUrls: ['./wbc-icon-list.component.css'],
})
export class WbcIconListComponent implements OnInit {
  @Input() icons!: IWbcIcon[];

  @Output() iconAction = new EventEmitter<IWbcIcon>();

  constructor() {}

  ngOnInit(): void {}

  handleClick(item: IWbcIcon) {
    this.iconAction.emit(item);
  }
}
