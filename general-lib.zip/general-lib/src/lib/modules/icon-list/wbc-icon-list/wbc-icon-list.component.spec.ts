import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcIconListComponent } from './wbc-icon-list.component';

describe('WbcIconListComponent', () => {
  let component: WbcIconListComponent;
  let fixture: ComponentFixture<WbcIconListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcIconListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcIconListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
