import { Component, Input, OnInit } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'lib-wbc-key-value-list',
  templateUrl: './wbc-key-value-list.component.html',
  styleUrls: ['./wbc-key-value-list.component.css'],
})
export class WbcKeyValueListComponent implements OnInit {
  @Input() title!: string;
  @Input() subTitle!: string;
  @Input() isChipRequired!: boolean;
  @Input() customClass?: string
  @Input() icon?: string

  constructor() {}

  ngOnInit(): void {}
}
