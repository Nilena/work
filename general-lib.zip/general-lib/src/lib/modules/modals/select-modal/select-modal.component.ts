import { Component, Inject, EventEmitter, Output, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'lib-select-modal',
  templateUrl: './select-modal.component.html',
  styleUrls: ['./select-modal.component.css']
})
export class SelectModalComponent implements OnInit {
  form: FormGroup;

  @Output() cancel = new EventEmitter();
  @Output() save = new EventEmitter<any>();
  constructor(
    public dialogRef: MatDialogRef<SelectModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    this.form = new FormGroup({
      selectedOption: new FormControl('')
    });
  }

  ngOnInit(): void {
  }

  onCancelClick(): void {
    this.cancel.emit();
    this.dialogRef.close();
  }

  onSaveClick(): void {
    this.save.emit(this.form.value.selectedOption);
    this.dialogRef.close();
  }

}
