import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { WbcBreadCrumbComponent } from './wbc-bread-crumb.component';
import { BreadCrumb } from '../wbc-bread-crumb-model';

describe('WbcBreadCrumbComponent', () => {
  let component: WbcBreadCrumbComponent;
  let fixture: ComponentFixture<WbcBreadCrumbComponent>;
  let router: Router;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [WbcBreadCrumbComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcBreadCrumbComponent);
    component = fixture.componentInstance;
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to the provided link when clicked', () => {
    const mockBreadcrumbs: BreadCrumb = { items: [{ title: 'Approval', route: '/insight/services' }, { title: 'Service', route: '/services' }, { title: 'Calendar', route: '/calendar' }] }
    component.breadcrumb = mockBreadcrumbs;
    fixture.detectChanges();

    const breadcrumbItems = fixture.nativeElement.querySelectorAll('.breadcrumb-items');
    spyOn(router, 'navigate');
    breadcrumbItems[0].click();
    expect(router.navigate).toHaveBeenCalledWith(['/home']);
  });

});

