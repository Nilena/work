import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BreadCrumb } from '../wbc-bread-crumb-model';

@Component({
  selector: 'lib-wbc-bread-crumb',
  templateUrl: './wbc-bread-crumb.component.html',
  styleUrls: ['./wbc-bread-crumb.component.css']
})
export class WbcBreadCrumbComponent {
  @Input() breadcrumb!: BreadCrumb;
  constructor(public router: Router) { }

  navigate(link) {
    if (link) this.router.navigate([link]);
  }

}
