import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcInfiniteDropdownComponent } from './wbc-infinite-dropdown/wbc-infinite-dropdown.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';



@NgModule({
  declarations: [WbcInfiniteDropdownComponent],
  imports: [
    CommonModule,
   FormsModule,
    MatSelectModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    NgxMatSelectSearchModule
    
  ],
  exports:[WbcInfiniteDropdownComponent]
})
export class InfiniteDropdownModule { }
