import { Injectable } from '@angular/core';
import { WbcAjaxService } from '../../../services/wbc-ajax.service';
import { of as observableOf, Observable, BehaviorSubject } from 'rxjs';

import { catchError, map } from 'rxjs/operators';
import { WbcDropDown } from '../../../models/wbc-drop-down.model';
@Injectable({
  providedIn: 'root'
})
export class WbcInfiniteDropdownService {

  constructor(private ajaxService: WbcAjaxService) { }


  getData(list: Array<WbcDropDown>, api: { appDetails: { apiBaseUrl: string, token: string }, operation: string, data: any, dataKey: string, responseKey: string, secondDataKey?: string }) {
    return this.ajaxService.postRequest(api.data, api.operation, api.appDetails, { spinner: false }).pipe(
      map(res => {
        let response: any = res;
        if (response.result == "success") {
          let data = response[api.responseKey];
          data.forEach((item) => {
            console.log("the item", item, { viewValue: item[api.dataKey], value: item })
            let elem = { viewValue: item[api.dataKey], value: item };
            if (api.secondDataKey && api.secondDataKey != "") {
              elem = { viewValue: item[api.dataKey] + " | " + item[api.secondDataKey], value: item };
            }
            list.push(elem);

          });
          console.log("the list", list)
          return { success: true, list: list }

        }
        else {

          return { success: false, list }
        }
      }
      ), catchError(err => observableOf(err).pipe(map(err => {
        return { success: false, list: list }

      }))))
  }
}
