import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { BehaviorSubject, Observable, Subscription, Subject } from 'rxjs';
import { scan, takeUntil } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { WbcAjaxService } from '../../../services/wbc-ajax.service';
import { WbcInfiniteDropdownService } from './wbc-infinite-dropdown.service';
import { WbcDropDown } from '../../../models/wbc-drop-down.model';
@Component({
  selector: 'lib-wbc-infinite-dropdown',
  templateUrl: './wbc-infinite-dropdown.component.html',
  styleUrls: ['./wbc-infinite-dropdown.component.css']
})
export class WbcInfiniteDropdownComponent implements OnInit {
  responseList:Array<WbcDropDown>=[];
  results=[];
  offset = 0;
  data=[];
  
  selectionControl: FormControl = new FormControl();
  searchControl: FormControl = new FormControl();

  @Output() emitSelected = new EventEmitter<any>();
  @Input() label:string;
  @Input() required :boolean;
  @Input()selectedValue :string;
  @Input() api:{appDetails:{apiBaseUrl:string,token:string},operation:string,data:any,dataKey:string,responseKey:string,secondDataKey?:string};
  @Output() error = new EventEmitter<any>();
  @Input() searchLabel;
  @Input() noResultFound;
  @Input() failedToLoadMessage;
  subscriptions: Subscription[] = [];
  _options = new BehaviorSubject([]);
  options$ = this._options.asObservable().pipe(
    scan((acc, curr) => {
      if (!acc || !curr) {
        return [];
      }
      return [...acc, ...curr];
    }, [])
  );
 
  protected _onDestroy = new Subject<void>();

  constructor(private wbcAjaxService: WbcAjaxService,private service:WbcInfiniteDropdownService) { }

  ngOnInit() {

    this.getData();
    this.data$.pipe(
      takeUntil(this._onDestroy)
    ).subscribe({
      next: (data) => {
        this.data = data;
        this.offset = 0;
        this._options.next(null);
         this.getNextBatch();
      }
    });

    this.searchControl
      .valueChanges
      .pipe(
        takeUntil(this._onDestroy)
      )
      .subscribe((val) => this.onSearchChange(val));
  }



  private _data = new BehaviorSubject<any[]>(this.responseList);
  data$ = this._data.asObservable();
  ngOnDestroy(): void {
    this._onDestroy.next();
    this._onDestroy.complete();
  }


  onSearchChange(e): void {
    let val = e ? e.trim() : null;
    if (!val) {
      // Empty search, returns everything
      this._data.next(this.responseList);
      return;
    } else {
      val = val.toLowerCase();
    }

    const matches = this.responseList.filter((i) => i.viewValue.toLowerCase().indexOf(val.toLowerCase()) > -1);
    this._data.next(matches);
  }

  getNextBatch(): void {
    const resulting = this.data.slice(this.offset,this.offset+this.data.length);
    this._options.next(resulting);
  }
  getData(){
    this.service.getData(this.responseList,this.api).subscribe((response)=>{
      this.responseList = response.list;
      console.log("the lisr",response)
      if(this.responseList.length==0){
        if(response.success){
          this.searchLabel=this.noResultFound;

        }else{
          this.searchLabel=this.failedToLoadMessage;
        }
        this.searchControl.disable();
      }
      else{
        console.log("inside the else")
      const resulting = this.data.slice(this.offset,this.offset+this.data.length);
      this._options.next(resulting);

      }


    })
  
}
onSelectionChange(value): void {
  console.log("the djdjdddd",value)
  this.emitSelected.emit(value);
}
}
