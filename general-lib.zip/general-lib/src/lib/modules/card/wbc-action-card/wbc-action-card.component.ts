import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-action-card',
  templateUrl: './wbc-action-card.component.html',
  styleUrls: ['./wbc-action-card.component.css']
})
export class WbcActionCardComponent implements OnInit {

  constants;
  constructor() { 
  }
  @Input() title;
  @Input() icon;
  @Input() tooltipMsg;
  @Input() contents;
   
  @Output() clickIconEvent = new EventEmitter()

  ngOnInit(): void {
    console.log(this.title)
  }

  setBuffer(item){

  }

  onClick(){
    this.clickIconEvent.emit()
  }

}
