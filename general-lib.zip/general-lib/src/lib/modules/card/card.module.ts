import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcActionCardComponent } from './wbc-action-card/wbc-action-card.component';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { WbcMinimalCardWithSingleActionComponent } from './wbc-minimal-card-with-single-action/wbc-minimal-card-with-single-action.component';
import { ButtonModule } from '../button/button.module';

@NgModule({
  declarations: [
    WbcActionCardComponent,
    WbcMinimalCardWithSingleActionComponent,
  ],
  imports: [
    CommonModule,
    MatTooltipModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    ButtonModule
  ],
  exports: [WbcActionCardComponent, WbcMinimalCardWithSingleActionComponent]
})
export class CardModule {}
