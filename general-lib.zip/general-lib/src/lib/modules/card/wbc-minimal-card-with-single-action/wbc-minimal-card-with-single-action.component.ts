import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-minimal-card-with-single-action',
  templateUrl: './wbc-minimal-card-with-single-action.component.html',
  styleUrls: ['./wbc-minimal-card-with-single-action.component.css']
})
export class WbcMinimalCardWithSingleActionComponent implements OnInit {

  @Input() label: string;
  @Input() topLabel: string;
  @Input() bottomLabel: string;
  @Input() action: any;
  @Input() btnLabel:string;
  @Input() btnIcon:string;
  @Input() btnType:string;
  @Input() isBtnDisabled:boolean=false;

  @Output() btnClickEvent=new EventEmitter();

  constructor() {}

  ngOnInit(): void {}

  handleButtonClick(){
    this.btnClickEvent.emit();
  }
}
