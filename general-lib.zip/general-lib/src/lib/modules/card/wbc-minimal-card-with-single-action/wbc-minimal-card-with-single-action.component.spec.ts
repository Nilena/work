import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcMinimalCardWithSingleActionComponent } from './wbc-minimal-card-with-single-action.component';

describe('WbcMinimalCardWithSingleActionComponent', () => {
  let component: WbcMinimalCardWithSingleActionComponent;
  let fixture: ComponentFixture<WbcMinimalCardWithSingleActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcMinimalCardWithSingleActionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcMinimalCardWithSingleActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
