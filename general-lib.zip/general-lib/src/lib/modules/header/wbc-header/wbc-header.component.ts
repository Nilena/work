import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'lib-wbc-header',
  templateUrl: './wbc-header.component.html',
  styleUrls: ['./wbc-header.component.css']
})
export class WbcHeaderComponent implements OnInit {

  constructor() { }
  @Input() logoPath:string;
  @Input() leftIcon:string;
  @Input() leftButtonTooltip:string;
  @Input() rightButtonTooltip:string;
  @Input() rightIcon:string;
  @Input() title :string;
  @Output() rightAction=new EventEmitter;
  @Output() leftAction=new EventEmitter;


  ngOnInit() {
  }

  rightIconclick(){
    this.rightAction.emit();

  }

  leftIconclick(){
    this.leftAction.emit();

  }

}
