import { Component, EventEmitter, Inject, Input, OnInit, Output, Renderer2, ViewEncapsulation } from '@angular/core';
import { MAT_SNACK_BAR_DATA, MatSnackBar, MatSnackBarRef } from '@angular/material/snack-bar';
import { icon_type } from '../../../general-lib-constants'
@Component({
  selector: 'lib-wbc-snackbar',
  templateUrl: './wbc-snackbar.component.html',
  styleUrls: ['./wbc-snackbar.component.css'],
})
export class WbcSnackbarComponent implements OnInit {
  icon;
  constructor(
    @Inject(MAT_SNACK_BAR_DATA) public data: any,
    private snackBarRef: MatSnackBarRef<WbcSnackbarComponent>,
    ) {
      this.icon = icon_type
     }

  type;
  text;
  show = false;
  @Output() closeIconClick = new EventEmitter()

  ngOnInit(): void {
    this.type = this.data.type
    this.text = this.data.message
  }

  onClose(){
    this.snackBarRef.dismiss()
    this.closeIconClick.emit()
  }
  
}
