import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcSnackbarComponent } from './wbc-snackbar/wbc-snackbar.component';
import { IconsModule } from '../icons/icons.module';
import { MAT_SNACK_BAR_DATA, MAT_SNACK_BAR_DEFAULT_OPTIONS, MatSnackBarModule, MatSnackBarRef } from '@angular/material/snack-bar';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';



@NgModule({
  declarations: [WbcSnackbarComponent],
  imports: [
    CommonModule,
    IconsModule,
    MatSnackBarModule,
    BrowserModule,
    BrowserAnimationsModule
  ],
  exports:[WbcSnackbarComponent],
  providers: [
    {
      provide: MAT_SNACK_BAR_DEFAULT_OPTIONS,
      useValue: {}
  }
]
})
export class SnackbarModule { }
