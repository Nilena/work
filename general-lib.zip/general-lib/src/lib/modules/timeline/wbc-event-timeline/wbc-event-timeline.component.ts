import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-event-timeline',
  templateUrl: './wbc-event-timeline.component.html',
  styleUrls: ['./wbc-event-timeline.component.css']
})
export class WbcEventTimelineComponent implements OnInit {
  @Input() events:any[] =[{title:"title", subtitle:[{icon:"icon_name",text:"subtext"}]}];
  constructor() { }

  ngOnInit(): void {
  }

}
