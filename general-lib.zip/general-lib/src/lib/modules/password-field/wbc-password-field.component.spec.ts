import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcPasswordFieldComponent } from './wbc-password-field.component';

describe('WbcPasswordFieldComponent', () => {
  let component: WbcPasswordFieldComponent;
  let fixture: ComponentFixture<WbcPasswordFieldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcPasswordFieldComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WbcPasswordFieldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should toggle password',() => {
    component.hidePassword = true;
    component.togglePassword(new Event('click')); 
    expect(component.hidePassword).toBe(false);
  })
});
