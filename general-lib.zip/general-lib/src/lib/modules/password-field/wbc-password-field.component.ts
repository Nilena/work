import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { LIB_CONSTANT } from '../../general-lib-constants.enum';

@Component({
  selector: 'lib-wbc-password-field',
  templateUrl: './wbc-password-field.component.html',
  styleUrls: ['./wbc-password-field.component.css'],
})
export class WbcPasswordFieldComponent implements OnInit {
  hidePassword: boolean = true;
  constants: any;

  @Input() customClass!: string;
  @Input() label!: string;
  @Input() submitted!: boolean;
  @Input() control: FormControl | any;

  constructor() {
    this.constants = LIB_CONSTANT;
  }

  ngOnInit(): void {
  }

  togglePassword(event: Event) {
    event.preventDefault();
    this.hidePassword = !this.hidePassword;
  }
}
