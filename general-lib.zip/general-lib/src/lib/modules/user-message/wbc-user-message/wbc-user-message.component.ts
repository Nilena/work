import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'lib-wbc-user-message',
  templateUrl: './wbc-user-message.component.html',
  styleUrls: ['./wbc-user-message.component.css']
})
export class WbcUserMessageComponent implements OnInit {

  constructor() { }
  @Input() message:string;
  @Input() className:string;

  ngOnInit() {
  }

}
