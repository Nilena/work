import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcUserMessageComponent } from './wbc-user-message/wbc-user-message.component';
import { WbcDynamicPipe } from '../../pipe/wbc-dynamic.pipe';
import { PipeModule } from '../../pipe/pipe.module';



@NgModule({
  declarations: [WbcUserMessageComponent],
  imports: [
    CommonModule,
    PipeModule
  ],
  exports:[WbcUserMessageComponent]
})
export class UserMessageModule { }
