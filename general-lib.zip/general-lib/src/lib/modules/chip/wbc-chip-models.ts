export interface Chip {
    value: string,
    icons?: ChipIcon,
    customClass?: string,
    tag?: boolean,
    isSvgIcon?: boolean,
    removableIcon?: ChipIcon
}

export interface ChipList {
    removableIcon?: ChipIcon,
    chipItems: Chip[],
}

export interface ChipIcon {
    icon?: string,
    iconClass?: string,
    isSvgIcon?: boolean;
}




