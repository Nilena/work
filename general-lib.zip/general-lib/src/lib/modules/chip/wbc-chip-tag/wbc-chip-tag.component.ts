import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Chip } from '../wbc-chip-models';

@Component({
  selector: 'lib-wbc-chip-tag',
  templateUrl: './wbc-chip-tag.component.html',
  styleUrls: ['./wbc-chip-tag.component.css']
})
export class WbcChipTagComponent {

  @Input() data!: Chip;
  @Output() clickEvent = new EventEmitter();

  constructor() { }

  clickedChip(event: Chip) {
    this.clickEvent.emit(event)
  }
}
