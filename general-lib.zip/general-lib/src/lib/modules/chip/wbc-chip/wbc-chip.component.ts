import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Chip, ChipIcon, ChipList } from '../wbc-chip-models';
import { FabButton } from '../../fab-button/wbc-fab-button-model';

@Component({
  selector: 'lib-wbc-chip',
  templateUrl: './wbc-chip.component.html',
  styleUrls: ['./wbc-chip.component.css']
})
export class WbcChipComponent implements OnChanges {
  @Input() chip!: Chip;
  @Input() removableIcon?: ChipIcon
  @Input() tag!: Chip;
  chipFabConfig!: FabButton;

  @Output() clickEvent = new EventEmitter();
  @Output() removeChipEvent = new EventEmitter();

  constructor() { }

  ngOnChanges(changes: SimpleChanges): void {
    this.chipFabConfig = { icon: this.removableIcon?.icon ? this.removableIcon.icon : 'close', toolTipText: 'close', customClass: this.removableIcon?.iconClass ? this.removableIcon.iconClass : 'custom-fab', action: 'close', IsSvgIcon: this.removableIcon?.isSvgIcon ? this.removableIcon?.isSvgIcon : false };
  }

  removeChip(chip: Chip) {
    event?.stopPropagation()
    this.removeChipEvent.emit(chip)
  }

  clickedChip(event: Chip) {
    this.clickEvent.emit(event)
  }
}
