import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcDialogHeaderComponent } from './wbc-dialog-header/wbc-dialog-header.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTooltipModule } from '@angular/material/tooltip';



@NgModule({
  declarations: [WbcDialogHeaderComponent],
  imports: [
    CommonModule,
    MatTooltipModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
  ],
  exports:[WbcDialogHeaderComponent]
})
export class DialoagHeaderModule { }
