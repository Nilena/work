import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcDialogHeaderComponent } from './wbc-dialog-header.component';

describe('WbcDialogHeaderComponent', () => {
  let component: WbcDialogHeaderComponent;
  let fixture: ComponentFixture<WbcDialogHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcDialogHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcDialogHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
