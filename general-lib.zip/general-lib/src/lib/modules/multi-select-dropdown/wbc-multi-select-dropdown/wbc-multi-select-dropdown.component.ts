import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter,
  ChangeDetectorRef,
  AfterContentInit,
  OnDestroy
} from '@angular/core';
import { MatSelect } from '@angular/material/select';
import { ReplaySubject, Subject } from 'rxjs';
import { FormControl } from '@angular/forms';
import { take, takeUntil } from 'rxjs/operators';
import { WbcDropDown } from '../../../models/wbc-drop-down.model';
import { WbcSortService } from '../../../services/wbc-sort.service';
import { LIB_CONSTANT } from '../../../general-lib-constants.enum';

@Component({
  selector: 'lib-multi-select-dropdown',
  templateUrl: './wbc-multi-select-dropdown.component.html',
  styleUrls: ['./wbc-multi-select-dropdown.component.css']
})
export class WbcMultiSelectDropdownComponent implements OnInit {
  @ViewChild('multiSelect') multiSelect: MatSelect;
  /** Subject that emits when the component has been destroyed. */
  private _onDestroy = new Subject<void>();

  public filteredMulti: ReplaySubject<WbcDropDown[]> = new ReplaySubject<
    WbcDropDown[]
  >(1);

  public multiFilterCtrl: FormControl = new FormControl();

  @Input() label: string;
  @Input() noSearchResultText: string;
  @Input() public selectOptionChange: Function;
  @Input() searchText: string = LIB_CONSTANT.SEARCH;
  @Input() key: string;
  @Input() disabled = false;
  @Input() list: WbcDropDown[] = [];
  @Input() selectedList: WbcDropDown[] = [];
  @Input() icon: string;
  @Input() customClass: string;
  @Input() customOptionClass: string;
  @Input() required
  @Input() checkboxValue: boolean = true;
  @Input() checkboxLabel?: string = '';
  @Input() showCheckBox?: boolean = false;
  selectControl = new FormControl(this.selectedList);
  @Output() selectedCheckboxEvent = new EventEmitter<any>();
  @Output() resetForm = new EventEmitter<WbcDropDown>();
  constructor(private sortService: WbcSortService) { }

  ngOnInit() {
    this.intialiseFilter();
  }

  /**
   * attaching the change event to the fileting the hospital
   */
  intialiseFilter() {
    this.list.sort(this.sortService.sortByAsc('viewValue'));
    this.selectControl.setValue(this.selectedList);
    this.filteredMulti.next(this.list.slice());
    this.multiFilterCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterMulti();
      });
  }

  /**
   * filters the hospitals when user searches
   */
  private filterMulti() {
    if (!this.list) {
      return;
    }
    // get the search keyword
    let search = this.multiFilterCtrl.value;
    if (!search) {
      this.filteredMulti.next(this.list.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the hospitals
    this.filteredMulti.next(
      this.list.filter(
        (item) => item.viewValue.toLowerCase().indexOf(search) > -1
      )
    );
  }

  onValueChange(event) {
    this.multiFilterCtrl.reset();
    this.selectedCheckboxEvent.emit(event);
  }

  onSelectionChange() {
    if (this.selectOptionChange) {
      this.selectOptionChange(this.key, this.selectedList);
    }
  }

  compareFn: ((f1: any, f2: any) => boolean) | null = this.compareByValue;
  compareByValue(f1: any, f2: any) {
    return f1 && f2 && f1.value === f2.value;
  }

  ngOnChanges(changes) {
    for (const propName in changes) {
      if (changes.hasOwnProperty(propName)) {
        switch (propName) {
          case 'list':
            {
              this.list = changes.list.currentValue;
              this.intialiseFilter();
            }
            break;
          case 'selectedList':
            this.selectedList = changes.selectedList.currentValue;
            this.selectControl.setValue(this.selectedList);
        }
      }
    }
  }
}
