import {
  AfterViewInit,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  Output,
  QueryList,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { IcolumnConfig } from './wbc-table-pagination.model';
import { TableColumnDirective } from './table-column.directive';
import { MatSort } from '@angular/material/sort';

/**
 * @description
 * Welcome to the ChuckleMaster 5000 - an Angular component that transforms
 * data tables into a comedy extravaganza. Get ready for a coding experience
 * that's as entertaining as it is functional!
 *
 * @example
 * <lib-wbc-table-pagination
 *   [columnConfig]="yourColumnConfig"
 *   [tableData]="yourTableData"
 *   [title]="yourTableTitle"
 *   [totalLength]="yourTotalLength"
 *   [hasNextPage]="yourHasNextPage"
 *   (pageChangeEvent)="yourPageChangeHandler($event)"
 *   (pageSizeEvent)="yourPageSizeHandler($event)"
 * ></lib-wbc-table-pagination>
 *
 * @export
 * @class WbcTableComponent
 * @implements {AfterViewInit}
 * @implements {OnInit}
 * @implements {OnChanges}
 */
@Component({
  selector: 'lib-wbc-table-pagination',
  templateUrl: './wbc-table-pagination.component.html',
  styleUrls: ['./wbc-table-pagination.component.css']
})
export class WbcTablePaginationComponent<T> implements AfterViewInit {
  @Input() columnConfig!: IcolumnConfig[];
  @Input() tableData!: T[];
  @Input() title: string = '';
  @Input() totalLength: number = 10000;
  @Input() hasNextPage: boolean = false;
  @Input() noPagination: boolean = false;
  @Input() sortOptions;
  @Input() isRowClickable = false;
  /**
   * @description
   * Event emitted when the page changes. Hook into this event to
   * navigate through your data with style and flair.
   *
   * @type {EventEmitter<any>}
   */
  @Output() pageChangeEvent = new EventEmitter();

  /**
   * @description
   * Event emitted when the page size changes. Hook into this event to
   * navigate through your data with style and flair.
   *
   * @type {EventEmitter<any>}
   */
  @Output() pageSizeEvent = new EventEmitter();

  /**
   * @description
   * Event emitted when the row is selected. Hook into this event to
   * navigate through your data with style and flair.
   *
   * @type {EventEmitter<any>}
   */
  @Output() rowSelectEvent = new EventEmitter();
  /**
   * @description
   * ViewChild decorator to grab the MatPaginator element for pagination control.
   *
   * @type {MatPaginator}
   */
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  @ContentChildren(TableColumnDirective)
  columnList!: QueryList<TableColumnDirective>;

  columnTemplateMap = new Map();
  pageSize: number = 10;
  pageIndex: number = 1;
  displayedColumns!: string[];
  dataSource!: MatTableDataSource<any>;

  /**
   * @description
   * Lifecycle hook called after the view has been initialized.
   * Connects the data source to the paginator for pagination.
   *
   * @memberof WbcTablePaginationComponent
   */
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    if (this.sortOptions) this.dataSource.sort = this.sort;
  }

  ngAfterContentInit() {
    this.columnList.forEach((item) => {
      this.columnTemplateMap.set(item.columnName, item.template);
    });
  }

  ngOnInit() {
    this.displayedColumns = this.columnConfig.map((col) => col.field);
    this.dataSource = new MatTableDataSource(this.tableData);
    if (this.sortOptions) this.dataSource.sort = this.sort;
  }
  ngDoCheck() {
    this.updatePaginator();
  }
  /**
   * @description
   * Lifecycle hook called when changes occur. Responsible for
   * updating the data source and adjusting pagination settings.
   *
   * @param {SimpleChanges} changes
   * @memberof WbcTableComponent
   */
  async ngOnChanges(changes: SimpleChanges) {
    this.displayedColumns = this.columnConfig.map((col) => col.field);
    const { tableData, hasNextPage } = changes;
    if (tableData && !tableData?.firstChange) {
      this.dataSource.data = await tableData?.currentValue;

      // Move paginator updates to a separate function
      this.updatePaginator();
    }
  }

  // Add a new function to update the paginator
  private updatePaginator() {
    if (!this.noPagination && this.paginator) {
      if (this.hasNextPage) {
        if (
          this.paginator.pageIndex !== undefined &&
          this.paginator.pageSize !== undefined
        ) {
          this.paginator.length =
            (this.paginator.pageIndex + 1) * this.paginator.pageSize +
            this.paginator.pageSize;
          this.totalLength =
            (this.paginator.pageIndex + 1) * this.paginator.pageSize +
            this.paginator.pageSize;
        }
      } else {
        this.paginator.length = this.dataSource.data?.length;
        this.totalLength = this.dataSource.data.length;
      }
    }
  }
  /**
   * Function to handle pagination
   * @param event An event object containing information about the pagination state
   */
  setPageSize(event: any) {
    const { pageIndex, previousPageIndex, pageSize, length } = event;
    this.pageSizeEvent.emit({ pageSize });
    if (this.dataSource.data.length < pageSize) {
      this.pageChangeEvent.emit({ pageSize, pageIndex: pageIndex + 1 });
    }
    if (pageIndex > previousPageIndex && this.hasNextPage)
      if ((pageIndex + 1) * pageSize >= this.dataSource.data?.length) {
        if ((pageIndex + 1) * pageSize === this.dataSource.data?.length) {
          this.paginator.length = this.dataSource?.data?.length + pageSize;
          this.totalLength = this.dataSource?.data?.length + pageSize;
        } else {
          this.pageChangeEvent.emit({ pageSize, pageIndex: pageIndex + 1 });
        }
      }
  }

  canSortColumn(column): boolean {
    // Exclude 'select' column from sorting
    return this.sortOptions && this.sortOptions.active !== 'select';
  }
  
  onRowClick(row:any){
    if (this.isRowClickable) {
      this.rowSelectEvent.emit({data:row})
    }
  } 

  getTooltip(element,column){
    return column.isTooltip?element['tooltip']:null;
  }
}
