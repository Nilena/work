import { Component, Directive, Input, TemplateRef } from '@angular/core';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { TableColumnDirective } from './table-column.directive';

class MockTemplateRef {
  createEmbeddedView() {}
}

@Directive({
  selector: '[mockTableColumn]',
})
class MockTableColumnDirective {
  @Input('tableColumn') columnName!: string;
}

@Component({
  template: `<div mockTableColumn [tableColumn]="'test'">this is test template</div>`,
})
class TestComponent {}

describe('TableColumnDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let element: HTMLElement;
  let directive: TableColumnDirective;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TestComponent, MockTableColumnDirective],
      providers: [
        TableColumnDirective,
        { provide: TemplateRef, useClass: MockTemplateRef },
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    directive = TestBed.inject(TableColumnDirective);
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('should render template', () => {
    fixture.detectChanges();
    const divElement = element.querySelector('div');
    expect(divElement?.textContent).toBe('this is test template');
  });
});
