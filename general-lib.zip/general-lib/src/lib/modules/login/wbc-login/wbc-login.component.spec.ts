import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcLoginComponent } from './wbc-login.component';

describe('WbcLoginComponent', () => {
  let component: WbcLoginComponent;
  let fixture: ComponentFixture<WbcLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
