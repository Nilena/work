import { EventEmitter,Component, OnInit, ViewChild, ViewContainerRef, Input, Output, ElementRef } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'lib-wbc-login',
  templateUrl: './wbc-login.component.html',
  styleUrls: ['./wbc-login.component.css']
})
export class WbcLoginComponent implements OnInit {

  constructor(private snackBar : MatSnackBar) { }
  @Input() emailLabel:string;
  @Input() passwordLabel:string;
  @Input() buttonLabel:string;
  @Input() emailPattern ="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,3}$";
  @Input() buttonTooltip:string;
  @Input() caption:string;
  @Input() emailErrorMessage :string;
  @Input() passwordErrorMessage:string;
  @Input() passwordPattern : string;
  @Output() buttonClicked=new EventEmitter<{buttonEl:ViewContainerRef,email:string,password:string}>();
  hide = true;
  constants;
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);
  resetPassword:any;
  @ViewChild('loginButton', { read: ViewContainerRef, static: true }) el:ViewContainerRef;
  @ViewChild('emailid',{  static: true }) emailid: any;
  @ViewChild('passwordfield',{static: true }) passwordfield: any;
  @Input() imagePath:string;

  ngOnInit() {
  }

 /**
 * Login method called from login button click.
 */
login() {
  if(this.email.value == ""||this.email.invalid){
    console.log("the emei",this.emailid)
    this.emailid.nativeElement.focus();
    this.snackBar.open(this.emailErrorMessage,'',{duration:1000});
  } else if(this.password.value == ""||this.password.invalid){
    this.passwordfield.nativeElement.focus();
      this.snackBar.open(this.passwordErrorMessage,'',{duration:1000});
  }
  else{
    console.log("the elemnt",this.el)
    this.buttonClicked.emit({buttonEl:this.el,email:this.email.value,password:this.password.value})
  }

  }

}
