import { Component, OnInit, Input,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'lib-wbc-time-picker',
  templateUrl: './wbc-time-picker.component.html',
  styleUrls: ['./wbc-time-picker.component.css']
})
export class WbcTimePickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  @Input() time:string;
  @Input() timeKey:string;

  min = new Date()
  @Output() changeHandler=new EventEmitter<{key:string,value:any}>()
  
  
  timeChange(value){
    this.time = value;
    this.changeHandler.emit({key:this.timeKey,value:value})
  }

}
