import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcTimePickerComponent } from './wbc-time-picker.component';

describe('WbcTimePickerComponent', () => {
  let component: WbcTimePickerComponent;
  let fixture: ComponentFixture<WbcTimePickerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WbcTimePickerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcTimePickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
