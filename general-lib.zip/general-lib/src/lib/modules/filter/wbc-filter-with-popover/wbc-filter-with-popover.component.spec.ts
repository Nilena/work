import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcFilterWithPopoverComponent } from './wbc-filter-with-popover.component';

describe('WbcFilterWithPopoverComponent', () => {
  let component: WbcFilterWithPopoverComponent;
  let fixture: ComponentFixture<WbcFilterWithPopoverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcFilterWithPopoverComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcFilterWithPopoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
