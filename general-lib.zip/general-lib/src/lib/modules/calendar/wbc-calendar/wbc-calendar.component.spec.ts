import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { WbcCalendarComponent } from './wbc-calendar.component';
import { CalendarService } from '../../../services/calendar.service';
import { MatSidenav, MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TimeOperationService } from '../../../services/time-operation.service';
import { SimpleChange, SimpleChanges } from '@angular/core';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { ViewportService } from '../../../services/viewport.service';

describe('WbcCalendarComponent', () => {
  let component: WbcCalendarComponent;
  let fixture: ComponentFixture<WbcCalendarComponent>;
  let calendarService: CalendarService;
  let timeService: TimeOperationService;
  let viewportService: ViewportService;
  let updateDataSpy: jasmine.Spy;

  let sidenavSpy: jasmine.SpyObj<MatSidenav>;

  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };

  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'DDDD',
      date: 'DD',
      month: 'MM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      shortDay: 'ddd',
      monthName: 'MMMM',
      hour: 'HH',
      formattedHr: 'hh:mm A'
    }
  };

  const viewportServiceMock = {
    isMobileView: true
  };
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [WbcCalendarComponent],
      providers: [{ provide: MatSidenav, useValue: sidenavSpy },
      { provide: 'WbcCalenderConfig', useValue: MockCalenderConfig },
      { provide: ViewportService, useValue: viewportServiceMock },
        CalendarService, TimeOperationService],
      imports: [MatSidenavModule,
        MatToolbarModule,
        BrowserAnimationsModule,]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcCalendarComponent);
    component = fixture.componentInstance;
    calendarService = TestBed.inject(CalendarService);
    timeService = TestBed.inject(TimeOperationService);
    viewportService = TestBed.inject(ViewportService);
    updateDataSpy = spyOn(calendarService, 'updateData');

    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should handle ngOnChanges when config is provided', () => {
    const config = MockCalenderConfig;
    component.config = config;
    component.ngOnChanges({ config: new SimpleChange(null, config, false) });

    expect(component.calendarConfig).toEqual(config);
    expect(calendarService.displayedView).toEqual(config.headerConfig.view.default);
    expect(component.activeViewBy).toEqual(config.headerConfig.view.default);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change month and date based on direction for month view (backward action)', () => {
    const Mockevent = { view: 'month', action: -1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: '12',
      year: '2023',
      date: '15',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });

  it('should change date based on direction for day view (forward action)', () => {
    const Mockevent = { view: 'day', action: 1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: '01',
      year: '2024',
      date: '16',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });

  it('should change month based on direction for month view (forward action)', () => {
    const Mockevent = { view: 'month', action: 1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: timeService.getMonthNumber('Feburary', 'MMMM'),
      year: '2024',
      date: '15',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });


  it('should change  date based on direction for day view (backward action)', () => {
    const Mockevent = { view: 'day', action: -1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: timeService.getMonthNumber('Janurary', 'MMMM'),
      year: '2024',
      date: '14',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });
  it('should change week  (forward action)', () => {
    const Mockevent = { view: 'week', action: 1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: '01',
      year: '2024',
      date: '22',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });
  it('should change week  (backward action)', () => {
    const Mockevent = { view: 'week', action: -1 };
    calendarService.displayedDate = '15';
    calendarService.displayedYear = '2024';
    calendarService.displayedMonth = '01';
    calendarService.displayedView = Mockevent.view;
    component.changeMonth(Mockevent);
    const expectedData = {
      month: '01',
      year: '2024',
      date: '08',
      view: calendarService.displayedView
    };
    expect(updateDataSpy).toHaveBeenCalledWith(expectedData);
  });


  it('should toggle the sidenav when toggleSidenav is called', () => {
    const sideNavSpy = spyOn(component.sidenav, 'toggle');
    const mockEvent = true;
    component.toggleSidenav(mockEvent);
    expect(sideNavSpy).toHaveBeenCalled();
  });

  it('should change the active view', () => {
    const expectedView = 'week';
    component.changeView(expectedView);
    expect(component.activeViewBy).toBe(expectedView);
  });

  it('should set openMenu to true if not in mobile view', () => {
    viewportServiceMock.isMobileView = false;
    component.ngOnInit();

    expect(component.openMenu).toBe(true);
  });

  it('should set openMenu to false if in mobile view', () => {
    viewportServiceMock.isMobileView = true;

    component.ngOnInit();
    expect(component.openMenu).toBe(false);
  });

  it('should emit getEventDetails event when eventData is called', () => {
    spyOn(component.eventData, 'emit');
    const mockEvent = true;
    component.getEventDetails(mockEvent);
    expect(component.eventData.emit).toHaveBeenCalled();
  });

  afterEach(() => {
    fixture.destroy();
  });
});

