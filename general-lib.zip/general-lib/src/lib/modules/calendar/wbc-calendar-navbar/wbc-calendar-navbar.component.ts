import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { DateFormatModel, SideNavConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { Subscription } from 'rxjs';
import { LIB_CONSTANT } from '../../../general-lib-constants.enum';

@Component({
  selector: 'lib-wbc-calendar-navbar',
  templateUrl: './wbc-calendar-navbar.component.html',
  styleUrls: ['./wbc-calendar-navbar.component.css']
})
export class WbcCalendarNavbarComponent implements OnInit {
  constants
  @Input() sidenav;
  @Input() reportees;
  @Input() dateConfig: DateFormatModel;
  @Input() configSideNav: SideNavConfigModel;
  @Output() dateChangeEvent = new EventEmitter<any>();
  @Output() reprteeChangeEvent = new EventEmitter<any>();
  date
  private eventDetailsSubscription: Subscription;
  is_open = true;
  displayedDatePicker: string;
  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService) { 
      this.constants = LIB_CONSTANT;}

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if ('sidenav' in changes) {
      this.is_open = changes.sidenav.currentValue;
    } 
    this.eventDetailsSubscription = this.calendarService.data$.subscribe((data:any) => {
      const month = parseInt(data.month, 10) - 1;
      this.date = new Date(data.year, month, data.date);
    })

  }

  /**
   * @description to update calender date value based on date picker change
   * @param event 
   */
  OnDateChange(event) {
    this.calendarService.displayedYear = this.timeService.getYear(event).toString();
    this.calendarService.displayedDate = this.timeService.getDateObj(event).toString().padStart(2, '0');
    this.calendarService.displayedMonth = this.timeService.getMonth(event);
    this.calendarService.displayedDay = this.timeService.getDayName(this.calendarService.displayedYear, this.calendarService.displayedMonth, this.calendarService.displayedDate, this.dateConfig.day);

    let data = {
      month: this.calendarService.displayedMonth,
      year: this.calendarService.displayedYear,
      date: this.calendarService.displayedDate,
      view: this.calendarService.displayedView
    };
    this.calendarService.updateData(data);
    this.dateChangeEvent.emit(data);
  }

  
  /**
   * @description to change reports 
   * @param value 
   */
  onDropDownChange(valueKey, value){
    this.reprteeChangeEvent.emit(value);
  }
}
