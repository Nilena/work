import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcCalendarNavbarComponent } from './wbc-calendar-navbar.component';
import { SimpleChanges } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import moment from 'moment';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';

describe('WbcCalendarNavbarComponent', () => {
  let component: WbcCalendarNavbarComponent;
  let fixture: ComponentFixture<WbcCalendarNavbarComponent>;
  let calendarService: CalendarService;
  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };

  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'dddd',
      date: 'DD',
      month: 'MM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      shortDay: 'ddd',
      monthName: 'MMMM',
      hour: 'HH',
      formattedHr: 'hh:mm A'
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WbcCalendarNavbarComponent],
      providers: [CalendarService]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcCalendarNavbarComponent);
    calendarService = TestBed.inject(CalendarService);
    component = fixture.componentInstance;
    component.configSideNav = MockCalenderConfig.sideNavConfig;
    component.dateConfig = MockCalenderConfig.dateFormat;

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set is_open to false when sidenav input changes', () => {
    expect(component.is_open).toBe(true);

    component.sidenav = false;
    const changes: SimpleChanges = {
      sidenav: {
        currentValue: false,
        previousValue: true,
        firstChange: false,
        isFirstChange: function (): boolean {
          throw new Error('Function not implemented.');
        }
      }
    };
    component.ngOnChanges(changes);
    expect(component.is_open).toBe(false);
  });

  it('should update calendar data when OnDateChange is called', () => {
    calendarService.displayedYear = '2022';
    calendarService.displayedDate = '15';
    calendarService.displayedMonth = '01';
    calendarService.displayedDay = 'Sunday';
    calendarService.displayedView = 'month';
    const mockEvent = moment('2022-02-20');
    component.OnDateChange(mockEvent);
    expect(calendarService.displayedYear).toBe('2022');
    expect(calendarService.displayedDate).toBe('20');
    expect(calendarService.displayedMonth).toBe('02');
    expect(calendarService.displayedDay).toBe('Sunday');
    expect(calendarService.displayedView).toBe('month');
  });


  it('should emit reprteeChangeEvent event when onDropDownChange is called', () => {
    spyOn(component.reprteeChangeEvent, 'emit');
    let value = 'month';
    let valueKey;
    component.onDropDownChange(valueKey, value);
    expect(component.reprteeChangeEvent.emit).toHaveBeenCalledWith('month');
  });
});
