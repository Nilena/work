import { Component, EventEmitter, Input, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { CalendarService } from '../../../services/calendar.service';
import { LIB_CONSTANT } from '../../../general-lib-constants.enum';
import { TimeOperationService } from '../../../services/time-operation.service';
import { Subscription } from 'rxjs';
import { DateFormatModel, HeaderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';

@Component({
  selector: 'lib-wbc-calendar-header',
  templateUrl: './wbc-calendar-header.component.html',
  styleUrls: ['./wbc-calendar-header.component.css']
})
export class WbcCalendarHeaderComponent implements OnInit {
  viewByOptions: any;
  displayView: string
  openLeftPanel: boolean = false;
  currentMonthName: string;
  currentYear: string;
  displayDate: string;
  constants;
  private eventDetailsSubscription: Subscription;
  @Input() activeViewBy: string;
  @Input() title: string;
  @Input() headerConfig: HeaderConfigModel;
  @Input() dateConfig: DateFormatModel;
  @Output() prevNextBtn = new EventEmitter<any>();
  @Output() handleChangeViewBy = new EventEmitter<any>();
  @Output() toggleSideNav = new EventEmitter<boolean>();

  constructor(private calendarService: CalendarService,
    private timeService: TimeOperationService) {
    this.activeViewBy = this.calendarService.displayedView;
    this.constants = LIB_CONSTANT;
  }

  ngOnInit(): void {
    this.eventDetailsSubscription = this.calendarService.data$.subscribe((data) => {
      this.currentMonthName = this.timeService.getMonthName(data.month, this.dateConfig.monthName);
      this.currentYear = data.year;
      this.displayDate = data.date;
    })
  }

  ngOnChanges() {
    if (this.headerConfig) {
      this.viewByOptions = this.headerConfig.view.options;
      this.title = this.headerConfig.title;
      this.activeViewBy = this.calendarService.displayedView;
    }
  }
  /**
   * @description toggle function to open and close menu
   */
  toggleSidenav(event): void {
    this.toggleSideNav.emit(event);
  }

  /**
   * @description  function to get value of view change
   */

  handleSelection(event) {
    this.handleChangeViewBy.emit(event?.value);
  }

  /**
   * @description  function to get value of action change
   * @param event event value -1 for backward and 1 for forward
   * @param activeViewBy  current view value
   */

  onPrevNextChange(event, displayView) {
    let data = {
      action: event,
      view: displayView
    }
    this.prevNextBtn.emit(data);
  }

  /**
   * @description function to display current month 
   * @param event current month 
   */
  getCurrentMonth(event) {
    this.currentMonthName = event;
  }

  /**
   * @description function to display current year 
   * @param event current month 
   */
  getCurrentYear(event) {
    this.currentYear = event;
  }

  /**
   * @description to destroy event subcription
   */
  ngOnDestroy() {
    this.eventDetailsSubscription.unsubscribe();
  }
}
