import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { MatSidenavModule } from '@angular/material/sidenav';
import { CalendarService } from '../../../services/calendar.service';
import { WbcCalendarHeaderComponent } from './wbc-calendar-header.component';
import { BehaviorSubject, of } from 'rxjs';
import { MatToolbarModule } from '@angular/material/toolbar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { TimeOperationService } from '../../../services/time-operation.service';

describe('WbcCalendarHeaderComponent', () => {
  let component: WbcCalendarHeaderComponent;
  let fixture: ComponentFixture<WbcCalendarHeaderComponent>;
  let calendarServiceSpy: jasmine.SpyObj<CalendarService>;
  let timeServiceSpy: jasmine.SpyObj<TimeOperationService>;

  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };

  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'DDDD',
      date: 'DD',
      month: 'MM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      shortDay: 'ddd',
      monthName: 'MMMM',
      hour: 'HH',
      formattedHr: 'hh:mm A'
    }
  };

  beforeEach(() => {
    calendarServiceSpy = jasmine.createSpyObj('CalendarService', ['data$', 'displayedView']);
    timeServiceSpy = jasmine.createSpyObj('TimeOperationService', ['getMonthName']);
    TestBed.configureTestingModule({
      declarations: [WbcCalendarHeaderComponent],
      providers: [
        { provide: TimeOperationService, useValue: timeServiceSpy },
        { provide: 'WbcCalenderConfig', useValue: MockCalenderConfig },
        { provide: CalendarService, useValue: calendarServiceSpy },],
      imports: [
        MatSidenavModule,
        MatToolbarModule,
        BrowserAnimationsModule,
      ],
    }).compileComponents();

  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcCalendarHeaderComponent);
    calendarServiceSpy.displayedView = 'month';
    component = fixture.componentInstance;
    calendarServiceSpy.data$ = of({ month: '01', year: '2022', date: '01', view: 'month' });
    component.headerConfig = MockCalenderConfig.headerConfig;
    component.dateConfig = MockCalenderConfig.dateFormat;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should handle ngOnChanges correctly', () => {
    component.ngOnChanges();
    expect(component.viewByOptions).toEqual(MockCalenderConfig.headerConfig.view.options);
    expect(component.title).toEqual(MockCalenderConfig.headerConfig.title);
    expect(component.activeViewBy).toEqual(calendarServiceSpy.displayedView);
  });
  it('should update component properties on ngOnInit', fakeAsync(() => {
    tick();
    const testData = {
      month: '01',
      year: '2022',
      date: '01',
      view: 'month'
    };
    const dataSubject = new BehaviorSubject(testData);
    calendarServiceSpy.data$ = dataSubject.asObservable();
    timeServiceSpy.getMonthName.and.returnValue('January');
    component.ngOnInit();

    expect(component.currentMonthName).toBe('January');
    expect(component.currentYear).toBe('2022');
    expect(component.displayDate).toBe('01');
  }));


  it('should emit toggleSideNav event when toggleSidenav is called', () => {
    spyOn(component.toggleSideNav, 'emit');
    const mockEvent = true;
    component.toggleSidenav(mockEvent);
    expect(component.toggleSideNav.emit).toHaveBeenCalled();
  });

  it('should emit handleChangeViewBy event when handleSelection is called', () => {
    spyOn(component.handleChangeViewBy, 'emit');
    component.handleSelection({ value: 'month' });
    expect(calendarServiceSpy.displayedView).toEqual('month');
    expect(component.handleChangeViewBy.emit).toHaveBeenCalledWith('month');
  });

  it('should emit prevNextBtn event when skiphandle is called', () => {
    let MockData = {
      action: -1,
      view: 'month'
    }
    spyOn(component.prevNextBtn, 'emit');
    component.onPrevNextChange(-1, 'month');
    expect(calendarServiceSpy.displayedView).toEqual('month');
    expect(component.prevNextBtn.emit).toHaveBeenCalledWith(MockData);
  });

  it('should update currentMonthName when getCurrentMonth is called', () => {
    const mockMonth = 'January';
    component.getCurrentMonth(mockMonth);
    expect(component.currentMonthName).toBe(mockMonth);
  });

  it('should update currentYear when getCurrentYear is called', () => {
    const mockYear = '2023';
    component.getCurrentYear(mockYear);
    expect(component.currentYear).toBe(mockYear);
  });


});
