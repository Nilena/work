import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { WbcGridAgainstDayComponent } from './wbc-grid-against-day.component';
import { CalendarService } from '../../../services/calendar.service';
import { TimeOperationService } from '../../../services/time-operation.service';
import { WbcCalenderConfigModel } from '../wbc-calendar-config-model/wbc-calendar-config-model';
import { of } from 'rxjs';

describe('WbcGridAgainstDayComponent', () => {
  let component: WbcGridAgainstDayComponent;
  let fixture: ComponentFixture<WbcGridAgainstDayComponent>;
  let calendarServiceMock: jasmine.SpyObj<CalendarService>;
  let timeServiceMock: jasmine.SpyObj<TimeOperationService>;
  const MockViewOptions = [
    { id: 'month', value: 'month', viewValue: 'Month', hide: false },
    { id: 'week', value: 'week', viewValue: 'Week', hide: false },
    { id: 'day', value: 'day', viewValue: 'Day', hide: false }
  ];

  const MockViewConfig = {
    default: 'month',
    options: MockViewOptions,
    display: true,
  };
  const mockstatusConfig = {
    approved: 'green',
    rejected: 'red',
    pending: 'blue',
    default: 'transparent'
  }
  const MockCalenderConfig: WbcCalenderConfigModel = {
    headerConfig: {
      view: MockViewConfig,
      displayView: true,
      displaySkipOptions: true,
      display: true,
      title: 'Calender',
      menu: true
    },
    sideNavConfig: {
      display: true,
      displayCalender: true,
      selectionDropdown: { display: true, multi: true }
    },
    dateFormat: {
      day: 'dddd',
      date: 'DD',
      month: 'MM',
      year: 'YYYY',
      formattedDate: 'YYYY-MM-DD',
      shortDay: 'ddd',
      monthName: 'MMMM',
      hour: 'HH',
      formattedHr: 'hh:mm A'
    },
    StatusConfig: mockstatusConfig
  };
  beforeEach(() => {
    timeServiceMock = jasmine.createSpyObj('TimeOperationService', [
      'convertTo24HrFormat',
      'isCurrentTime', 'getDayName']);

    calendarServiceMock = jasmine.createSpyObj('CalendarService', [
      'getHourList',
      'updateEmittedData'
    ]);

    TestBed.configureTestingModule({
      declarations: [WbcGridAgainstDayComponent],
      providers: [
        { provide: CalendarService, useValue: calendarServiceMock },
        { provide: TimeOperationService, useValue: timeServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(WbcGridAgainstDayComponent);
    calendarServiceMock = TestBed.inject(CalendarService) as jasmine.SpyObj<CalendarService>;
    timeServiceMock = TestBed.inject(TimeOperationService) as jasmine.SpyObj<TimeOperationService>;
    component = fixture.componentInstance;
    component.dateConfig = MockCalenderConfig.dateFormat;
    component.statusConfig = MockCalenderConfig.StatusConfig;
    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should set hours and update events on ngOnChanges', () => {
    const dateConfig = MockCalenderConfig.dateFormat;
    component.dateConfig = dateConfig;
    const events = [{ hour: '12:00 PM' }, { hour: '03:30 PM' }];
    component.events = events;

    calendarServiceMock.getHourList.and.returnValue(['12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM']);
    timeServiceMock.convertTo24HrFormat.and.callFake((hour, dateConfig) => hour);

    const testData = { year: '2022', month: '01', date: '01', view: 'month' };
    calendarServiceMock.data$ = of(testData);

    component.ngOnChanges({ dateConfig: { currentValue: dateConfig, previousValue: undefined, firstChange: true, isFirstChange: () => true } });

    expect(component.hours).toEqual(['12:00 PM', '01:00 PM', '02:00 PM', '03:00 PM', '04:00 PM']);
    expect(component.events).toEqual([
      { formattedHour: '12:00 PM', hour: '12:00 PM' },
      { formattedHour: '03:30 PM', hour: '03:30 PM' },
    ]);
    expect(calendarServiceMock.displayedYear).toBe(testData.year);
    expect(calendarServiceMock.displayedMonth).toBe(testData.month);
    expect(calendarServiceMock.displayedDate).toBe(testData.date);
    expect(timeServiceMock.getDayName).toHaveBeenCalledWith(testData.year, testData.month, testData.date, dateConfig.day);
  });


  it('should filter events for a specific hour', () => {
    component.events = [
      { hour: 12, day: '01', month: '01', year: '2022' },
      { hour: 12, day: '02', month: '01', year: '2022' },
      { hour: 14, day: '01', month: '01', year: '2022' },
    ];

    calendarServiceMock.displayedDate = '01';
    calendarServiceMock.displayedMonth = '01';
    calendarServiceMock.displayedYear = '2022';
    const filteredEvents = component.getEventsForHour(12);
    expect(filteredEvents.length).toBe(1);
    expect(filteredEvents[0]).toEqual({ hour: 12, day: '01', month: '01', year: '2022' });
  });

  it('should return true if the given hour is the current time', () => {
    component.dateConfig = MockCalenderConfig.dateFormat;
    timeServiceMock.isCurrentTime.and.returnValue(true);
    const result = component.getCurrentTime('12:30 PM');
    expect(result).toBe(true);
    expect(timeServiceMock.isCurrentTime).toHaveBeenCalledWith('12:30 PM', 'hh:mm A');
  });

  it('should return false if the given hour is not the current time', () => {
    component.dateConfig = MockCalenderConfig.dateFormat;
    timeServiceMock.isCurrentTime.and.returnValue(false);
    const result = component.getCurrentTime('12:30 PM');
    expect(result).toBe(false);
    expect(timeServiceMock.isCurrentTime).toHaveBeenCalledWith('12:30 PM', 'hh:mm A');
  });

  it('should return "red" for status "rejected"', () => {
    const status = 'rejected';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('red');
  });

  it('should return "custom" for status "addvisit"', () => {
    const status = '';
    const result = component.getBackgroundColor(status, true);
    expect(result).toEqual(component.statusConfig.custom);
  });


  it('should return "blue" for status "pending"', () => {
    const status = 'pending';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('blue');
  });

  it('should return "transparent" for unknown status', () => {
    const status = 'unknown';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('transparent');
  });

  it('should return "transparent" for unknown status', () => {
    const status = 'approved';
    const result = component.getBackgroundColor(status);
    expect(result).toEqual('green');
  });
  
  // it('should emit eventData when getData is called', () => {
  //   spyOn(component.eventData, 'emit').and.callThrough();
  //   const mockEvent = { day: '15', month: '01', year: '2024', eventName: 'Webcardio Client meet', hour: '10:00 AM', status: 'rejected' };
  //   const mockHour = '10';
  //   calendarServiceMock.displayedDate = '15';
  //   calendarServiceMock.displayedMonth = '01';
  //   calendarServiceMock.displayedYear = '2024'
  //   const expectedEmittedData = {
  //     date: calendarServiceMock.displayedDate,
  //     month: calendarServiceMock.displayedMonth,
  //     year: calendarServiceMock.displayedYear,
  //     event: mockEvent,
  //     hour: mockHour,
  //   };
  //   component.getData(mockEvent, mockHour);
  //   expect(component.eventData.emit).toHaveBeenCalledWith(expectedEmittedData);
  // });


  it('should emit eventData and updateEmittedData when getData is called', () => {
    const eventDataSpy = spyOn(component.eventData, 'emit').and.callThrough()    ;

    const mockEvent = { day: '15', month: '01', year: '2024', eventName: 'Webcardio Client meet', hour: '10:00 AM', status: 'rejected' };
    const mockHour = '10';
    calendarServiceMock.displayedDate = '15';
    calendarServiceMock.displayedMonth = '01';
    calendarServiceMock.displayedYear = '2024';
    component.getData(mockEvent, mockHour);

    const expectedEmittedData = {
      date: calendarServiceMock.displayedDate,
      month: calendarServiceMock.displayedMonth,
      year: calendarServiceMock.displayedYear,
      event: mockEvent,
      hour: mockHour,
    };
    expect(eventDataSpy).toHaveBeenCalledWith(expectedEmittedData);
  });

  it('should emit eventData when getData is called', () => {
    spyOn(component.eventData, 'emit').and.callThrough(); 
    const mockEvent = { day: '15', month: '01', year: '2024', eventName: 'Webcardio Client meet', hour: '10:00 AM', status: 'rejected' };
    const mockHour = '10';
    calendarServiceMock.displayedDate = '15';
    calendarServiceMock.displayedMonth = '01';
    calendarServiceMock.displayedYear ='2024'
    const expectedEmittedData = {
      date: calendarServiceMock.displayedDate,
      month: calendarServiceMock.displayedMonth,
      year: calendarServiceMock.displayedYear,
      event: mockEvent,
      hour: mockHour,
    };
    component.getData(mockEvent, mockHour);
    expect(component.eventData.emit).toHaveBeenCalledWith(expectedEmittedData);
  });

});
