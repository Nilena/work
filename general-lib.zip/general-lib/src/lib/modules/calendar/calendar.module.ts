import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcCalendarComponent } from './wbc-calendar/wbc-calendar.component';
import { WbcCalendarNavbarComponent } from './wbc-calendar-navbar/wbc-calendar-navbar.component';
import { WbcCalendarHeaderComponent } from './wbc-calendar-header/wbc-calendar-header.component';
import { MultiSelectDropdownModule } from '../multi-select-dropdown/multi-select-dropdown.module';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { DatePickerModule } from '../date-picker/date-picker.module';
import { MatListModule } from '@angular/material/list';
import { WbcGridAgainstDayComponent } from './wbc-grid-against-day/wbc-grid-against-day.component';
import { WbcCalendarGridboxComponent } from './wbc-calendar-gridbox/wbc-calendar-gridbox.component';
import { WbcWebGridAgainstMonthComponent } from './wbc-web-grid-against-month/wbc-web-grid-against-month.component';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { BidirectionalSkipModule } from '../bidirectional-skip/bidirectional-skip.module';
import { DragDropModule } from '@angular/cdk/drag-drop';

import { ActionDialogModule } from '../action-dialog/action-dialog.module';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';
import { WbcDayViewBottomSheetComponent } from './wbc-day-view-bottom-sheet/wbc-day-view-bottom-sheet.component';
import { WbcGridAgainstWeekComponent } from './wbc-grid-against-week/wbc-grid-against-week.component';

@NgModule({
  declarations: [
    WbcCalendarComponent,
    WbcCalendarNavbarComponent,
    WbcCalendarHeaderComponent,
    WbcGridAgainstDayComponent,
    WbcCalendarGridboxComponent,
    WbcWebGridAgainstMonthComponent,
    WbcDayViewBottomSheetComponent,
    WbcGridAgainstWeekComponent,
  ],
  imports: [
    CommonModule,
    MultiSelectDropdownModule,
    MatIconModule,
    MatSidenavModule,
    DatePickerModule,
    MatListModule,
    MatToolbarModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    BidirectionalSkipModule,
    DragDropModule,
    ActionDialogModule,
    MatBottomSheetModule,
    
  ],
  exports: [
    WbcCalendarComponent
  ]
})
export class CalendarModule {}
