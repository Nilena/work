import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcCloseIconComponent } from './wbc-close-icon.component';

describe('WbcCloseIconComponent', () => {
  let component: WbcCloseIconComponent;
  let fixture: ComponentFixture<WbcCloseIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcCloseIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcCloseIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
