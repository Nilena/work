import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcInfoIconComponent } from './wbc-info-icon.component';

describe('WbcInfoIconComponent', () => {
  let component: WbcInfoIconComponent;
  let fixture: ComponentFixture<WbcInfoIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcInfoIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcInfoIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
