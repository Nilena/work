import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcSuccessIconComponent } from './wbc-success-icon.component';

describe('WbcSuccessIconComponent', () => {
  let component: WbcSuccessIconComponent;
  let fixture: ComponentFixture<WbcSuccessIconComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcSuccessIconComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcSuccessIconComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
