import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'lib-wbc-success-icon',
  templateUrl: './wbc-success-icon.component.html',
  styleUrls: ['./wbc-success-icon.component.css']
})
export class WbcSuccessIconComponent implements OnInit {

  constructor() { }

  @Input() size;

  ngOnInit(): void {
  }

}
