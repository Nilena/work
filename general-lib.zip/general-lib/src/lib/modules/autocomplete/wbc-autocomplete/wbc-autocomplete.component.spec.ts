import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WbcAutocompleteComponent } from './wbc-autocomplete.component';

describe('WbcAutocompleteComponent', () => {
  let component: WbcAutocompleteComponent;
  let fixture: ComponentFixture<WbcAutocompleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WbcAutocompleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WbcAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
