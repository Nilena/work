import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WbcAutocompleteComponent } from './wbc-autocomplete/wbc-autocomplete.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

@NgModule({
  declarations: [WbcAutocompleteComponent],
  imports: [
    CommonModule,
    MatAutocompleteModule,
    MatInputModule,
    ReactiveFormsModule,
    MatIconModule
  ],
  exports: [WbcAutocompleteComponent]
})
export class AutocompleteModule {}
